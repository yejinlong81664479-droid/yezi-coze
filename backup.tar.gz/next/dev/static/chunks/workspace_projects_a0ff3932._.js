(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0aa19d29._.js",
  "static/chunks/b9369_next_dist_compiled_react-dom_042e344b._.js",
  "static/chunks/b9369_next_dist_compiled_react-server-dom-turbopack_4cf0dcec._.js",
  "static/chunks/b9369_next_dist_compiled_next-devtools_index_47dc7d4e.js",
  "static/chunks/b9369_next_dist_compiled_8be6bc0d._.js",
  "static/chunks/b9369_next_dist_client_c798e8db._.js",
  "static/chunks/b9369_next_dist_a8f12cf7._.js",
  "static/chunks/ff2e8_@swc_helpers_cjs_ed7f8946._.js"
],
    source: "entry"
});
