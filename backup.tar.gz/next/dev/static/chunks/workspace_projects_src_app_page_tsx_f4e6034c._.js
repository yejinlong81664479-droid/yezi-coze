(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/3eae6_motion-dom_dist_es_969545b7._.js",
  "static/chunks/ed11c_framer-motion_dist_es_2fabf022._.js",
  "static/chunks/5813c_three_build_three_core_ce1ddd28.js",
  "static/chunks/5813c_three_build_three_module_d18562fa.js",
  "static/chunks/5813c_three_build_three_module_e17194c6.js",
  "static/chunks/f3c31_@react-three_fiber_dist_047566f2._.js",
  "static/chunks/86bb5__pnpm_14179d0c._.js",
  "static/chunks/workspace_projects_src_faade81a._.js"
],
    source: "dynamic"
});
