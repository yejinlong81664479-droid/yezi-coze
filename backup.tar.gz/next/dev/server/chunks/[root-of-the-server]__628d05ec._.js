module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/http2 [external] (http2, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http2", () => require("http2"));

module.exports = mod;
}),
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[externals]/tty [external] (tty, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/node:crypto [external] (node:crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:crypto", () => require("node:crypto"));

module.exports = mod;
}),
"[externals]/pg [external] (pg, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("pg", () => require("pg"));

module.exports = mod;
}),
"[externals]/child_process [external] (child_process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("child_process", () => require("child_process"));

module.exports = mod;
}),
"[externals]/@aws-sdk/client-s3 [external] (@aws-sdk/client-s3, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("@aws-sdk/client-s3", () => require("@aws-sdk/client-s3"));

module.exports = mod;
}),
"[externals]/node:fs/promises [external] (node:fs/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:fs/promises", () => require("node:fs/promises"));

module.exports = mod;
}),
"[externals]/buffer [external] (buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}),
"[project]/workspace/projects/src/storage/database/shared/schema.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "generations",
    ()=>generations,
    "insertGenerationSchema",
    ()=>insertGenerationSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$table$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/node_modules/.pnpm/drizzle-orm@0.45.1_@types+pg@8.16.0_pg@8.16.3/node_modules/drizzle-orm/pg-core/table.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$text$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/node_modules/.pnpm/drizzle-orm@0.45.1_@types+pg@8.16.0_pg@8.16.3/node_modules/drizzle-orm/pg-core/columns/text.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/node_modules/.pnpm/drizzle-orm@0.45.1_@types+pg@8.16.0_pg@8.16.3/node_modules/drizzle-orm/pg-core/columns/varchar.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/node_modules/.pnpm/drizzle-orm@0.45.1_@types+pg@8.16.0_pg@8.16.3/node_modules/drizzle-orm/pg-core/columns/timestamp.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$jsonb$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/node_modules/.pnpm/drizzle-orm@0.45.1_@types+pg@8.16.0_pg@8.16.3/node_modules/drizzle-orm/pg-core/columns/jsonb.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$integer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/node_modules/.pnpm/drizzle-orm@0.45.1_@types+pg@8.16.0_pg@8.16.3/node_modules/drizzle-orm/pg-core/columns/integer.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$indexes$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/node_modules/.pnpm/drizzle-orm@0.45.1_@types+pg@8.16.0_pg@8.16.3/node_modules/drizzle-orm/pg-core/indexes.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$sql$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/node_modules/.pnpm/drizzle-orm@0.45.1_@types+pg@8.16.0_pg@8.16.3/node_modules/drizzle-orm/sql/sql.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$zod$40$0$2e$8$2e$3_drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3_$5f$zod$40$4$2e$2$2e$1$2f$node_modules$2f$drizzle$2d$zod$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/node_modules/.pnpm/drizzle-zod@0.8.3_drizzle-orm@0.45.1_@types+pg@8.16.0_pg@8.16.3__zod@4.2.1/node_modules/drizzle-zod/index.mjs [app-route] (ecmascript)");
;
;
;
const generations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$table$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["pgTable"])("generations", {
    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["varchar"])("id", {
        length: 36
    }).primaryKey().default(__TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$sql$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sql"]`gen_random_uuid()`),
    type: (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["varchar"])("type", {
        length: 20
    }).notNull(),
    prompt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$text$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["text"])("prompt").notNull(),
    style: (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$text$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["text"])("style"),
    pageCount: (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$integer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["integer"])("page_count").default(1),
    imageUrls: (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$jsonb$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["jsonb"])("image_urls").$type(),
    imageKeys: (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$jsonb$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["jsonb"])("image_keys").$type(),
    createdAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["timestamp"])("created_at", {
        withTimezone: true
    }).defaultNow().notNull()
}, (table)=>({
        typeIdx: (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$indexes$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["index"])("generations_type_idx").on(table.type),
        createdAtIdx: (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$indexes$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["index"])("generations_created_at_idx").on(table.createdAt)
    }));
const { createInsertSchema: createCoercedInsertSchema } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$zod$40$0$2e$8$2e$3_drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3_$5f$zod$40$4$2e$2$2e$1$2f$node_modules$2f$drizzle$2d$zod$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createSchemaFactory"])({
    coerce: {
        date: true
    }
});
const insertGenerationSchema = createCoercedInsertSchema(generations).pick({
    type: true,
    prompt: true,
    style: true,
    pageCount: true
});
}),
"[project]/workspace/projects/src/storage/database/generationManager.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GenerationManager",
    ()=>GenerationManager,
    "generationManager",
    ()=>generationManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$expressions$2f$conditions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/node_modules/.pnpm/drizzle-orm@0.45.1_@types+pg@8.16.0_pg@8.16.3/node_modules/drizzle-orm/sql/expressions/conditions.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$expressions$2f$select$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/node_modules/.pnpm/drizzle-orm@0.45.1_@types+pg@8.16.0_pg@8.16.3/node_modules/drizzle-orm/sql/expressions/select.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$coze$2d$coding$2d$dev$2d$sdk$40$0$2e$5$2e$0_$40$types$2b$pg$40$8$2e$16$2e$0_openai$40$6$2e$15$2e$0_ws$40$8$2e$19$2e$0_zod$40$4$2e$2$2e$1_$5f$ws$40$8$2e$19$2e$0$2f$node_modules$2f$coze$2d$coding$2d$dev$2d$sdk$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/node_modules/.pnpm/coze-coding-dev-sdk@0.5.0_@types+pg@8.16.0_openai@6.15.0_ws@8.19.0_zod@4.2.1__ws@8.19.0/node_modules/coze-coding-dev-sdk/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$shared$2f$schema$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/src/storage/database/shared/schema.ts [app-route] (ecmascript)");
;
;
;
const STORAGE_EXPIRE_SECONDS = 30 * 24 * 60 * 60 // 30 天
;
const REFRESH_THRESHOLD_SECONDS = 27 * 24 * 60 * 60 // 27 天后刷新
;
class GenerationManager {
    async createGeneration(data) {
        const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$coze$2d$coding$2d$dev$2d$sdk$40$0$2e$5$2e$0_$40$types$2b$pg$40$8$2e$16$2e$0_openai$40$6$2e$15$2e$0_ws$40$8$2e$19$2e$0_zod$40$4$2e$2$2e$1_$5f$ws$40$8$2e$19$2e$0$2f$node_modules$2f$coze$2d$coding$2d$dev$2d$sdk$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
        const validated = __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$shared$2f$schema$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["insertGenerationSchema"].parse(data);
        const [generation] = await db.insert(__TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$shared$2f$schema$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generations"]).values(validated).returning();
        return generation;
    }
    async updateGeneration(id, data) {
        const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$coze$2d$coding$2d$dev$2d$sdk$40$0$2e$5$2e$0_$40$types$2b$pg$40$8$2e$16$2e$0_openai$40$6$2e$15$2e$0_ws$40$8$2e$19$2e$0_zod$40$4$2e$2$2e$1_$5f$ws$40$8$2e$19$2e$0$2f$node_modules$2f$coze$2d$coding$2d$dev$2d$sdk$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
        const [generation] = await db.update(__TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$shared$2f$schema$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generations"]).set(data).where((0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$expressions$2f$conditions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["eq"])(__TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$shared$2f$schema$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generations"].id, id)).returning();
        return generation || null;
    }
    /**
   * 刷新即将过期的签名 URL
   * 如果距离创建时间超过 REFRESH_THRESHOLD_SECONDS，则刷新所有签名
   */ async refreshExpiredUrls(generation) {
        const now = new Date();
        const createdAt = new Date(generation.createdAt);
        const ageInSeconds = (now.getTime() - createdAt.getTime()) / 1000;
        // 如果没有 imageKeys 或未达到刷新阈值，直接返回
        if (!generation.imageKeys || generation.imageKeys.length === 0) {
            return generation;
        }
        // 如果距离创建时间超过阈值，刷新签名
        if (ageInSeconds > REFRESH_THRESHOLD_SECONDS) {
            console.log(`刷新签名 URL，记录 ID: ${generation.id}，创建于: ${createdAt.toISOString()}`);
            try {
                const storage = new __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$coze$2d$coding$2d$dev$2d$sdk$40$0$2e$5$2e$0_$40$types$2b$pg$40$8$2e$16$2e$0_openai$40$6$2e$15$2e$0_ws$40$8$2e$19$2e$0_zod$40$4$2e$2$2e$1_$5f$ws$40$8$2e$19$2e$0$2f$node_modules$2f$coze$2d$coding$2d$dev$2d$sdk$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["S3Storage"]({
                    endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
                    bucketName: process.env.COZE_BUCKET_NAME,
                    region: "cn-beijing"
                });
                // 为每个 key 生成新的签名 URL
                const newImageUrls = await Promise.all(generation.imageKeys.map(async (key)=>{
                    return await storage.generatePresignedUrl({
                        key,
                        expireTime: STORAGE_EXPIRE_SECONDS
                    });
                }));
                // 更新数据库
                const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$coze$2d$coding$2d$dev$2d$sdk$40$0$2e$5$2e$0_$40$types$2b$pg$40$8$2e$16$2e$0_openai$40$6$2e$15$2e$0_ws$40$8$2e$19$2e$0_zod$40$4$2e$2$2e$1_$5f$ws$40$8$2e$19$2e$0$2f$node_modules$2f$coze$2d$coding$2d$dev$2d$sdk$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
                const [updated] = await db.update(__TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$shared$2f$schema$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generations"]).set({
                    imageUrls: newImageUrls
                }).where((0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$expressions$2f$conditions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["eq"])(__TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$shared$2f$schema$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generations"].id, generation.id)).returning();
                if (updated) {
                    console.log(`签名 URL 刷新成功，记录 ID: ${generation.id}`);
                    return updated;
                }
            } catch (error) {
                console.error(`刷新签名 URL 失败，记录 ID: ${generation.id}`, error);
            }
        }
        return generation;
    }
    /**
   * 获取生成记录（自动刷新即将过期的签名 URL）
   */ async getGenerations(options = {}) {
        const { type, skip = 0, limit = 100 } = options;
        const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$coze$2d$coding$2d$dev$2d$sdk$40$0$2e$5$2e$0_$40$types$2b$pg$40$8$2e$16$2e$0_openai$40$6$2e$15$2e$0_ws$40$8$2e$19$2e$0_zod$40$4$2e$2$2e$1_$5f$ws$40$8$2e$19$2e$0$2f$node_modules$2f$coze$2d$coding$2d$dev$2d$sdk$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
        const conditions = [];
        if (type !== undefined) {
            conditions.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$expressions$2f$conditions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["eq"])(__TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$shared$2f$schema$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generations"].type, type));
        }
        let results;
        if (conditions.length > 0) {
            results = await db.select().from(__TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$shared$2f$schema$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generations"]).where((0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$expressions$2f$conditions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["and"])(...conditions)).orderBy((0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$expressions$2f$select$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["desc"])(__TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$shared$2f$schema$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generations"].createdAt)).limit(limit).offset(skip);
        } else {
            results = await db.select().from(__TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$shared$2f$schema$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generations"]).orderBy((0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$expressions$2f$select$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["desc"])(__TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$shared$2f$schema$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generations"].createdAt)).limit(limit).offset(skip);
        }
        // 异步刷新即将过期的签名 URL
        // 不等待刷新结果，避免影响响应速度
        results.forEach(async (generation)=>{
            await this.refreshExpiredUrls(generation);
        });
        return results;
    }
    async getGenerationById(id) {
        const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$coze$2d$coding$2d$dev$2d$sdk$40$0$2e$5$2e$0_$40$types$2b$pg$40$8$2e$16$2e$0_openai$40$6$2e$15$2e$0_ws$40$8$2e$19$2e$0_zod$40$4$2e$2$2e$1_$5f$ws$40$8$2e$19$2e$0$2f$node_modules$2f$coze$2d$coding$2d$dev$2d$sdk$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
        const [generation] = await db.select().from(__TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$shared$2f$schema$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generations"]).where((0, __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$drizzle$2d$orm$40$0$2e$45$2e$1_$40$types$2b$pg$40$8$2e$16$2e$0_pg$40$8$2e$16$2e$3$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$expressions$2f$conditions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["eq"])(__TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$shared$2f$schema$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generations"].id, id));
        return generation || null;
    }
}
const generationManager = new GenerationManager();
}),
"[project]/workspace/projects/src/storage/database/index.ts [app-route] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$generationManager$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/src/storage/database/generationManager.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$shared$2f$schema$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/src/storage/database/shared/schema.ts [app-route] (ecmascript)");
;
;
}),
"[project]/workspace/projects/src/app/api/generations/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_$40$babel$2b$core$40$7$2e$28$2e$5_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/node_modules/.pnpm/next@16.0.10_@babel+core@7.28.5_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$index$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/workspace/projects/src/storage/database/index.ts [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$generationManager$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/workspace/projects/src/storage/database/generationManager.ts [app-route] (ecmascript)");
;
;
async function GET(request) {
    try {
        const searchParams = request.nextUrl.searchParams;
        const type = searchParams.get("type");
        const generations = await __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$src$2f$storage$2f$database$2f$generationManager$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generationManager"].getGenerations({
            type: type || undefined,
            limit: 50
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_$40$babel$2b$core$40$7$2e$28$2e$5_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            data: generations
        });
    } catch (error) {
        console.error("获取生成记录失败:", error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$workspace$2f$projects$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_$40$babel$2b$core$40$7$2e$28$2e$5_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: "获取生成记录失败"
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__628d05ec._.js.map