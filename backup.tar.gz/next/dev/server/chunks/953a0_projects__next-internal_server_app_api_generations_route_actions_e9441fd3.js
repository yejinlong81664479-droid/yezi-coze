module.exports = [
"[project]/workspace/projects/.next-internal/server/app/api/generations/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=953a0_projects__next-internal_server_app_api_generations_route_actions_e9441fd3.js.map