module.exports = [
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

//#region rolldown:runtime
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") for(var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++){
        key = keys[i];
        if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ((k)=>from[k]).bind(null, key),
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toESM = (mod, isNodeMode, target)=>(target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
        value: mod,
        enumerable: true
    }) : target, mod));
//#endregion
exports.__toESM = __toESM;
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/errors.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

//#region src/utils/errors.ts
function addLangChainErrorFields(error, lc_error_code) {
    error.lc_error_code = lc_error_code;
    error.message = `${error.message}\n\nTroubleshooting URL: https://docs.langchain.com/oss/javascript/langchain/errors/${lc_error_code}/\n`;
    return error;
}
//#endregion
exports.addLangChainErrorFields = addLangChainErrorFields; //# sourceMappingURL=errors.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/client.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const require_errors = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/errors.cjs [app-route] (ecmascript)");
const openai = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/openai@6.15.0_ws@8.19.0_zod@4.2.1/node_modules/openai/index.js [app-route] (ecmascript)"));
//#region src/utils/client.ts
function wrapOpenAIClientError(e) {
    if (!e || typeof e !== "object") return e;
    let error;
    if (e.constructor.name === openai.APIConnectionTimeoutError.name && "message" in e && typeof e.message === "string") {
        error = new Error(e.message);
        error.name = "TimeoutError";
    } else if (e.constructor.name === openai.APIUserAbortError.name && "message" in e && typeof e.message === "string") {
        error = new Error(e.message);
        error.name = "AbortError";
    } else if ("status" in e && e.status === 400 && "message" in e && typeof e.message === "string" && e.message.includes("tool_calls")) error = require_errors.addLangChainErrorFields(e, "INVALID_TOOL_RESULTS");
    else if ("status" in e && e.status === 401) error = require_errors.addLangChainErrorFields(e, "MODEL_AUTHENTICATION");
    else if ("status" in e && e.status === 429) error = require_errors.addLangChainErrorFields(e, "MODEL_RATE_LIMIT");
    else if ("status" in e && e.status === 404) error = require_errors.addLangChainErrorFields(e, "MODEL_NOT_FOUND");
    else error = e;
    return error;
}
//#endregion
exports.wrapOpenAIClientError = wrapOpenAIClientError; //# sourceMappingURL=client.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/misc.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const __langchain_core_messages = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/messages/index.cjs [app-route] (ecmascript)"));
//#region src/utils/misc.ts
const iife = (fn)=>fn();
function isReasoningModel(model) {
    if (!model) return false;
    if (/^o\d/.test(model ?? "")) return true;
    if (model.startsWith("gpt-5") && !model.startsWith("gpt-5-chat")) return true;
    return false;
}
function extractGenericMessageCustomRole(message) {
    if (message.role !== "system" && message.role !== "developer" && message.role !== "assistant" && message.role !== "user" && message.role !== "function" && message.role !== "tool") console.warn(`Unknown message role: ${message.role}`);
    return message.role;
}
function getRequiredFilenameFromMetadata(block) {
    const filename = block.metadata?.filename ?? block.metadata?.name ?? block.metadata?.title;
    if (!filename) throw new Error("a filename or name or title is needed via meta-data for OpenAI when working with multimodal blocks");
    return filename;
}
function messageToOpenAIRole(message) {
    const type = message._getType();
    switch(type){
        case "system":
            return "system";
        case "ai":
            return "assistant";
        case "human":
            return "user";
        case "function":
            return "function";
        case "tool":
            return "tool";
        case "generic":
            if (!__langchain_core_messages.ChatMessage.isInstance(message)) throw new Error("Invalid generic chat message");
            return extractGenericMessageCustomRole(message);
        default:
            throw new Error(`Unknown message type: ${type}`);
    }
}
function _modelPrefersResponsesAPI(model) {
    return model.includes("gpt-5.2-pro");
}
//#endregion
exports._modelPrefersResponsesAPI = _modelPrefersResponsesAPI;
exports.getRequiredFilenameFromMetadata = getRequiredFilenameFromMetadata;
exports.iife = iife;
exports.isReasoningModel = isReasoningModel;
exports.messageToOpenAIRole = messageToOpenAIRole; //# sourceMappingURL=misc.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/azure.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const require_misc = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/misc.cjs [app-route] (ecmascript)");
const __langchain_core_utils_env = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/env.cjs [app-route] (ecmascript)"));
//#region src/utils/azure.ts
/**
* This function generates an endpoint URL for (Azure) OpenAI
* based on the configuration parameters provided.
*
* @param {OpenAIEndpointConfig} config - The configuration object for the (Azure) endpoint.
*
* @property {string} config.azureOpenAIApiDeploymentName - The deployment name of Azure OpenAI.
* @property {string} config.azureOpenAIApiInstanceName - The instance name of Azure OpenAI, e.g. `example-resource`.
* @property {string} config.azureOpenAIApiKey - The API Key for Azure OpenAI.
* @property {string} config.azureOpenAIBasePath - The base path for Azure OpenAI, e.g. `https://example-resource.azure.openai.com/openai/deployments/`.
* @property {string} config.baseURL - Some other custom base path URL.
* @property {string} config.azureOpenAIEndpoint - The endpoint for the Azure OpenAI instance, e.g. `https://example-resource.azure.openai.com/`.
*
* The function operates as follows:
* - If both `azureOpenAIBasePath` and `azureOpenAIApiDeploymentName` (plus `azureOpenAIApiKey`) are provided, it returns an URL combining these two parameters (`${azureOpenAIBasePath}/${azureOpenAIApiDeploymentName}`).
* - If both `azureOpenAIEndpoint` and `azureOpenAIApiDeploymentName` (plus `azureOpenAIApiKey`) are provided, it returns an URL combining these two parameters (`${azureOpenAIEndpoint}/openai/deployments/${azureOpenAIApiDeploymentName}`).
* - If `azureOpenAIApiKey` is provided, it checks for `azureOpenAIApiInstanceName` and `azureOpenAIApiDeploymentName` and throws an error if any of these is missing. If both are provided, it generates an URL incorporating these parameters.
* - If none of the above conditions are met, return any custom `baseURL`.
* - The function returns the generated URL as a string, or undefined if no custom paths are specified.
*
* @throws Will throw an error if the necessary parameters for generating the URL are missing.
*
* @returns {string | undefined} The generated (Azure) OpenAI endpoint URL.
*/ function getEndpoint(config) {
    const { azureOpenAIApiDeploymentName, azureOpenAIApiInstanceName, azureOpenAIApiKey, azureOpenAIBasePath, baseURL, azureADTokenProvider, azureOpenAIEndpoint } = config;
    if ((azureOpenAIApiKey || azureADTokenProvider) && azureOpenAIBasePath && azureOpenAIApiDeploymentName) return `${azureOpenAIBasePath}/${azureOpenAIApiDeploymentName}`;
    if ((azureOpenAIApiKey || azureADTokenProvider) && azureOpenAIEndpoint && azureOpenAIApiDeploymentName) return `${azureOpenAIEndpoint}/openai/deployments/${azureOpenAIApiDeploymentName}`;
    if (azureOpenAIApiKey || azureADTokenProvider) {
        if (!azureOpenAIApiInstanceName) throw new Error("azureOpenAIApiInstanceName is required when using azureOpenAIApiKey");
        if (!azureOpenAIApiDeploymentName) throw new Error("azureOpenAIApiDeploymentName is a required parameter when using azureOpenAIApiKey");
        return `https://${azureOpenAIApiInstanceName}.openai.azure.com/openai/deployments/${azureOpenAIApiDeploymentName}`;
    }
    return baseURL;
}
function isHeaders(headers) {
    return typeof Headers !== "undefined" && headers !== null && typeof headers === "object" && Object.prototype.toString.call(headers) === "[object Headers]";
}
/**
* Normalizes various header formats into a consistent Record format.
*
* This function accepts headers in multiple formats and converts them to a
* Record<string, HeaderValue | readonly HeaderValue[]> for consistent handling.
*
* @param headers - The headers to normalize. Can be:
*   - A Headers instance
*   - An array of [key, value] pairs
*   - A plain object with string keys
*   - A NullableHeaders-like object with a 'values' property containing Headers
*   - null or undefined
* @returns A normalized Record containing the header key-value pairs
*
* @example
* ```ts
* // With Headers instance
* const headers1 = new Headers([['content-type', 'application/json']]);
* const normalized1 = normalizeHeaders(headers1);
*
* // With plain object
* const headers2 = { 'content-type': 'application/json' };
* const normalized2 = normalizeHeaders(headers2);
*
* // With array of pairs
* const headers3 = [['content-type', 'application/json']];
* const normalized3 = normalizeHeaders(headers3);
* ```
*/ function normalizeHeaders(headers) {
    const output = require_misc.iife(()=>{
        if (isHeaders(headers)) return headers;
        else if (Array.isArray(headers)) return new Headers(headers);
        else if (typeof headers === "object" && headers !== null && "values" in headers && isHeaders(headers.values)) return headers.values;
        else if (typeof headers === "object" && headers !== null) {
            const entries = Object.entries(headers).filter(([, v])=>typeof v === "string").map(([k, v])=>[
                    k,
                    v
                ]);
            return new Headers(entries);
        }
        return new Headers();
    });
    return Object.fromEntries(output.entries());
}
function getFormattedEnv() {
    let env = (0, __langchain_core_utils_env.getEnv)();
    if (env === "node" || env === "deno") env = `(${env}/${process.version}; ${process.platform}; ${process.arch})`;
    return env;
}
function getHeadersWithUserAgent(headers, isAzure = false, version = "1.0.0") {
    const normalizedHeaders = normalizeHeaders(headers);
    const env = getFormattedEnv();
    const library = `langchainjs${isAzure ? "-azure" : ""}-openai`;
    return {
        ...normalizedHeaders,
        "User-Agent": normalizedHeaders["User-Agent"] ? `${library}/${version} (${env})${normalizedHeaders["User-Agent"]}` : `${library}/${version} (${env})`
    };
}
//#endregion
exports.getEndpoint = getEndpoint;
exports.getFormattedEnv = getFormattedEnv;
exports.getHeadersWithUserAgent = getHeadersWithUserAgent;
exports.isHeaders = isHeaders;
exports.normalizeHeaders = normalizeHeaders; //# sourceMappingURL=azure.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/tools.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const __langchain_core_utils_function_calling = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/function_calling.cjs [app-route] (ecmascript)"));
const __langchain_core_utils_types = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/types/index.cjs [app-route] (ecmascript)"));
const __langchain_core_utils_json_schema = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/json_schema.cjs [app-route] (ecmascript)"));
//#region src/utils/tools.ts
/**
* Formats a tool in either OpenAI format, or LangChain structured tool format
* into an OpenAI tool format. If the tool is already in OpenAI format, return without
* any changes. If it is in LangChain structured tool format, convert it to OpenAI tool format
* using OpenAI's `zodFunction` util, falling back to `convertToOpenAIFunction` if the parameters
* returned from the `zodFunction` util are not defined.
*
* @param {BindToolsInput} tool The tool to convert to an OpenAI tool.
* @param {Object} [fields] Additional fields to add to the OpenAI tool.
* @returns {ToolDefinition} The inputted tool in OpenAI tool format.
*/ function _convertToOpenAITool(tool, fields) {
    let toolDef;
    if ((0, __langchain_core_utils_function_calling.isLangChainTool)(tool)) toolDef = (0, __langchain_core_utils_function_calling.convertToOpenAITool)(tool);
    else toolDef = tool;
    if (fields?.strict !== void 0) toolDef.function.strict = fields.strict;
    return toolDef;
}
function isAnyOfProp(prop) {
    return prop.anyOf !== void 0 && Array.isArray(prop.anyOf);
}
function formatFunctionDefinitions(functions) {
    const lines = [
        "namespace functions {",
        ""
    ];
    for (const f of functions){
        if (f.description) lines.push(`// ${f.description}`);
        if (Object.keys(f.parameters.properties ?? {}).length > 0) {
            lines.push(`type ${f.name} = (_: {`);
            lines.push(formatObjectProperties(f.parameters, 0));
            lines.push("}) => any;");
        } else lines.push(`type ${f.name} = () => any;`);
        lines.push("");
    }
    lines.push("} // namespace functions");
    return lines.join("\n");
}
function formatObjectProperties(obj, indent) {
    const lines = [];
    for (const [name, param] of Object.entries(obj.properties ?? {})){
        if (param.description && indent < 2) lines.push(`// ${param.description}`);
        if (obj.required?.includes(name)) lines.push(`${name}: ${formatType(param, indent)},`);
        else lines.push(`${name}?: ${formatType(param, indent)},`);
    }
    return lines.map((line)=>" ".repeat(indent) + line).join("\n");
}
function formatType(param, indent) {
    if (isAnyOfProp(param)) return param.anyOf.map((v)=>formatType(v, indent)).join(" | ");
    switch(param.type){
        case "string":
            if (param.enum) return param.enum.map((v)=>`"${v}"`).join(" | ");
            return "string";
        case "number":
            if (param.enum) return param.enum.map((v)=>`${v}`).join(" | ");
            return "number";
        case "integer":
            if (param.enum) return param.enum.map((v)=>`${v}`).join(" | ");
            return "number";
        case "boolean":
            return "boolean";
        case "null":
            return "null";
        case "object":
            return [
                "{",
                formatObjectProperties(param, indent + 2),
                "}"
            ].join("\n");
        case "array":
            if (param.items) return `${formatType(param.items, indent)}[]`;
            return "any[]";
        default:
            return "";
    }
}
function formatToOpenAIToolChoice(toolChoice) {
    if (!toolChoice) return void 0;
    else if (toolChoice === "any" || toolChoice === "required") return "required";
    else if (toolChoice === "auto") return "auto";
    else if (toolChoice === "none") return "none";
    else if (typeof toolChoice === "string") return {
        type: "function",
        function: {
            name: toolChoice
        }
    };
    else return toolChoice;
}
function isBuiltInTool(tool) {
    return "type" in tool && tool.type !== "function";
}
/**
* Checks if a tool has a provider-specific tool definition in extras.providerToolDefinition.
* This is used for tools like localShell, shell, computerUse, and applyPatch
* that need to be sent as built-in tool types to the OpenAI API.
*/ function hasProviderToolDefinition(tool) {
    return typeof tool === "object" && tool !== null && "extras" in tool && typeof tool.extras === "object" && tool.extras !== null && "providerToolDefinition" in tool.extras && typeof tool.extras.providerToolDefinition === "object" && tool.extras.providerToolDefinition !== null;
}
function isBuiltInToolChoice(tool_choice) {
    return tool_choice != null && typeof tool_choice === "object" && "type" in tool_choice && tool_choice.type !== "function";
}
function isCustomTool(tool) {
    return typeof tool === "object" && tool !== null && "metadata" in tool && typeof tool.metadata === "object" && tool.metadata !== null && "customTool" in tool.metadata && typeof tool.metadata.customTool === "object" && tool.metadata.customTool !== null;
}
function isOpenAICustomTool(tool) {
    return "type" in tool && tool.type === "custom" && "custom" in tool && typeof tool.custom === "object" && tool.custom !== null;
}
function parseCustomToolCall(rawToolCall) {
    if (rawToolCall.type !== "custom_tool_call") return void 0;
    return {
        ...rawToolCall,
        type: "tool_call",
        call_id: rawToolCall.id,
        id: rawToolCall.call_id,
        name: rawToolCall.name,
        isCustomTool: true,
        args: {
            input: rawToolCall.input
        }
    };
}
/**
* Parses a computer_call output item from the OpenAI Responses API
* into a ToolCall format that can be processed by the ToolNode.
*
* @param rawToolCall - The raw computer_call output item from the API
* @returns A ComputerToolCall object if valid, undefined otherwise
*/ function parseComputerCall(rawToolCall) {
    if (rawToolCall.type !== "computer_call") return void 0;
    return {
        ...rawToolCall,
        type: "tool_call",
        call_id: rawToolCall.id,
        id: rawToolCall.call_id,
        name: "computer_use",
        isComputerTool: true,
        args: {
            action: rawToolCall.action
        }
    };
}
/**
* Checks if a tool call is a computer tool call.
* @param toolCall - The tool call to check.
* @returns True if the tool call is a computer tool call, false otherwise.
*/ function isComputerToolCall(toolCall) {
    return typeof toolCall === "object" && toolCall !== null && "type" in toolCall && toolCall.type === "tool_call" && "isComputerTool" in toolCall && toolCall.isComputerTool === true;
}
function isCustomToolCall(toolCall) {
    return typeof toolCall === "object" && toolCall !== null && "type" in toolCall && toolCall.type === "tool_call" && "isCustomTool" in toolCall && toolCall.isCustomTool === true;
}
function convertCompletionsCustomTool(tool) {
    const getFormat = ()=>{
        if (!tool.custom.format) return void 0;
        if (tool.custom.format.type === "grammar") return {
            type: "grammar",
            definition: tool.custom.format.grammar.definition,
            syntax: tool.custom.format.grammar.syntax
        };
        if (tool.custom.format.type === "text") return {
            type: "text"
        };
        return void 0;
    };
    return {
        type: "custom",
        name: tool.custom.name,
        description: tool.custom.description,
        format: getFormat()
    };
}
function convertResponsesCustomTool(tool) {
    const getFormat = ()=>{
        if (!tool.format) return void 0;
        if (tool.format.type === "grammar") return {
            type: "grammar",
            grammar: {
                definition: tool.format.definition,
                syntax: tool.format.syntax
            }
        };
        if (tool.format.type === "text") return {
            type: "text"
        };
        return void 0;
    };
    return {
        type: "custom",
        custom: {
            name: tool.name,
            description: tool.description,
            format: getFormat()
        }
    };
}
//#endregion
exports._convertToOpenAITool = _convertToOpenAITool;
exports.convertCompletionsCustomTool = convertCompletionsCustomTool;
exports.convertResponsesCustomTool = convertResponsesCustomTool;
exports.formatFunctionDefinitions = formatFunctionDefinitions;
exports.formatToOpenAIToolChoice = formatToOpenAIToolChoice;
exports.hasProviderToolDefinition = hasProviderToolDefinition;
exports.isBuiltInTool = isBuiltInTool;
exports.isBuiltInToolChoice = isBuiltInToolChoice;
exports.isComputerToolCall = isComputerToolCall;
exports.isCustomTool = isCustomTool;
exports.isCustomToolCall = isCustomToolCall;
exports.isOpenAICustomTool = isOpenAICustomTool;
exports.parseComputerCall = parseComputerCall;
exports.parseCustomToolCall = parseCustomToolCall; //# sourceMappingURL=tools.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/output.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const __langchain_core_utils_types = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/types/index.cjs [app-route] (ecmascript)"));
const __langchain_core_utils_json_schema = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/json_schema.cjs [app-route] (ecmascript)"));
const zod_v4_core = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/zod@4.2.1/node_modules/zod/v4/core/index.cjs [app-route] (ecmascript)"));
const openai_helpers_zod = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/openai@6.15.0_ws@8.19.0_zod@4.2.1/node_modules/openai/helpers/zod.js [app-route] (ecmascript)"));
//#region src/utils/output.ts
const SUPPORTED_METHODS = [
    "jsonSchema",
    "functionCalling",
    "jsonMode"
];
/**
* Get the structured output method for a given model. By default, it uses
* `jsonSchema` if the model supports it, otherwise it uses `functionCalling`.
*
* @throws if the method is invalid, e.g. is not a string or invalid method is provided.
* @param model - The model name.
* @param config - The structured output method options.
* @returns The structured output method.
*/ function getStructuredOutputMethod(model, method) {
    /**
	* If a method is provided, validate it.
	*/ if (typeof method !== "undefined" && !SUPPORTED_METHODS.includes(method)) throw new Error(`Invalid method: ${method}. Supported methods are: ${SUPPORTED_METHODS.join(", ")}`);
    const hasSupportForJsonSchema = !model.startsWith("gpt-3") && !model.startsWith("gpt-4-") && model !== "gpt-4";
    /**
	* If the model supports JSON Schema, use it by default.
	*/ if (hasSupportForJsonSchema && !method) return "jsonSchema";
    if (!hasSupportForJsonSchema && method === "jsonSchema") throw new Error(`JSON Schema is not supported for model "${model}". Please use a different method, e.g. "functionCalling" or "jsonMode".`);
    /**
	* If the model does not support JSON Schema, use function calling by default.
	*/ return method ?? "functionCalling";
}
function makeParseableResponseFormat(response_format, parser) {
    const obj = {
        ...response_format
    };
    Object.defineProperties(obj, {
        $brand: {
            value: "auto-parseable-response-format",
            enumerable: false
        },
        $parseRaw: {
            value: parser,
            enumerable: false
        }
    });
    return obj;
}
function interopZodResponseFormat(zodSchema, name, props) {
    if ((0, __langchain_core_utils_types.isZodSchemaV3)(zodSchema)) return (0, openai_helpers_zod.zodResponseFormat)(zodSchema, name, props);
    if ((0, __langchain_core_utils_types.isZodSchemaV4)(zodSchema)) return makeParseableResponseFormat({
        type: "json_schema",
        json_schema: {
            ...props,
            name,
            strict: true,
            schema: (0, __langchain_core_utils_json_schema.toJsonSchema)(zodSchema, {
                cycles: "ref",
                reused: "ref",
                override (ctx) {
                    ctx.jsonSchema.title = name;
                }
            })
        }
    }, (content)=>(0, zod_v4_core.parse)(zodSchema, JSON.parse(content)));
    throw new Error("Unsupported schema response format");
}
/**
* Handle multi modal response content.
*
* @param content The content of the message.
* @param messages The messages of the response.
* @returns The new content of the message.
*/ function handleMultiModalOutput(content, messages) {
    /**
	* Handle OpenRouter image responses
	* @see https://openrouter.ai/docs/features/multimodal/image-generation#api-usage
	*/ if (messages && typeof messages === "object" && "images" in messages && Array.isArray(messages.images)) {
        const images = messages.images.filter((image)=>typeof image?.image_url?.url === "string").map((image)=>({
                type: "image",
                url: image.image_url.url
            }));
        return [
            {
                type: "text",
                text: content
            },
            ...images
        ];
    }
    return content;
}
//#endregion
exports.getStructuredOutputMethod = getStructuredOutputMethod;
exports.handleMultiModalOutput = handleMultiModalOutput;
exports.interopZodResponseFormat = interopZodResponseFormat; //# sourceMappingURL=output.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/profiles.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

//#region src/chat_models/profiles.ts
const PROFILES = {
    "gpt-4.1-nano": {
        maxInputTokens: 1047576,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 32768,
        reasoningOutput: false,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "text-embedding-3-small": {
        maxInputTokens: 8191,
        imageInputs: false,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 1536,
        reasoningOutput: false,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: false,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "gpt-4": {
        maxInputTokens: 8192,
        imageInputs: false,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 8192,
        reasoningOutput: false,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "o1-pro": {
        maxInputTokens: 2e5,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 1e5,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "gpt-4o-2024-05-13": {
        maxInputTokens: 128e3,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 4096,
        reasoningOutput: false,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "gpt-4o-2024-08-06": {
        maxInputTokens: 128e3,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 16384,
        reasoningOutput: false,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "gpt-4.1-mini": {
        maxInputTokens: 1047576,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 32768,
        reasoningOutput: false,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "o3-deep-research": {
        maxInputTokens: 2e5,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 1e5,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "gpt-3.5-turbo": {
        maxInputTokens: 16385,
        imageInputs: false,
        audioInputs: false,
        pdfInputs: false,
        videoInputs: false,
        maxOutputTokens: 4096,
        reasoningOutput: false,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: false,
        structuredOutput: false,
        imageUrlInputs: false,
        pdfToolMessage: false,
        imageToolMessage: false,
        toolChoice: true
    },
    "text-embedding-3-large": {
        maxInputTokens: 8191,
        imageInputs: false,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 3072,
        reasoningOutput: false,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: false,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "gpt-4-turbo": {
        maxInputTokens: 128e3,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 4096,
        reasoningOutput: false,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "o1-preview": {
        maxInputTokens: 128e3,
        imageInputs: false,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 32768,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: false,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "o3-mini": {
        maxInputTokens: 2e5,
        imageInputs: false,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 1e5,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "codex-mini-latest": {
        maxInputTokens: 2e5,
        imageInputs: false,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 1e5,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "gpt-5-nano": {
        maxInputTokens: 4e5,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 128e3,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "gpt-5-codex": {
        maxInputTokens: 4e5,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 128e3,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "gpt-4o": {
        maxInputTokens: 128e3,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 16384,
        reasoningOutput: false,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "gpt-4.1": {
        maxInputTokens: 1047576,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 32768,
        reasoningOutput: false,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "o4-mini": {
        maxInputTokens: 2e5,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 1e5,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    o1: {
        maxInputTokens: 2e5,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 1e5,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "gpt-5-mini": {
        maxInputTokens: 4e5,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 128e3,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "o1-mini": {
        maxInputTokens: 128e3,
        imageInputs: false,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 65536,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: false,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "text-embedding-ada-002": {
        maxInputTokens: 8192,
        imageInputs: false,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 1536,
        reasoningOutput: false,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: false,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "o3-pro": {
        maxInputTokens: 2e5,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 1e5,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "gpt-4o-2024-11-20": {
        maxInputTokens: 128e3,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 16384,
        reasoningOutput: false,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    o3: {
        maxInputTokens: 2e5,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 1e5,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "o4-mini-deep-research": {
        maxInputTokens: 2e5,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 1e5,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "gpt-5-chat-latest": {
        maxInputTokens: 4e5,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 128e3,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: false,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "gpt-4o-mini": {
        maxInputTokens: 128e3,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 16384,
        reasoningOutput: false,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "gpt-5": {
        maxInputTokens: 4e5,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 128e3,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    },
    "gpt-5-pro": {
        maxInputTokens: 4e5,
        imageInputs: true,
        audioInputs: false,
        pdfInputs: true,
        videoInputs: false,
        maxOutputTokens: 272e3,
        reasoningOutput: true,
        imageOutputs: false,
        audioOutputs: false,
        videoOutputs: false,
        toolCalling: true,
        structuredOutput: true,
        imageUrlInputs: true,
        pdfToolMessage: true,
        imageToolMessage: true,
        toolChoice: true
    }
};
var profiles_default = PROFILES;
//#endregion
exports.default = profiles_default; //# sourceMappingURL=profiles.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/base.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const require_client = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/client.cjs [app-route] (ecmascript)");
const require_tools = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/tools.cjs [app-route] (ecmascript)");
const require_misc = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/misc.cjs [app-route] (ecmascript)");
const require_azure = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/azure.cjs [app-route] (ecmascript)");
const require_output = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/output.cjs [app-route] (ecmascript)");
const require_profiles = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/profiles.cjs [app-route] (ecmascript)");
const openai = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/openai@6.15.0_ws@8.19.0_zod@4.2.1/node_modules/openai/index.js [app-route] (ecmascript)"));
const __langchain_core_utils_types = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/types/index.cjs [app-route] (ecmascript)"));
const __langchain_core_utils_json_schema = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/json_schema.cjs [app-route] (ecmascript)"));
const __langchain_core_utils_env = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/env.cjs [app-route] (ecmascript)"));
const __langchain_core_language_models_chat_models = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/language_models/chat_models.cjs [app-route] (ecmascript)"));
const __langchain_core_language_models_base = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/language_models/base.cjs [app-route] (ecmascript)"));
const __langchain_core_runnables = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/runnables/index.cjs [app-route] (ecmascript)"));
const __langchain_core_output_parsers = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/output_parsers/index.cjs [app-route] (ecmascript)"));
const __langchain_core_output_parsers_openai_tools = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/output_parsers/openai_tools/index.cjs [app-route] (ecmascript)"));
//#region src/chat_models/base.ts
/** @internal */ var BaseChatOpenAI = class extends __langchain_core_language_models_chat_models.BaseChatModel {
    temperature;
    topP;
    frequencyPenalty;
    presencePenalty;
    n;
    logitBias;
    model = "gpt-3.5-turbo";
    modelKwargs;
    stop;
    stopSequences;
    user;
    timeout;
    streaming = false;
    streamUsage = true;
    maxTokens;
    logprobs;
    topLogprobs;
    apiKey;
    organization;
    __includeRawResponse;
    /** @internal */ client;
    /** @internal */ clientConfig;
    /**
	* Whether the model supports the `strict` argument when passing in tools.
	* If `undefined` the `strict` argument will not be passed to OpenAI.
	*/ supportsStrictToolCalling;
    audio;
    modalities;
    reasoning;
    /**
	* Must be set to `true` in tenancies with Zero Data Retention. Setting to `true` will disable
	* output storage in the Responses API, but this DOES NOT enable Zero Data Retention in your
	* OpenAI organization or project. This must be configured directly with OpenAI.
	*
	* See:
	* https://platform.openai.com/docs/guides/your-data
	* https://platform.openai.com/docs/api-reference/responses/create#responses-create-store
	*
	* @default false
	*/ zdrEnabled;
    /**
	* Service tier to use for this request. Can be "auto", "default", or "flex" or "priority".
	* Specifies the service tier for prioritization and latency optimization.
	*/ service_tier;
    /**
	* Used by OpenAI to cache responses for similar requests to optimize your cache
	* hit rates.
	* [Learn more](https://platform.openai.com/docs/guides/prompt-caching).
	*/ promptCacheKey;
    /**
	* Used by OpenAI to set cache retention time
	*/ promptCacheRetention;
    /**
	* The verbosity of the model's response.
	*/ verbosity;
    defaultOptions;
    _llmType() {
        return "openai";
    }
    static lc_name() {
        return "ChatOpenAI";
    }
    get callKeys() {
        return [
            ...super.callKeys,
            "options",
            "function_call",
            "functions",
            "tools",
            "tool_choice",
            "promptIndex",
            "response_format",
            "seed",
            "reasoning",
            "service_tier"
        ];
    }
    lc_serializable = true;
    get lc_secrets() {
        return {
            apiKey: "OPENAI_API_KEY",
            organization: "OPENAI_ORGANIZATION"
        };
    }
    get lc_aliases() {
        return {
            apiKey: "openai_api_key",
            modelName: "model"
        };
    }
    get lc_serializable_keys() {
        return [
            "configuration",
            "logprobs",
            "topLogprobs",
            "prefixMessages",
            "supportsStrictToolCalling",
            "modalities",
            "audio",
            "temperature",
            "maxTokens",
            "topP",
            "frequencyPenalty",
            "presencePenalty",
            "n",
            "logitBias",
            "user",
            "streaming",
            "streamUsage",
            "model",
            "modelName",
            "modelKwargs",
            "stop",
            "stopSequences",
            "timeout",
            "apiKey",
            "cache",
            "maxConcurrency",
            "maxRetries",
            "verbose",
            "callbacks",
            "tags",
            "metadata",
            "disableStreaming",
            "zdrEnabled",
            "reasoning",
            "promptCacheKey",
            "promptCacheRetention",
            "verbosity"
        ];
    }
    getLsParams(options) {
        const params = this.invocationParams(options);
        return {
            ls_provider: "openai",
            ls_model_name: this.model,
            ls_model_type: "chat",
            ls_temperature: params.temperature ?? void 0,
            ls_max_tokens: params.max_tokens ?? void 0,
            ls_stop: options.stop
        };
    }
    /** @ignore */ _identifyingParams() {
        return {
            model_name: this.model,
            ...this.invocationParams(),
            ...this.clientConfig
        };
    }
    /**
	* Get the identifying parameters for the model
	*/ identifyingParams() {
        return this._identifyingParams();
    }
    constructor(fields){
        super(fields ?? {});
        const configApiKey = typeof fields?.configuration?.apiKey === "string" || typeof fields?.configuration?.apiKey === "function" ? fields?.configuration?.apiKey : void 0;
        this.apiKey = fields?.apiKey ?? configApiKey ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("OPENAI_API_KEY");
        this.organization = fields?.configuration?.organization ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("OPENAI_ORGANIZATION");
        this.model = fields?.model ?? fields?.modelName ?? this.model;
        this.modelKwargs = fields?.modelKwargs ?? {};
        this.timeout = fields?.timeout;
        this.temperature = fields?.temperature ?? this.temperature;
        this.topP = fields?.topP ?? this.topP;
        this.frequencyPenalty = fields?.frequencyPenalty ?? this.frequencyPenalty;
        this.presencePenalty = fields?.presencePenalty ?? this.presencePenalty;
        this.logprobs = fields?.logprobs;
        this.topLogprobs = fields?.topLogprobs;
        this.n = fields?.n ?? this.n;
        this.logitBias = fields?.logitBias;
        this.stop = fields?.stopSequences ?? fields?.stop;
        this.stopSequences = this.stop;
        this.user = fields?.user;
        this.__includeRawResponse = fields?.__includeRawResponse;
        this.audio = fields?.audio;
        this.modalities = fields?.modalities;
        this.reasoning = fields?.reasoning;
        this.maxTokens = fields?.maxCompletionTokens ?? fields?.maxTokens;
        this.promptCacheKey = fields?.promptCacheKey ?? this.promptCacheKey;
        this.promptCacheRetention = fields?.promptCacheRetention ?? this.promptCacheRetention;
        this.verbosity = fields?.verbosity ?? this.verbosity;
        this.disableStreaming = fields?.disableStreaming === true;
        this.streaming = fields?.streaming === true;
        if (this.disableStreaming) this.streaming = false;
        if (fields?.streaming === false) this.disableStreaming = true;
        this.streamUsage = fields?.streamUsage ?? this.streamUsage;
        if (this.disableStreaming) this.streamUsage = false;
        this.clientConfig = {
            apiKey: this.apiKey,
            organization: this.organization,
            dangerouslyAllowBrowser: true,
            ...fields?.configuration
        };
        if (fields?.supportsStrictToolCalling !== void 0) this.supportsStrictToolCalling = fields.supportsStrictToolCalling;
        if (fields?.service_tier !== void 0) this.service_tier = fields.service_tier;
        this.zdrEnabled = fields?.zdrEnabled ?? false;
    }
    /**
	* Returns backwards compatible reasoning parameters from constructor params and call options
	* @internal
	*/ _getReasoningParams(options) {
        if (!require_misc.isReasoningModel(this.model)) return;
        let reasoning;
        if (this.reasoning !== void 0) reasoning = {
            ...reasoning,
            ...this.reasoning
        };
        if (options?.reasoning !== void 0) reasoning = {
            ...reasoning,
            ...options.reasoning
        };
        return reasoning;
    }
    /**
	* Returns an openai compatible response format from a set of options
	* @internal
	*/ _getResponseFormat(resFormat) {
        if (resFormat && resFormat.type === "json_schema" && resFormat.json_schema.schema && (0, __langchain_core_utils_types.isInteropZodSchema)(resFormat.json_schema.schema)) return require_output.interopZodResponseFormat(resFormat.json_schema.schema, resFormat.json_schema.name, {
            description: resFormat.json_schema.description
        });
        return resFormat;
    }
    _combineCallOptions(additionalOptions) {
        return {
            ...this.defaultOptions,
            ...additionalOptions ?? {}
        };
    }
    /** @internal */ _getClientOptions(options) {
        if (!this.client) {
            const openAIEndpointConfig = {
                baseURL: this.clientConfig.baseURL
            };
            const endpoint = require_azure.getEndpoint(openAIEndpointConfig);
            const params = {
                ...this.clientConfig,
                baseURL: endpoint,
                timeout: this.timeout,
                maxRetries: 0
            };
            if (!params.baseURL) delete params.baseURL;
            params.defaultHeaders = require_azure.getHeadersWithUserAgent(params.defaultHeaders);
            this.client = new openai.OpenAI(params);
        }
        const requestOptions = {
            ...this.clientConfig,
            ...options
        };
        return requestOptions;
    }
    _convertChatOpenAIToolToCompletionsTool(tool, fields) {
        if (require_tools.isCustomTool(tool)) return require_tools.convertResponsesCustomTool(tool.metadata.customTool);
        if ((0, __langchain_core_language_models_base.isOpenAITool)(tool)) {
            if (fields?.strict !== void 0) return {
                ...tool,
                function: {
                    ...tool.function,
                    strict: fields.strict
                }
            };
            return tool;
        }
        return require_tools._convertToOpenAITool(tool, fields);
    }
    bindTools(tools, kwargs) {
        let strict;
        if (kwargs?.strict !== void 0) strict = kwargs.strict;
        else if (this.supportsStrictToolCalling !== void 0) strict = this.supportsStrictToolCalling;
        return this.withConfig({
            tools: tools.map((tool)=>{
                if (require_tools.isBuiltInTool(tool) || require_tools.isCustomTool(tool)) return tool;
                if (require_tools.hasProviderToolDefinition(tool)) return tool.extras.providerToolDefinition;
                return this._convertChatOpenAIToolToCompletionsTool(tool, {
                    strict
                });
            }),
            ...kwargs
        });
    }
    async stream(input, options) {
        return super.stream(input, this._combineCallOptions(options));
    }
    async invoke(input, options) {
        return super.invoke(input, this._combineCallOptions(options));
    }
    /** @ignore */ _combineLLMOutput(...llmOutputs) {
        return llmOutputs.reduce((acc, llmOutput)=>{
            if (llmOutput && llmOutput.tokenUsage) {
                acc.tokenUsage.completionTokens += llmOutput.tokenUsage.completionTokens ?? 0;
                acc.tokenUsage.promptTokens += llmOutput.tokenUsage.promptTokens ?? 0;
                acc.tokenUsage.totalTokens += llmOutput.tokenUsage.totalTokens ?? 0;
            }
            return acc;
        }, {
            tokenUsage: {
                completionTokens: 0,
                promptTokens: 0,
                totalTokens: 0
            }
        });
    }
    async getNumTokensFromMessages(messages) {
        let totalCount = 0;
        let tokensPerMessage = 0;
        let tokensPerName = 0;
        if (this.model === "gpt-3.5-turbo-0301") {
            tokensPerMessage = 4;
            tokensPerName = -1;
        } else {
            tokensPerMessage = 3;
            tokensPerName = 1;
        }
        const countPerMessage = await Promise.all(messages.map(async (message)=>{
            const textCount = await this.getNumTokens(message.content);
            const roleCount = await this.getNumTokens(require_misc.messageToOpenAIRole(message));
            const nameCount = message.name !== void 0 ? tokensPerName + await this.getNumTokens(message.name) : 0;
            let count = textCount + tokensPerMessage + roleCount + nameCount;
            const openAIMessage = message;
            if (openAIMessage._getType() === "function") count -= 2;
            if (openAIMessage.additional_kwargs?.function_call) count += 3;
            if (openAIMessage?.additional_kwargs.function_call?.name) count += await this.getNumTokens(openAIMessage.additional_kwargs.function_call?.name);
            if (openAIMessage.additional_kwargs.function_call?.arguments) try {
                count += await this.getNumTokens(JSON.stringify(JSON.parse(openAIMessage.additional_kwargs.function_call?.arguments)));
            } catch (error) {
                console.error("Error parsing function arguments", error, JSON.stringify(openAIMessage.additional_kwargs.function_call));
                count += await this.getNumTokens(openAIMessage.additional_kwargs.function_call?.arguments);
            }
            totalCount += count;
            return count;
        }));
        totalCount += 3;
        return {
            totalCount,
            countPerMessage
        };
    }
    /** @internal */ async _getNumTokensFromGenerations(generations) {
        const generationUsages = await Promise.all(generations.map(async (generation)=>{
            if (generation.message.additional_kwargs?.function_call) return (await this.getNumTokensFromMessages([
                generation.message
            ])).countPerMessage[0];
            else return await this.getNumTokens(generation.message.content);
        }));
        return generationUsages.reduce((a, b)=>a + b, 0);
    }
    /** @internal */ async _getEstimatedTokenCountFromPrompt(messages, functions, function_call) {
        let tokens = (await this.getNumTokensFromMessages(messages)).totalCount;
        if (functions && function_call !== "auto") {
            const promptDefinitions = require_tools.formatFunctionDefinitions(functions);
            tokens += await this.getNumTokens(promptDefinitions);
            tokens += 9;
        }
        if (functions && messages.find((m)=>m._getType() === "system")) tokens -= 4;
        if (function_call === "none") tokens += 1;
        else if (typeof function_call === "object") tokens += await this.getNumTokens(function_call.name) + 4;
        return tokens;
    }
    /**
	* Moderate content using OpenAI's Moderation API.
	*
	* This method checks whether content violates OpenAI's content policy by
	* analyzing text for categories such as hate, harassment, self-harm,
	* sexual content, violence, and more.
	*
	* @param input - The text or array of texts to moderate
	* @param params - Optional parameters for the moderation request
	* @param params.model - The moderation model to use. Defaults to "omni-moderation-latest".
	* @param params.options - Additional options to pass to the underlying request
	* @returns A promise that resolves to the moderation response containing results for each input
	*
	* @example
	* ```typescript
	* const model = new ChatOpenAI({ model: "gpt-4o-mini" });
	*
	* // Moderate a single text
	* const result = await model.moderateContent("This is a test message");
	* console.log(result.results[0].flagged); // false
	* console.log(result.results[0].categories); // { hate: false, harassment: false, ... }
	*
	* // Moderate multiple texts
	* const results = await model.moderateContent([
	*   "Hello, how are you?",
	*   "This is inappropriate content"
	* ]);
	* results.results.forEach((result, index) => {
	*   console.log(`Text ${index + 1} flagged:`, result.flagged);
	* });
	*
	* // Use a specific moderation model
	* const stableResult = await model.moderateContent(
	*   "Test content",
	*   { model: "omni-moderation-latest" }
	* );
	* ```
	*/ async moderateContent(input, params) {
        const clientOptions = this._getClientOptions(params?.options);
        const moderationModel = params?.model ?? "omni-moderation-latest";
        const moderationRequest = {
            input,
            model: moderationModel
        };
        return this.caller.call(async ()=>{
            try {
                const response = await this.client.moderations.create(moderationRequest, clientOptions);
                return response;
            } catch (e) {
                const error = require_client.wrapOpenAIClientError(e);
                throw error;
            }
        });
    }
    /**
	* Return profiling information for the model.
	*
	* Provides information about the model's capabilities and constraints,
	* including token limits, multimodal support, and advanced features like
	* tool calling and structured output.
	*
	* @returns {ModelProfile} An object describing the model's capabilities and constraints
	*
	* @example
	* ```typescript
	* const model = new ChatOpenAI({ model: "gpt-4o" });
	* const profile = model.profile;
	* console.log(profile.maxInputTokens); // 128000
	* console.log(profile.imageInputs); // true
	* ```
	*/ get profile() {
        return require_profiles.default[this.model] ?? {};
    }
    /** @internal */ _getStructuredOutputMethod(config) {
        const ensuredConfig = {
            ...config
        };
        if (!this.model.startsWith("gpt-3") && !this.model.startsWith("gpt-4-") && this.model !== "gpt-4") {
            if (ensuredConfig?.method === void 0) return "jsonSchema";
        } else if (ensuredConfig.method === "jsonSchema") console.warn(`[WARNING]: JSON Schema is not supported for model "${this.model}". Falling back to tool calling.`);
        return ensuredConfig.method;
    }
    /**
	* Add structured output to the model.
	*
	* The OpenAI model family supports the following structured output methods:
	* - `jsonSchema`: Use the `response_format` field in the response to return a JSON schema. Only supported with the `gpt-4o-mini`,
	*   `gpt-4o-mini-2024-07-18`, and `gpt-4o-2024-08-06` model snapshots and later.
	* - `functionCalling`: Function calling is useful when you are building an application that bridges the models and functionality
	*   of your application.
	* - `jsonMode`: JSON mode is a more basic version of the Structured Outputs feature. While JSON mode ensures that model
	*   output is valid JSON, Structured Outputs reliably matches the model's output to the schema you specify.
	*   We recommend you use `functionCalling` or `jsonSchema` if it is supported for your use case.
	*
	* The default method is `functionCalling`.
	*
	* @see https://platform.openai.com/docs/guides/structured-outputs
	* @param outputSchema - The schema to use for structured output.
	* @param config - The structured output method options.
	* @returns The model with structured output.
	*/ withStructuredOutput(outputSchema, config) {
        let llm;
        let outputParser;
        const { schema, name, includeRaw } = {
            ...config,
            schema: outputSchema
        };
        if (config?.strict !== void 0 && config.method === "jsonMode") throw new Error("Argument `strict` is only supported for `method` = 'function_calling'");
        const method = require_output.getStructuredOutputMethod(this.model, config?.method);
        if (method === "jsonMode") {
            if ((0, __langchain_core_utils_types.isInteropZodSchema)(schema)) outputParser = __langchain_core_output_parsers.StructuredOutputParser.fromZodSchema(schema);
            else outputParser = new __langchain_core_output_parsers.JsonOutputParser();
            const asJsonSchema = (0, __langchain_core_utils_json_schema.toJsonSchema)(schema);
            llm = this.withConfig({
                outputVersion: "v0",
                response_format: {
                    type: "json_object"
                },
                ls_structured_output_format: {
                    kwargs: {
                        method: "json_mode"
                    },
                    schema: {
                        title: name ?? "extract",
                        ...asJsonSchema
                    }
                }
            });
        } else if (method === "jsonSchema") {
            const openaiJsonSchemaParams = {
                name: name ?? "extract",
                description: (0, __langchain_core_utils_types.getSchemaDescription)(schema),
                schema,
                strict: config?.strict
            };
            const asJsonSchema = (0, __langchain_core_utils_json_schema.toJsonSchema)(openaiJsonSchemaParams.schema);
            llm = this.withConfig({
                outputVersion: "v0",
                response_format: {
                    type: "json_schema",
                    json_schema: openaiJsonSchemaParams
                },
                ls_structured_output_format: {
                    kwargs: {
                        method: "json_schema"
                    },
                    schema: {
                        title: openaiJsonSchemaParams.name,
                        description: openaiJsonSchemaParams.description,
                        ...asJsonSchema
                    }
                }
            });
            if ((0, __langchain_core_utils_types.isInteropZodSchema)(schema)) {
                const altParser = __langchain_core_output_parsers.StructuredOutputParser.fromZodSchema(schema);
                outputParser = __langchain_core_runnables.RunnableLambda.from((aiMessage)=>{
                    if ("parsed" in aiMessage.additional_kwargs) return aiMessage.additional_kwargs.parsed;
                    return altParser;
                });
            } else outputParser = new __langchain_core_output_parsers.JsonOutputParser();
        } else {
            let functionName = name ?? "extract";
            if ((0, __langchain_core_utils_types.isInteropZodSchema)(schema)) {
                const asJsonSchema = (0, __langchain_core_utils_json_schema.toJsonSchema)(schema);
                llm = this.withConfig({
                    outputVersion: "v0",
                    tools: [
                        {
                            type: "function",
                            function: {
                                name: functionName,
                                description: asJsonSchema.description,
                                parameters: asJsonSchema
                            }
                        }
                    ],
                    tool_choice: {
                        type: "function",
                        function: {
                            name: functionName
                        }
                    },
                    ls_structured_output_format: {
                        kwargs: {
                            method: "function_calling"
                        },
                        schema: {
                            title: functionName,
                            ...asJsonSchema
                        }
                    },
                    ...config?.strict !== void 0 ? {
                        strict: config.strict
                    } : {}
                });
                outputParser = new __langchain_core_output_parsers_openai_tools.JsonOutputKeyToolsParser({
                    returnSingle: true,
                    keyName: functionName,
                    zodSchema: schema
                });
            } else {
                let openAIFunctionDefinition;
                if (typeof schema.name === "string" && typeof schema.parameters === "object" && schema.parameters != null) {
                    openAIFunctionDefinition = schema;
                    functionName = schema.name;
                } else {
                    functionName = schema.title ?? functionName;
                    openAIFunctionDefinition = {
                        name: functionName,
                        description: schema.description ?? "",
                        parameters: schema
                    };
                }
                const asJsonSchema = (0, __langchain_core_utils_json_schema.toJsonSchema)(schema);
                llm = this.withConfig({
                    outputVersion: "v0",
                    tools: [
                        {
                            type: "function",
                            function: openAIFunctionDefinition
                        }
                    ],
                    tool_choice: {
                        type: "function",
                        function: {
                            name: functionName
                        }
                    },
                    ls_structured_output_format: {
                        kwargs: {
                            method: "function_calling"
                        },
                        schema: {
                            title: functionName,
                            ...asJsonSchema
                        }
                    },
                    ...config?.strict !== void 0 ? {
                        strict: config.strict
                    } : {}
                });
                outputParser = new __langchain_core_output_parsers_openai_tools.JsonOutputKeyToolsParser({
                    returnSingle: true,
                    keyName: functionName
                });
            }
        }
        if (!includeRaw) return llm.pipe(outputParser);
        const parserAssign = __langchain_core_runnables.RunnablePassthrough.assign({
            parsed: (input, config$1)=>outputParser.invoke(input.raw, config$1)
        });
        const parserNone = __langchain_core_runnables.RunnablePassthrough.assign({
            parsed: ()=>null
        });
        const parsedWithFallback = parserAssign.withFallbacks({
            fallbacks: [
                parserNone
            ]
        });
        return __langchain_core_runnables.RunnableSequence.from([
            {
                raw: llm
            },
            parsedWithFallback
        ]);
    }
};
//#endregion
exports.BaseChatOpenAI = BaseChatOpenAI; //# sourceMappingURL=base.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/converters/completions.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const require_misc = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/misc.cjs [app-route] (ecmascript)");
const require_output = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/output.cjs [app-route] (ecmascript)");
const __langchain_core_messages = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/messages/index.cjs [app-route] (ecmascript)"));
const __langchain_core_output_parsers_openai_tools = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/output_parsers/openai_tools/index.cjs [app-route] (ecmascript)"));
//#region src/converters/completions.ts
/**
* @deprecated This converter is an internal detail of the OpenAI provider. Do not use it directly. This will be revisited in a future release.
*/ const completionsApiContentBlockConverter = {
    providerName: "ChatOpenAI",
    fromStandardTextBlock (block) {
        return {
            type: "text",
            text: block.text
        };
    },
    fromStandardImageBlock (block) {
        if (block.source_type === "url") return {
            type: "image_url",
            image_url: {
                url: block.url,
                ...block.metadata?.detail ? {
                    detail: block.metadata.detail
                } : {}
            }
        };
        if (block.source_type === "base64") {
            const url = `data:${block.mime_type ?? ""};base64,${block.data}`;
            return {
                type: "image_url",
                image_url: {
                    url,
                    ...block.metadata?.detail ? {
                        detail: block.metadata.detail
                    } : {}
                }
            };
        }
        throw new Error(`Image content blocks with source_type ${block.source_type} are not supported for ChatOpenAI`);
    },
    fromStandardAudioBlock (block) {
        if (block.source_type === "url") {
            const data = (0, __langchain_core_messages.parseBase64DataUrl)({
                dataUrl: block.url
            });
            if (!data) throw new Error(`URL audio blocks with source_type ${block.source_type} must be formatted as a data URL for ChatOpenAI`);
            const rawMimeType = data.mime_type || block.mime_type || "";
            let mimeType;
            try {
                mimeType = (0, __langchain_core_messages.parseMimeType)(rawMimeType);
            } catch  {
                throw new Error(`Audio blocks with source_type ${block.source_type} must have mime type of audio/wav or audio/mp3`);
            }
            if (mimeType.type !== "audio" || mimeType.subtype !== "wav" && mimeType.subtype !== "mp3") throw new Error(`Audio blocks with source_type ${block.source_type} must have mime type of audio/wav or audio/mp3`);
            return {
                type: "input_audio",
                input_audio: {
                    format: mimeType.subtype,
                    data: data.data
                }
            };
        }
        if (block.source_type === "base64") {
            let mimeType;
            try {
                mimeType = (0, __langchain_core_messages.parseMimeType)(block.mime_type ?? "");
            } catch  {
                throw new Error(`Audio blocks with source_type ${block.source_type} must have mime type of audio/wav or audio/mp3`);
            }
            if (mimeType.type !== "audio" || mimeType.subtype !== "wav" && mimeType.subtype !== "mp3") throw new Error(`Audio blocks with source_type ${block.source_type} must have mime type of audio/wav or audio/mp3`);
            return {
                type: "input_audio",
                input_audio: {
                    format: mimeType.subtype,
                    data: block.data
                }
            };
        }
        throw new Error(`Audio content blocks with source_type ${block.source_type} are not supported for ChatOpenAI`);
    },
    fromStandardFileBlock (block) {
        if (block.source_type === "url") {
            const data = (0, __langchain_core_messages.parseBase64DataUrl)({
                dataUrl: block.url
            });
            const filename = require_misc.getRequiredFilenameFromMetadata(block);
            if (!data) throw new Error(`URL file blocks with source_type ${block.source_type} must be formatted as a data URL for ChatOpenAI`);
            return {
                type: "file",
                file: {
                    file_data: block.url,
                    ...block.metadata?.filename || block.metadata?.name ? {
                        filename
                    } : {}
                }
            };
        }
        if (block.source_type === "base64") {
            const filename = require_misc.getRequiredFilenameFromMetadata(block);
            return {
                type: "file",
                file: {
                    file_data: `data:${block.mime_type ?? ""};base64,${block.data}`,
                    ...block.metadata?.filename || block.metadata?.name || block.metadata?.title ? {
                        filename
                    } : {}
                }
            };
        }
        if (block.source_type === "id") return {
            type: "file",
            file: {
                file_id: block.id
            }
        };
        throw new Error(`File content blocks with source_type ${block.source_type} are not supported for ChatOpenAI`);
    }
};
/**
* Converts an OpenAI Chat Completions API message to a LangChain BaseMessage.
*
* This converter transforms messages from OpenAI's Chat Completions API format into
* LangChain's internal message representation, handling various message types and
* preserving metadata, tool calls, and other relevant information.
*
* @remarks
* The converter handles the following message roles:
* - `assistant`: Converted to {@link AIMessage} with support for tool calls, function calls,
*   audio content, and multi-modal outputs
* - Other roles: Converted to generic {@link ChatMessage}
*
* For assistant messages, the converter:
* - Parses and validates tool calls, separating valid and invalid calls
* - Preserves function call information in additional_kwargs
* - Includes usage statistics and system fingerprint in response_metadata
* - Handles multi-modal content (text, images, audio)
* - Optionally includes the raw API response for debugging
*
* @param params - Conversion parameters
* @param params.message - The OpenAI chat completion message to convert
* @param params.rawResponse - The complete raw response from OpenAI's API, used to extract
*   metadata like model name, usage statistics, and system fingerprint
* @param params.includeRawResponse - If true, includes the raw OpenAI response in the
*   message's additional_kwargs under the `__raw_response` key. Useful for debugging
*   or accessing provider-specific fields. Defaults to false.
*
* @returns A LangChain BaseMessage instance:
*   - {@link AIMessage} for assistant messages with tool calls, metadata, and content
*   - {@link ChatMessage} for all other message types
*
* @example
* ```typescript
* const baseMessage = convertCompletionsMessageToBaseMessage({
*   message: {
*     role: "assistant",
*     content: "Hello! How can I help you?",
*     tool_calls: [
*       {
*         id: "call_123",
*         type: "function",
*         function: { name: "get_weather", arguments: '{"location":"NYC"}' }
*       }
*     ]
*   },
*   rawResponse: completionResponse,
*   includeRawResponse: true
* });
* // Returns an AIMessage with parsed tool calls and metadata
* ```
*
* @throws {Error} If tool call parsing fails, the invalid tool call is captured in
*   the `invalid_tool_calls` array rather than throwing an error
*
*/ const convertCompletionsMessageToBaseMessage = ({ message, rawResponse, includeRawResponse })=>{
    const rawToolCalls = message.tool_calls;
    switch(message.role){
        case "assistant":
            {
                const toolCalls = [];
                const invalidToolCalls = [];
                for (const rawToolCall of rawToolCalls ?? [])try {
                    toolCalls.push((0, __langchain_core_output_parsers_openai_tools.parseToolCall)(rawToolCall, {
                        returnId: true
                    }));
                } catch (e) {
                    invalidToolCalls.push((0, __langchain_core_output_parsers_openai_tools.makeInvalidToolCall)(rawToolCall, e.message));
                }
                const additional_kwargs = {
                    function_call: message.function_call,
                    tool_calls: rawToolCalls
                };
                if (includeRawResponse !== void 0) additional_kwargs.__raw_response = rawResponse;
                const response_metadata = {
                    model_provider: "openai",
                    model_name: rawResponse.model,
                    ...rawResponse.system_fingerprint ? {
                        usage: {
                            ...rawResponse.usage
                        },
                        system_fingerprint: rawResponse.system_fingerprint
                    } : {}
                };
                if (message.audio) additional_kwargs.audio = message.audio;
                const content = require_output.handleMultiModalOutput(message.content || "", rawResponse.choices?.[0]?.message);
                return new __langchain_core_messages.AIMessage({
                    content,
                    tool_calls: toolCalls,
                    invalid_tool_calls: invalidToolCalls,
                    additional_kwargs,
                    response_metadata,
                    id: rawResponse.id
                });
            }
        default:
            return new __langchain_core_messages.ChatMessage(message.content || "", message.role ?? "unknown");
    }
};
/**
* Converts an OpenAI Chat Completions API delta (streaming chunk) to a LangChain BaseMessageChunk.
*
* This converter is used during streaming responses to transform incremental updates from OpenAI's
* Chat Completions API into LangChain message chunks. It handles various message types, tool calls,
* function calls, audio content, and role-specific message chunk creation.
*
* @param params - Conversion parameters
* @param params.delta - The delta object from an OpenAI streaming chunk containing incremental
*   message updates. May include content, role, tool_calls, function_call, audio, etc.
* @param params.rawResponse - The complete raw ChatCompletionChunk response from OpenAI,
*   containing metadata like model info, usage stats, and the delta
* @param params.includeRawResponse - Optional flag to include the raw OpenAI response in the
*   message chunk's additional_kwargs. Useful for debugging or accessing provider-specific data
* @param params.defaultRole - Optional default role to use if the delta doesn't specify one.
*   Typically used to maintain role consistency across chunks in a streaming response
*
* @returns A BaseMessageChunk subclass appropriate for the message role:
*   - HumanMessageChunk for "user" role
*   - AIMessageChunk for "assistant" role (includes tool call chunks)
*   - SystemMessageChunk for "system" or "developer" roles
*   - FunctionMessageChunk for "function" role
*   - ToolMessageChunk for "tool" role
*   - ChatMessageChunk for any other role
*
* @example
* Basic streaming text chunk:
* ```typescript
* const chunk = convertCompletionsDeltaToBaseMessageChunk({
*   delta: { role: "assistant", content: "Hello" },
*   rawResponse: { id: "chatcmpl-123", model: "gpt-4", ... }
* });
* // Returns: AIMessageChunk with content "Hello"
* ```
*
* @example
* Streaming chunk with tool call:
* ```typescript
* const chunk = convertCompletionsDeltaToBaseMessageChunk({
*   delta: {
*     role: "assistant",
*     tool_calls: [{
*       index: 0,
*       id: "call_123",
*       function: { name: "get_weather", arguments: '{"location":' }
*     }]
*   },
*   rawResponse: { id: "chatcmpl-123", ... }
* });
* // Returns: AIMessageChunk with tool_call_chunks containing partial tool call data
* ```
*
* @remarks
* - Tool calls are converted to ToolCallChunk objects with incremental data
* - Audio content includes the chunk index from the raw response
* - The "developer" role is mapped to SystemMessageChunk with a special marker
* - Response metadata includes model provider info and usage statistics
* - Function calls and tool calls are stored in additional_kwargs for compatibility
*/ const convertCompletionsDeltaToBaseMessageChunk = ({ delta, rawResponse, includeRawResponse, defaultRole })=>{
    const role = delta.role ?? defaultRole;
    const content = delta.content ?? "";
    let additional_kwargs;
    if (delta.function_call) additional_kwargs = {
        function_call: delta.function_call
    };
    else if (delta.tool_calls) additional_kwargs = {
        tool_calls: delta.tool_calls
    };
    else additional_kwargs = {};
    if (includeRawResponse) additional_kwargs.__raw_response = rawResponse;
    if (delta.audio) additional_kwargs.audio = {
        ...delta.audio,
        index: rawResponse.choices[0].index
    };
    const response_metadata = {
        model_provider: "openai",
        usage: {
            ...rawResponse.usage
        }
    };
    if (role === "user") return new __langchain_core_messages.HumanMessageChunk({
        content,
        response_metadata
    });
    else if (role === "assistant") {
        const toolCallChunks = [];
        if (Array.isArray(delta.tool_calls)) for (const rawToolCall of delta.tool_calls)toolCallChunks.push({
            name: rawToolCall.function?.name,
            args: rawToolCall.function?.arguments,
            id: rawToolCall.id,
            index: rawToolCall.index,
            type: "tool_call_chunk"
        });
        return new __langchain_core_messages.AIMessageChunk({
            content,
            tool_call_chunks: toolCallChunks,
            additional_kwargs,
            id: rawResponse.id,
            response_metadata
        });
    } else if (role === "system") return new __langchain_core_messages.SystemMessageChunk({
        content,
        response_metadata
    });
    else if (role === "developer") return new __langchain_core_messages.SystemMessageChunk({
        content,
        response_metadata,
        additional_kwargs: {
            __openai_role__: "developer"
        }
    });
    else if (role === "function") return new __langchain_core_messages.FunctionMessageChunk({
        content,
        additional_kwargs,
        name: delta.name,
        response_metadata
    });
    else if (role === "tool") return new __langchain_core_messages.ToolMessageChunk({
        content,
        additional_kwargs,
        tool_call_id: delta.tool_call_id,
        response_metadata
    });
    else return new __langchain_core_messages.ChatMessageChunk({
        content,
        role,
        response_metadata
    });
};
/**
* Converts a standard LangChain content block to an OpenAI Completions API content part.
*
* This converter transforms LangChain's standardized content blocks (image, audio, file)
* into the format expected by OpenAI's Chat Completions API. It handles various content
* types including images (URL or base64), audio (base64), and files (data or file ID).
*
* @param block - The standard content block to convert. Can be an image, audio, or file block.
*
* @returns An OpenAI Chat Completions content part object, or undefined if the block
*   cannot be converted (e.g., missing required data).
*
* @example
* Image with URL:
* ```typescript
* const block = { type: "image", url: "https://example.com/image.jpg" };
* const part = convertStandardContentBlockToCompletionsContentPart(block);
* // Returns: { type: "image_url", image_url: { url: "https://example.com/image.jpg" } }
* ```
*
* @example
* Image with base64 data:
* ```typescript
* const block = { type: "image", data: "iVBORw0KGgo...", mimeType: "image/png" };
* const part = convertStandardContentBlockToCompletionsContentPart(block);
* // Returns: { type: "image_url", image_url: { url: "data:image/png;base64,iVBORw0KGgo..." } }
* ```
*/ const convertStandardContentBlockToCompletionsContentPart = (block)=>{
    if (block.type === "image") {
        if (block.url) return {
            type: "image_url",
            image_url: {
                url: block.url
            }
        };
        else if (block.data) return {
            type: "image_url",
            image_url: {
                url: `data:${block.mimeType};base64,${block.data}`
            }
        };
    }
    if (block.type === "audio") {
        if (block.data) {
            const format = (0, __langchain_core_messages.iife)(()=>{
                const [, format$1] = block.mimeType.split("/");
                if (format$1 === "wav" || format$1 === "mp3") return format$1;
                return "wav";
            });
            return {
                type: "input_audio",
                input_audio: {
                    data: block.data.toString(),
                    format
                }
            };
        }
    }
    if (block.type === "file") {
        if (block.data) {
            const filename = require_misc.getRequiredFilenameFromMetadata(block);
            return {
                type: "file",
                file: {
                    file_data: `data:${block.mimeType};base64,${block.data}`,
                    filename
                }
            };
        }
        if (block.fileId) return {
            type: "file",
            file: {
                file_id: block.fileId
            }
        };
    }
    return void 0;
};
/**
* Converts a LangChain BaseMessage with standard content blocks to an OpenAI Chat Completions API message parameter.
*
* This converter transforms LangChain's standardized message format (using contentBlocks) into the format
* expected by OpenAI's Chat Completions API. It handles role mapping, content filtering, and multi-modal
* content conversion for various message types.
*
* @remarks
* The converter performs the following transformations:
* - Maps LangChain message roles to OpenAI API roles (user, assistant, system, developer, tool, function)
* - For reasoning models, automatically converts "system" role to "developer" role
* - Filters content blocks based on message role (most roles only include text blocks)
* - For user messages, converts multi-modal content blocks (images, audio, files) to OpenAI format
* - Preserves tool call IDs for tool messages and function names for function messages
*
* Role-specific behavior:
* - **developer**: Returns only text content blocks (used for reasoning models)
* - **system**: Returns only text content blocks
* - **assistant**: Returns only text content blocks
* - **tool**: Returns only text content blocks with tool_call_id preserved
* - **function**: Returns text content blocks joined as a single string with function name
* - **user** (default): Returns multi-modal content including text, images, audio, and files
*
* @param params - Conversion parameters
* @param params.message - The LangChain BaseMessage to convert. Must have contentBlocks property
*   containing an array of standard content blocks (text, image, audio, file, etc.)
* @param params.model - Optional model name. Used to determine if special role mapping is needed
*   (e.g., "system" -> "developer" for reasoning models like o1)
*
* @returns An OpenAI ChatCompletionMessageParam object formatted for the Chat Completions API.
*   The structure varies by role:
*   - Developer/System/Assistant: `{ role, content: TextBlock[] }`
*   - Tool: `{ role: "tool", tool_call_id, content: TextBlock[] }`
*   - Function: `{ role: "function", name, content: string }`
*   - User: `{ role: "user", content: Array<TextPart | ImagePart | AudioPart | FilePart> }`
*
* @example
* Simple text message:
* ```typescript
* const message = new HumanMessage({
*   content: [{ type: "text", text: "Hello!" }]
* });
* const param = convertStandardContentMessageToCompletionsMessage({ message });
* // Returns: { role: "user", content: [{ type: "text", text: "Hello!" }] }
* ```
*
* @example
* Multi-modal user message with image:
* ```typescript
* const message = new HumanMessage({
*   content: [
*     { type: "text", text: "What's in this image?" },
*     { type: "image", url: "https://example.com/image.jpg" }
*   ]
* });
* const param = convertStandardContentMessageToCompletionsMessage({ message });
* // Returns: {
* //   role: "user",
* //   content: [
* //     { type: "text", text: "What's in this image?" },
* //     { type: "image_url", image_url: { url: "https://example.com/image.jpg" } }
* //   ]
* // }
* ```
*/ const convertStandardContentMessageToCompletionsMessage = ({ message, model })=>{
    let role = require_misc.messageToOpenAIRole(message);
    if (role === "system" && require_misc.isReasoningModel(model)) role = "developer";
    if (role === "developer") return {
        role: "developer",
        content: message.contentBlocks.filter((block)=>block.type === "text")
    };
    else if (role === "system") return {
        role: "system",
        content: message.contentBlocks.filter((block)=>block.type === "text")
    };
    else if (role === "assistant") return {
        role: "assistant",
        content: message.contentBlocks.filter((block)=>block.type === "text")
    };
    else if (role === "tool" && __langchain_core_messages.ToolMessage.isInstance(message)) return {
        role: "tool",
        tool_call_id: message.tool_call_id,
        content: message.contentBlocks.filter((block)=>block.type === "text")
    };
    else if (role === "function") return {
        role: "function",
        name: message.name ?? "",
        content: message.contentBlocks.filter((block)=>block.type === "text").join("")
    };
    function* iterateUserContent(blocks) {
        for (const block of blocks){
            if (block.type === "text") yield {
                type: "text",
                text: block.text
            };
            const data = convertStandardContentBlockToCompletionsContentPart(block);
            if (data) yield data;
        }
    }
    return {
        role: "user",
        content: Array.from(iterateUserContent(message.contentBlocks))
    };
};
/**
* Converts an array of LangChain BaseMessages to OpenAI Chat Completions API message parameters.
*
* This converter transforms LangChain's internal message representation into the format required
* by OpenAI's Chat Completions API. It handles various message types, roles, content formats,
* tool calls, function calls, audio messages, and special model-specific requirements.
*
* @remarks
* The converter performs several key transformations:
* - Maps LangChain message types to OpenAI roles (user, assistant, system, tool, function, developer)
* - Converts standard content blocks (v1 format) using a specialized converter
* - Handles multimodal content including text, images, audio, and data blocks
* - Preserves tool calls and function calls with proper formatting
* - Applies model-specific role mappings (e.g., "system" → "developer" for reasoning models)
* - Splits audio messages into separate message parameters when needed
*
* @param params - Conversion parameters
* @param params.messages - Array of LangChain BaseMessages to convert. Can include any message
*   type: HumanMessage, AIMessage, SystemMessage, ToolMessage, FunctionMessage, etc.
* @param params.model - Optional model name used to determine if special role mapping is needed.
*   For reasoning models (o1, o3, etc.), "system" role is converted to "developer" role.
*
* @returns Array of ChatCompletionMessageParam objects formatted for OpenAI's Chat Completions API.
*   Some messages may be split into multiple parameters (e.g., audio messages).
*
* @example
* Basic message conversion:
* ```typescript
* const messages = [
*   new HumanMessage("What's the weather like?"),
*   new AIMessage("Let me check that for you.")
* ];
*
* const params = convertMessagesToCompletionsMessageParams({
*   messages,
*   model: "gpt-4"
* });
* // Returns:
* // [
* //   { role: "user", content: "What's the weather like?" },
* //   { role: "assistant", content: "Let me check that for you." }
* // ]
* ```
*
* @example
* Message with tool calls:
* ```typescript
* const messages = [
*   new AIMessage({
*     content: "",
*     tool_calls: [{
*       id: "call_123",
*       name: "get_weather",
*       args: { location: "San Francisco" }
*     }]
*   })
* ];
*
* const params = convertMessagesToCompletionsMessageParams({ messages });
* // Returns:
* // [{
* //   role: "assistant",
* //   content: "",
* //   tool_calls: [{
* //     id: "call_123",
* //     type: "function",
* //     function: { name: "get_weather", arguments: '{"location":"San Francisco"}' }
* //   }]
* // }]
* ```
*/ const convertMessagesToCompletionsMessageParams = ({ messages, model })=>{
    return messages.flatMap((message)=>{
        if ("output_version" in message.response_metadata && message.response_metadata?.output_version === "v1") return convertStandardContentMessageToCompletionsMessage({
            message
        });
        let role = require_misc.messageToOpenAIRole(message);
        if (role === "system" && require_misc.isReasoningModel(model)) role = "developer";
        const content = typeof message.content === "string" ? message.content : message.content.map((m)=>{
            if ((0, __langchain_core_messages.isDataContentBlock)(m)) return (0, __langchain_core_messages.convertToProviderContentBlock)(m, completionsApiContentBlockConverter);
            return m;
        });
        const completionParam = {
            role,
            content
        };
        if (message.name != null) completionParam.name = message.name;
        if (message.additional_kwargs.function_call != null) completionParam.function_call = message.additional_kwargs.function_call;
        if (__langchain_core_messages.AIMessage.isInstance(message) && !!message.tool_calls?.length) completionParam.tool_calls = message.tool_calls.map(__langchain_core_output_parsers_openai_tools.convertLangChainToolCallToOpenAI);
        else {
            if (message.additional_kwargs.tool_calls != null) completionParam.tool_calls = message.additional_kwargs.tool_calls;
            if (__langchain_core_messages.ToolMessage.isInstance(message) && message.tool_call_id != null) completionParam.tool_call_id = message.tool_call_id;
        }
        if (message.additional_kwargs.audio && typeof message.additional_kwargs.audio === "object" && "id" in message.additional_kwargs.audio) {
            const audioMessage = {
                role: "assistant",
                audio: {
                    id: message.additional_kwargs.audio.id
                }
            };
            return [
                completionParam,
                audioMessage
            ];
        }
        return completionParam;
    });
};
//#endregion
exports.completionsApiContentBlockConverter = completionsApiContentBlockConverter;
exports.convertCompletionsDeltaToBaseMessageChunk = convertCompletionsDeltaToBaseMessageChunk;
exports.convertCompletionsMessageToBaseMessage = convertCompletionsMessageToBaseMessage;
exports.convertMessagesToCompletionsMessageParams = convertMessagesToCompletionsMessageParams;
exports.convertStandardContentBlockToCompletionsContentPart = convertStandardContentBlockToCompletionsContentPart;
exports.convertStandardContentMessageToCompletionsMessage = convertStandardContentMessageToCompletionsMessage; //# sourceMappingURL=completions.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/completions.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const require_client = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/client.cjs [app-route] (ecmascript)");
const require_tools = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/tools.cjs [app-route] (ecmascript)");
const require_misc = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/misc.cjs [app-route] (ecmascript)");
const require_base = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/base.cjs [app-route] (ecmascript)");
const require_completions = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/converters/completions.cjs [app-route] (ecmascript)");
const __langchain_core_messages = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/messages/index.cjs [app-route] (ecmascript)"));
const __langchain_core_outputs = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/outputs.cjs [app-route] (ecmascript)"));
//#region src/chat_models/completions.ts
/**
* OpenAI Completions API implementation.
* @internal
*/ var ChatOpenAICompletions = class extends require_base.BaseChatOpenAI {
    /** @internal */ invocationParams(options, extra) {
        let strict;
        if (options?.strict !== void 0) strict = options.strict;
        else if (this.supportsStrictToolCalling !== void 0) strict = this.supportsStrictToolCalling;
        let streamOptionsConfig = {};
        if (options?.stream_options !== void 0) streamOptionsConfig = {
            stream_options: options.stream_options
        };
        else if (this.streamUsage && (this.streaming || extra?.streaming)) streamOptionsConfig = {
            stream_options: {
                include_usage: true
            }
        };
        const params = {
            model: this.model,
            temperature: this.temperature,
            top_p: this.topP,
            frequency_penalty: this.frequencyPenalty,
            presence_penalty: this.presencePenalty,
            logprobs: this.logprobs,
            top_logprobs: this.topLogprobs,
            n: this.n,
            logit_bias: this.logitBias,
            stop: options?.stop ?? this.stopSequences,
            user: this.user,
            stream: this.streaming,
            functions: options?.functions,
            function_call: options?.function_call,
            tools: options?.tools?.length ? options.tools.map((tool)=>this._convertChatOpenAIToolToCompletionsTool(tool, {
                    strict
                })) : void 0,
            tool_choice: require_tools.formatToOpenAIToolChoice(options?.tool_choice),
            response_format: this._getResponseFormat(options?.response_format),
            seed: options?.seed,
            ...streamOptionsConfig,
            parallel_tool_calls: options?.parallel_tool_calls,
            ...this.audio || options?.audio ? {
                audio: this.audio || options?.audio
            } : {},
            ...this.modalities || options?.modalities ? {
                modalities: this.modalities || options?.modalities
            } : {},
            ...this.modelKwargs,
            prompt_cache_key: options?.promptCacheKey ?? this.promptCacheKey,
            prompt_cache_retention: options?.promptCacheRetention ?? this.promptCacheRetention,
            verbosity: options?.verbosity ?? this.verbosity
        };
        if (options?.prediction !== void 0) params.prediction = options.prediction;
        if (this.service_tier !== void 0) params.service_tier = this.service_tier;
        if (options?.service_tier !== void 0) params.service_tier = options.service_tier;
        const reasoning = this._getReasoningParams(options);
        if (reasoning !== void 0 && reasoning.effort !== void 0) params.reasoning_effort = reasoning.effort;
        if (require_misc.isReasoningModel(params.model)) params.max_completion_tokens = this.maxTokens === -1 ? void 0 : this.maxTokens;
        else params.max_tokens = this.maxTokens === -1 ? void 0 : this.maxTokens;
        return params;
    }
    async _generate(messages, options, runManager) {
        const usageMetadata = {};
        const params = this.invocationParams(options);
        const messagesMapped = require_completions.convertMessagesToCompletionsMessageParams({
            messages,
            model: this.model
        });
        if (params.stream) {
            const stream = this._streamResponseChunks(messages, options, runManager);
            const finalChunks = {};
            for await (const chunk of stream){
                chunk.message.response_metadata = {
                    ...chunk.generationInfo,
                    ...chunk.message.response_metadata
                };
                const index = chunk.generationInfo?.completion ?? 0;
                if (finalChunks[index] === void 0) finalChunks[index] = chunk;
                else finalChunks[index] = finalChunks[index].concat(chunk);
            }
            const generations = Object.entries(finalChunks).sort(([aKey], [bKey])=>parseInt(aKey, 10) - parseInt(bKey, 10)).map(([_, value])=>value);
            const { functions, function_call } = this.invocationParams(options);
            const promptTokenUsage = await this._getEstimatedTokenCountFromPrompt(messages, functions, function_call);
            const completionTokenUsage = await this._getNumTokensFromGenerations(generations);
            usageMetadata.input_tokens = promptTokenUsage;
            usageMetadata.output_tokens = completionTokenUsage;
            usageMetadata.total_tokens = promptTokenUsage + completionTokenUsage;
            return {
                generations,
                llmOutput: {
                    estimatedTokenUsage: {
                        promptTokens: usageMetadata.input_tokens,
                        completionTokens: usageMetadata.output_tokens,
                        totalTokens: usageMetadata.total_tokens
                    }
                }
            };
        } else {
            const data = await this.completionWithRetry({
                ...params,
                stream: false,
                messages: messagesMapped
            }, {
                signal: options?.signal,
                ...options?.options
            });
            const { completion_tokens: completionTokens, prompt_tokens: promptTokens, total_tokens: totalTokens, prompt_tokens_details: promptTokensDetails, completion_tokens_details: completionTokensDetails } = data?.usage ?? {};
            if (completionTokens) usageMetadata.output_tokens = (usageMetadata.output_tokens ?? 0) + completionTokens;
            if (promptTokens) usageMetadata.input_tokens = (usageMetadata.input_tokens ?? 0) + promptTokens;
            if (totalTokens) usageMetadata.total_tokens = (usageMetadata.total_tokens ?? 0) + totalTokens;
            if (promptTokensDetails?.audio_tokens !== null || promptTokensDetails?.cached_tokens !== null) usageMetadata.input_token_details = {
                ...promptTokensDetails?.audio_tokens !== null && {
                    audio: promptTokensDetails?.audio_tokens
                },
                ...promptTokensDetails?.cached_tokens !== null && {
                    cache_read: promptTokensDetails?.cached_tokens
                }
            };
            if (completionTokensDetails?.audio_tokens !== null || completionTokensDetails?.reasoning_tokens !== null) usageMetadata.output_token_details = {
                ...completionTokensDetails?.audio_tokens !== null && {
                    audio: completionTokensDetails?.audio_tokens
                },
                ...completionTokensDetails?.reasoning_tokens !== null && {
                    reasoning: completionTokensDetails?.reasoning_tokens
                }
            };
            const generations = [];
            for (const part of data?.choices ?? []){
                const text = part.message?.content ?? "";
                const generation = {
                    text,
                    message: this._convertCompletionsMessageToBaseMessage(part.message ?? {
                        role: "assistant"
                    }, data)
                };
                generation.generationInfo = {
                    ...part.finish_reason ? {
                        finish_reason: part.finish_reason
                    } : {},
                    ...part.logprobs ? {
                        logprobs: part.logprobs
                    } : {}
                };
                if ((0, __langchain_core_messages.isAIMessage)(generation.message)) generation.message.usage_metadata = usageMetadata;
                generation.message = new __langchain_core_messages.AIMessage(Object.fromEntries(Object.entries(generation.message).filter(([key])=>!key.startsWith("lc_"))));
                generations.push(generation);
            }
            return {
                generations,
                llmOutput: {
                    tokenUsage: {
                        promptTokens: usageMetadata.input_tokens,
                        completionTokens: usageMetadata.output_tokens,
                        totalTokens: usageMetadata.total_tokens
                    }
                }
            };
        }
    }
    async *_streamResponseChunks(messages, options, runManager) {
        const messagesMapped = require_completions.convertMessagesToCompletionsMessageParams({
            messages,
            model: this.model
        });
        const params = {
            ...this.invocationParams(options, {
                streaming: true
            }),
            messages: messagesMapped,
            stream: true
        };
        let defaultRole;
        const streamIterable = await this.completionWithRetry(params, options);
        let usage;
        for await (const data of streamIterable){
            const choice = data?.choices?.[0];
            if (data.usage) usage = data.usage;
            if (!choice) continue;
            const { delta } = choice;
            if (!delta) continue;
            const chunk = this._convertCompletionsDeltaToBaseMessageChunk(delta, data, defaultRole);
            defaultRole = delta.role ?? defaultRole;
            const newTokenIndices = {
                prompt: options.promptIndex ?? 0,
                completion: choice.index ?? 0
            };
            if (typeof chunk.content !== "string") {
                console.log("[WARNING]: Received non-string content from OpenAI. This is currently not supported.");
                continue;
            }
            const generationInfo = {
                ...newTokenIndices
            };
            if (choice.finish_reason != null) {
                generationInfo.finish_reason = choice.finish_reason;
                generationInfo.system_fingerprint = data.system_fingerprint;
                generationInfo.model_name = data.model;
                generationInfo.service_tier = data.service_tier;
            }
            if (this.logprobs) generationInfo.logprobs = choice.logprobs;
            const generationChunk = new __langchain_core_outputs.ChatGenerationChunk({
                message: chunk,
                text: chunk.content,
                generationInfo
            });
            yield generationChunk;
            await runManager?.handleLLMNewToken(generationChunk.text ?? "", newTokenIndices, void 0, void 0, void 0, {
                chunk: generationChunk
            });
        }
        if (usage) {
            const inputTokenDetails = {
                ...usage.prompt_tokens_details?.audio_tokens !== null && {
                    audio: usage.prompt_tokens_details?.audio_tokens
                },
                ...usage.prompt_tokens_details?.cached_tokens !== null && {
                    cache_read: usage.prompt_tokens_details?.cached_tokens
                }
            };
            const outputTokenDetails = {
                ...usage.completion_tokens_details?.audio_tokens !== null && {
                    audio: usage.completion_tokens_details?.audio_tokens
                },
                ...usage.completion_tokens_details?.reasoning_tokens !== null && {
                    reasoning: usage.completion_tokens_details?.reasoning_tokens
                }
            };
            const generationChunk = new __langchain_core_outputs.ChatGenerationChunk({
                message: new __langchain_core_messages.AIMessageChunk({
                    content: "",
                    response_metadata: {
                        usage: {
                            ...usage
                        }
                    },
                    usage_metadata: {
                        input_tokens: usage.prompt_tokens,
                        output_tokens: usage.completion_tokens,
                        total_tokens: usage.total_tokens,
                        ...Object.keys(inputTokenDetails).length > 0 && {
                            input_token_details: inputTokenDetails
                        },
                        ...Object.keys(outputTokenDetails).length > 0 && {
                            output_token_details: outputTokenDetails
                        }
                    }
                }),
                text: ""
            });
            yield generationChunk;
        }
        if (options.signal?.aborted) throw new Error("AbortError");
    }
    async completionWithRetry(request, requestOptions) {
        const clientOptions = this._getClientOptions(requestOptions);
        const isParseableFormat = request.response_format && request.response_format.type === "json_schema";
        return this.caller.call(async ()=>{
            try {
                if (isParseableFormat && !request.stream) return await this.client.chat.completions.parse(request, clientOptions);
                else return await this.client.chat.completions.create(request, clientOptions);
            } catch (e) {
                const error = require_client.wrapOpenAIClientError(e);
                throw error;
            }
        });
    }
    /**
	* @deprecated
	* This function was hoisted into a publicly accessible function from a
	* different export, but to maintain backwards compatibility with chat models
	* that depend on ChatOpenAICompletions, we'll keep it here as an overridable
	* method. This will be removed in a future release
	*/ _convertCompletionsDeltaToBaseMessageChunk(delta, rawResponse, defaultRole) {
        return require_completions.convertCompletionsDeltaToBaseMessageChunk({
            delta,
            rawResponse,
            includeRawResponse: this.__includeRawResponse,
            defaultRole
        });
    }
    /**
	* @deprecated
	* This function was hoisted into a publicly accessible function from a
	* different export, but to maintain backwards compatibility with chat models
	* that depend on ChatOpenAICompletions, we'll keep it here as an overridable
	* method. This will be removed in a future release
	*/ _convertCompletionsMessageToBaseMessage(message, rawResponse) {
        return require_completions.convertCompletionsMessageToBaseMessage({
            message,
            rawResponse,
            includeRawResponse: this.__includeRawResponse
        });
    }
};
//#endregion
exports.ChatOpenAICompletions = ChatOpenAICompletions; //# sourceMappingURL=completions.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/azure/chat_models/common.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const require_azure = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/azure.cjs [app-route] (ecmascript)");
const openai = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/openai@6.15.0_ws@8.19.0_zod@4.2.1/node_modules/openai/index.js [app-route] (ecmascript)"));
const __langchain_core_utils_env = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/env.cjs [app-route] (ecmascript)"));
//#region src/azure/chat_models/common.ts
const AZURE_ALIASES = {
    openAIApiKey: "openai_api_key",
    openAIApiVersion: "openai_api_version",
    openAIBasePath: "openai_api_base",
    deploymentName: "deployment_name",
    azureOpenAIEndpoint: "azure_endpoint",
    azureOpenAIApiVersion: "openai_api_version",
    azureOpenAIBasePath: "openai_api_base",
    azureOpenAIApiDeploymentName: "deployment_name"
};
const AZURE_SECRETS = {
    azureOpenAIApiKey: "AZURE_OPENAI_API_KEY"
};
const AZURE_SERIALIZABLE_KEYS = [
    "azureOpenAIApiKey",
    "azureOpenAIApiVersion",
    "azureOpenAIBasePath",
    "azureOpenAIEndpoint",
    "azureOpenAIApiInstanceName",
    "azureOpenAIApiDeploymentName",
    "deploymentName",
    "openAIApiKey",
    "openAIApiVersion"
];
function _constructAzureFields(fields) {
    this.azureOpenAIApiKey = fields?.azureOpenAIApiKey ?? (typeof fields?.openAIApiKey === "string" ? fields?.openAIApiKey : void 0) ?? (typeof fields?.apiKey === "string" ? fields?.apiKey : void 0) ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_API_KEY");
    this.azureOpenAIApiInstanceName = fields?.azureOpenAIApiInstanceName ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_API_INSTANCE_NAME");
    this.azureOpenAIApiDeploymentName = fields?.azureOpenAIApiDeploymentName ?? fields?.deploymentName ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_API_DEPLOYMENT_NAME");
    this.azureOpenAIApiVersion = fields?.azureOpenAIApiVersion ?? fields?.openAIApiVersion ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_API_VERSION");
    this.azureOpenAIBasePath = fields?.azureOpenAIBasePath ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_BASE_PATH");
    this.azureOpenAIEndpoint = fields?.azureOpenAIEndpoint ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_ENDPOINT");
    this.azureADTokenProvider = fields?.azureADTokenProvider;
    if (!this.azureOpenAIApiKey && !this.apiKey && !this.azureADTokenProvider) throw new Error("Azure OpenAI API key or Token Provider not found");
}
function _getAzureClientOptions(options) {
    if (!this.client) {
        const openAIEndpointConfig = {
            azureOpenAIApiDeploymentName: this.azureOpenAIApiDeploymentName,
            azureOpenAIApiInstanceName: this.azureOpenAIApiInstanceName,
            azureOpenAIApiKey: this.azureOpenAIApiKey,
            azureOpenAIBasePath: this.azureOpenAIBasePath,
            azureADTokenProvider: this.azureADTokenProvider,
            baseURL: this.clientConfig.baseURL,
            azureOpenAIEndpoint: this.azureOpenAIEndpoint
        };
        const endpoint = require_azure.getEndpoint(openAIEndpointConfig);
        const { apiKey: existingApiKey, ...clientConfigRest } = this.clientConfig;
        const params = {
            ...clientConfigRest,
            baseURL: endpoint,
            timeout: this.timeout,
            maxRetries: 0
        };
        if (!this.azureADTokenProvider) params.apiKey = openAIEndpointConfig.azureOpenAIApiKey;
        if (!params.baseURL) delete params.baseURL;
        params.defaultHeaders = require_azure.getHeadersWithUserAgent(params.defaultHeaders, true, "2.0.0");
        this.client = new openai.AzureOpenAI({
            apiVersion: this.azureOpenAIApiVersion,
            azureADTokenProvider: this.azureADTokenProvider,
            deployment: this.azureOpenAIApiDeploymentName,
            ...params
        });
    }
    const requestOptions = {
        ...this.clientConfig,
        ...options
    };
    if (this.azureOpenAIApiKey) {
        requestOptions.headers = {
            "api-key": this.azureOpenAIApiKey,
            ...requestOptions.headers
        };
        requestOptions.query = {
            "api-version": this.azureOpenAIApiVersion,
            ...requestOptions.query
        };
    }
    return requestOptions;
}
function _serializeAzureChat(input) {
    const json = input;
    function isRecord(obj) {
        return typeof obj === "object" && obj != null;
    }
    if (isRecord(json) && isRecord(json.kwargs)) {
        delete json.kwargs.azure_openai_base_path;
        delete json.kwargs.azure_openai_api_deployment_name;
        delete json.kwargs.azure_openai_api_key;
        delete json.kwargs.azure_openai_api_version;
        delete json.kwargs.azure_open_ai_base_path;
        if (!json.kwargs.azure_endpoint && this.azureOpenAIEndpoint) json.kwargs.azure_endpoint = this.azureOpenAIEndpoint;
        if (!json.kwargs.azure_endpoint && this.azureOpenAIBasePath) {
            const parts = this.azureOpenAIBasePath.split("/openai/deployments/");
            if (parts.length === 2 && parts[0].startsWith("http")) {
                const [endpoint] = parts;
                json.kwargs.azure_endpoint = endpoint;
            }
        }
        if (!json.kwargs.azure_endpoint && this.azureOpenAIApiInstanceName) json.kwargs.azure_endpoint = `https://${this.azureOpenAIApiInstanceName}.openai.azure.com/`;
        if (!json.kwargs.deployment_name && this.azureOpenAIApiDeploymentName) json.kwargs.deployment_name = this.azureOpenAIApiDeploymentName;
        if (!json.kwargs.deployment_name && this.azureOpenAIBasePath) {
            const parts = this.azureOpenAIBasePath.split("/openai/deployments/");
            if (parts.length === 2) {
                const [, deployment] = parts;
                json.kwargs.deployment_name = deployment;
            }
        }
        if (json.kwargs.azure_endpoint && json.kwargs.deployment_name && json.kwargs.openai_api_base) delete json.kwargs.openai_api_base;
        if (json.kwargs.azure_openai_api_instance_name && json.kwargs.azure_endpoint) delete json.kwargs.azure_openai_api_instance_name;
    }
    return json;
}
//#endregion
exports.AZURE_ALIASES = AZURE_ALIASES;
exports.AZURE_SECRETS = AZURE_SECRETS;
exports.AZURE_SERIALIZABLE_KEYS = AZURE_SERIALIZABLE_KEYS;
exports._constructAzureFields = _constructAzureFields;
exports._getAzureClientOptions = _getAzureClientOptions;
exports._serializeAzureChat = _serializeAzureChat; //# sourceMappingURL=common.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/azure/chat_models/completions.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_completions = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/completions.cjs [app-route] (ecmascript)");
const require_common = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/azure/chat_models/common.cjs [app-route] (ecmascript)");
//#region src/azure/chat_models/completions.ts
var AzureChatOpenAICompletions = class extends require_completions.ChatOpenAICompletions {
    azureOpenAIApiVersion;
    azureOpenAIApiKey;
    azureADTokenProvider;
    azureOpenAIApiInstanceName;
    azureOpenAIApiDeploymentName;
    azureOpenAIBasePath;
    azureOpenAIEndpoint;
    _llmType() {
        return "azure_openai";
    }
    get lc_aliases() {
        return {
            ...super.lc_aliases,
            ...require_common.AZURE_ALIASES
        };
    }
    get lc_secrets() {
        return {
            ...super.lc_secrets,
            ...require_common.AZURE_SECRETS
        };
    }
    get lc_serializable_keys() {
        return [
            ...super.lc_serializable_keys,
            ...require_common.AZURE_SERIALIZABLE_KEYS
        ];
    }
    getLsParams(options) {
        const params = super.getLsParams(options);
        params.ls_provider = "azure";
        return params;
    }
    constructor(fields){
        super(fields);
        require_common._constructAzureFields.call(this, fields);
    }
    _getClientOptions(options) {
        return require_common._getAzureClientOptions.call(this, options);
    }
    toJSON() {
        return require_common._serializeAzureChat.call(this, super.toJSON());
    }
};
//#endregion
exports.AzureChatOpenAICompletions = AzureChatOpenAICompletions; //# sourceMappingURL=completions.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/converters/responses.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const require_tools = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/tools.cjs [app-route] (ecmascript)");
const require_misc = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/misc.cjs [app-route] (ecmascript)");
const require_completions = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/converters/completions.cjs [app-route] (ecmascript)");
const __langchain_core_messages = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/messages/index.cjs [app-route] (ecmascript)"));
const __langchain_core_outputs = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/outputs.cjs [app-route] (ecmascript)"));
const __langchain_core_output_parsers_openai_tools = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/output_parsers/openai_tools/index.cjs [app-route] (ecmascript)"));
//#region src/converters/responses.ts
const _FUNCTION_CALL_IDS_MAP_KEY = "__openai_function_call_ids__";
/**
* Converts OpenAI Responses API usage statistics to LangChain's UsageMetadata format.
*
* This converter transforms token usage information from OpenAI's Responses API into
* the standardized UsageMetadata format used throughout LangChain. It handles both
* basic token counts and detailed token breakdowns including cached tokens and
* reasoning tokens.
*
* @param usage - The usage statistics object from OpenAI's Responses API containing
*                token counts and optional detailed breakdowns.
*
* @returns A UsageMetadata object containing:
*   - `input_tokens`: Total number of tokens in the input/prompt (defaults to 0 if not provided)
*   - `output_tokens`: Total number of tokens in the model's output (defaults to 0 if not provided)
*   - `total_tokens`: Combined total of input and output tokens (defaults to 0 if not provided)
*   - `input_token_details`: Object containing detailed input token information:
*     - `cache_read`: Number of tokens read from cache (only included if available)
*   - `output_token_details`: Object containing detailed output token information:
*     - `reasoning`: Number of tokens used for reasoning (only included if available)
*
* @example
* ```typescript
* const usage = {
*   input_tokens: 100,
*   output_tokens: 50,
*   total_tokens: 150,
*   input_tokens_details: { cached_tokens: 20 },
*   output_tokens_details: { reasoning_tokens: 10 }
* };
*
* const metadata = convertResponsesUsageToUsageMetadata(usage);
* // Returns:
* // {
* //   input_tokens: 100,
* //   output_tokens: 50,
* //   total_tokens: 150,
* //   input_token_details: { cache_read: 20 },
* //   output_token_details: { reasoning: 10 }
* // }
* ```
*
* @remarks
* - The function safely handles undefined or null values by using optional chaining
*   and nullish coalescing operators
* - Detailed token information (cache_read, reasoning) is only included in the result
*   if the corresponding values are present in the input
* - Token counts default to 0 if not provided in the usage object
* - This converter is specifically designed for OpenAI's Responses API format and
*   may differ from other OpenAI API endpoints
*/ const convertResponsesUsageToUsageMetadata = (usage)=>{
    const inputTokenDetails = {
        ...usage?.input_tokens_details?.cached_tokens != null && {
            cache_read: usage?.input_tokens_details?.cached_tokens
        }
    };
    const outputTokenDetails = {
        ...usage?.output_tokens_details?.reasoning_tokens != null && {
            reasoning: usage?.output_tokens_details?.reasoning_tokens
        }
    };
    return {
        input_tokens: usage?.input_tokens ?? 0,
        output_tokens: usage?.output_tokens ?? 0,
        total_tokens: usage?.total_tokens ?? 0,
        input_token_details: inputTokenDetails,
        output_token_details: outputTokenDetails
    };
};
/**
* Converts an OpenAI Responses API response to a LangChain AIMessage.
*
* This converter processes the output from OpenAI's Responses API (both `create` and `parse` methods)
* and transforms it into a LangChain AIMessage object with all relevant metadata, tool calls, and content.
*
* @param response - The response object from OpenAI's Responses API. Can be either:
*   - ResponsesCreateInvoke: Result from `responses.create()`
*   - ResponsesParseInvoke: Result from `responses.parse()`
*
* @returns An AIMessage containing:
*   - `id`: The message ID from the response output
*   - `content`: Array of message content blocks (text, images, etc.)
*   - `tool_calls`: Array of successfully parsed tool calls
*   - `invalid_tool_calls`: Array of tool calls that failed to parse
*   - `usage_metadata`: Token usage information converted to LangChain format
*   - `additional_kwargs`: Extra data including:
*     - `refusal`: Refusal text if the model refused to respond
*     - `reasoning`: Reasoning output for reasoning models
*     - `tool_outputs`: Results from built-in tools (web search, file search, etc.)
*     - `parsed`: Parsed structured output when using json_schema format
*     - Function call ID mappings for tracking
*   - `response_metadata`: Metadata about the response including model, timestamps, status, etc.
*
* @throws Error if the response contains an error object. The error message and code are extracted
*   from the response.error field.
*
* @example
* ```typescript
* const response = await client.responses.create({
*   model: "gpt-4",
*   input: [{ type: "message", content: "Hello" }]
* });
* const message = convertResponsesMessageToAIMessage(response);
* console.log(message.content); // Message content
* console.log(message.tool_calls); // Any tool calls made
* ```
*
* @remarks
* The converter handles multiple output item types:
* - `message`: Text and structured content from the model
* - `function_call`: Tool/function calls that need to be executed
* - `reasoning`: Reasoning traces from reasoning models (o1, o3, etc.)
* - `custom_tool_call`: Custom tool invocations
* - Built-in tool outputs: web_search, file_search, code_interpreter, etc.
*
* Tool calls are parsed and validated. Invalid tool calls (malformed JSON, etc.) are captured
* in the `invalid_tool_calls` array rather than throwing errors.
*/ const convertResponsesMessageToAIMessage = (response)=>{
    if (response.error) {
        const error = new Error(response.error.message);
        error.name = response.error.code;
        throw error;
    }
    let messageId;
    const content = [];
    const tool_calls = [];
    const invalid_tool_calls = [];
    const response_metadata = {
        model_provider: "openai",
        model: response.model,
        created_at: response.created_at,
        id: response.id,
        incomplete_details: response.incomplete_details,
        metadata: response.metadata,
        object: response.object,
        status: response.status,
        user: response.user,
        service_tier: response.service_tier,
        model_name: response.model
    };
    const additional_kwargs = {};
    for (const item of response.output)if (item.type === "message") {
        messageId = item.id;
        content.push(...item.content.flatMap((part)=>{
            if (part.type === "output_text") {
                if ("parsed" in part && part.parsed != null) additional_kwargs.parsed = part.parsed;
                return {
                    type: "text",
                    text: part.text,
                    annotations: part.annotations
                };
            }
            if (part.type === "refusal") {
                additional_kwargs.refusal = part.refusal;
                return [];
            }
            return part;
        }));
    } else if (item.type === "function_call") {
        const fnAdapter = {
            function: {
                name: item.name,
                arguments: item.arguments
            },
            id: item.call_id
        };
        try {
            tool_calls.push((0, __langchain_core_output_parsers_openai_tools.parseToolCall)(fnAdapter, {
                returnId: true
            }));
        } catch (e) {
            let errMessage;
            if (typeof e === "object" && e != null && "message" in e && typeof e.message === "string") errMessage = e.message;
            invalid_tool_calls.push((0, __langchain_core_output_parsers_openai_tools.makeInvalidToolCall)(fnAdapter, errMessage));
        }
        additional_kwargs[_FUNCTION_CALL_IDS_MAP_KEY] ??= {};
        if (item.id) additional_kwargs[_FUNCTION_CALL_IDS_MAP_KEY][item.call_id] = item.id;
    } else if (item.type === "reasoning") additional_kwargs.reasoning = item;
    else if (item.type === "custom_tool_call") {
        const parsed = require_tools.parseCustomToolCall(item);
        if (parsed) tool_calls.push(parsed);
        else invalid_tool_calls.push((0, __langchain_core_output_parsers_openai_tools.makeInvalidToolCall)(item, "Malformed custom tool call"));
    } else if (item.type === "computer_call") {
        const parsed = require_tools.parseComputerCall(item);
        if (parsed) tool_calls.push(parsed);
        else invalid_tool_calls.push((0, __langchain_core_output_parsers_openai_tools.makeInvalidToolCall)(item, "Malformed computer call"));
    } else {
        additional_kwargs.tool_outputs ??= [];
        additional_kwargs.tool_outputs.push(item);
    }
    return new __langchain_core_messages.AIMessage({
        id: messageId,
        content,
        tool_calls,
        invalid_tool_calls,
        usage_metadata: convertResponsesUsageToUsageMetadata(response.usage),
        additional_kwargs,
        response_metadata
    });
};
/**
* Converts a LangChain ChatOpenAI reasoning summary to an OpenAI Responses API reasoning item.
*
* This converter transforms reasoning summaries that have been accumulated during streaming
* (where summary parts may arrive in multiple chunks with the same index) into the final
* consolidated format expected by OpenAI's Responses API. It combines summary parts that
* share the same index and removes the index field from the final output.
*
* @param reasoning - A ChatOpenAI reasoning summary object containing:
*   - `id`: The reasoning item ID
*   - `type`: The type of reasoning (typically "reasoning")
*   - `summary`: Array of summary parts, each with:
*     - `text`: The summary text content
*     - `type`: The summary type (e.g., "summary_text")
*     - `index`: The index used to group related summary parts during streaming
*
* @returns An OpenAI Responses API ResponseReasoningItem with:
*   - All properties from the input reasoning object
*   - `summary`: Consolidated array of summary objects with:
*     - `text`: Combined text from all parts with the same index
*     - `type`: The summary type
*     - No `index` field (removed after consolidation)
*
* @example
* ```typescript
* // Input: Reasoning summary with multiple parts at the same index
* const reasoning = {
*   id: "reasoning_123",
*   type: "reasoning",
*   summary: [
*     { text: "First ", type: "summary_text", index: 0 },
*     { text: "part", type: "summary_text", index: 0 },
*     { text: "Second part", type: "summary_text", index: 1 }
*   ]
* };
*
* const result = convertReasoningSummaryToResponsesReasoningItem(reasoning);
* // Returns:
* // {
* //   id: "reasoning_123",
* //   type: "reasoning",
* //   summary: [
* //     { text: "First part", type: "summary_text" },
* //     { text: "Second part", type: "summary_text" }
* //   ]
* // }
* ```
*
* @remarks
* - This converter is primarily used when reconstructing complete reasoning items from
*   streaming chunks, where summary parts may arrive incrementally with index markers
* - Summary parts with the same index are concatenated in the order they appear
* - If the reasoning summary contains only one part, no reduction is performed
* - The index field is used internally during streaming to track which summary parts
*   belong together, but is removed from the final output as it's not part of the
*   OpenAI Responses API schema
* - This is the inverse operation of the streaming accumulation that happens in
*   `convertResponsesDeltaToChatGenerationChunk`
*/ const convertReasoningSummaryToResponsesReasoningItem = (reasoning)=>{
    const summary = (reasoning.summary.length > 1 ? reasoning.summary.reduce((acc, curr)=>{
        const last = acc[acc.length - 1];
        if (last.index === curr.index) last.text += curr.text;
        else acc.push(curr);
        return acc;
    }, [
        {
            ...reasoning.summary[0]
        }
    ]) : reasoning.summary).map((s)=>Object.fromEntries(Object.entries(s).filter(([k])=>k !== "index")));
    return {
        ...reasoning,
        summary
    };
};
/**
* Converts OpenAI Responses API stream events to LangChain ChatGenerationChunk objects.
*
* This converter processes streaming events from OpenAI's Responses API and transforms them
* into LangChain ChatGenerationChunk objects that can be used in streaming chat applications.
* It handles various event types including text deltas, tool calls, reasoning, and metadata updates.
*
* @param event - A streaming event from OpenAI's Responses API
*
* @returns A ChatGenerationChunk containing:
*   - `text`: Concatenated text content from all text parts in the event
*   - `message`: An AIMessageChunk with:
*     - `id`: Message ID (set when a message output item is added)
*     - `content`: Array of content blocks (text with optional annotations)
*     - `tool_call_chunks`: Incremental tool call data (name, args, id)
*     - `usage_metadata`: Token usage information (only in completion events)
*     - `additional_kwargs`: Extra data including:
*       - `refusal`: Refusal text if the model refused to respond
*       - `reasoning`: Reasoning output for reasoning models (id, type, summary)
*       - `tool_outputs`: Results from built-in tools (web search, file search, etc.)
*       - `parsed`: Parsed structured output when using json_schema format
*       - Function call ID mappings for tracking
*     - `response_metadata`: Metadata about the response (model, id, etc.)
*   - `generationInfo`: Additional generation information (e.g., tool output status)
*
*   Returns `null` for events that don't produce meaningful chunks:
*   - Partial image generation events (to avoid storing all partial images in history)
*   - Unrecognized event types
*
* @example
* ```typescript
* const stream = await client.responses.create({
*   model: "gpt-4",
*   input: [{ type: "message", content: "Hello" }],
*   stream: true
* });
*
* for await (const event of stream) {
*   const chunk = convertResponsesDeltaToChatGenerationChunk(event);
*   if (chunk) {
*     console.log(chunk.text); // Incremental text
*     console.log(chunk.message.tool_call_chunks); // Tool call updates
*   }
* }
* ```
*
* @remarks
* - Text content is accumulated in an array with index tracking for proper ordering
* - Tool call chunks include incremental arguments that need to be concatenated by the consumer
* - Reasoning summaries are built incrementally across multiple events
* - Function call IDs are tracked in `additional_kwargs` to map call_id to item id
* - The `text` field is provided for legacy compatibility with `onLLMNewToken` callbacks
* - Usage metadata is only available in `response.completed` events
* - Partial images are intentionally ignored to prevent memory bloat in conversation history
*/ const convertResponsesDeltaToChatGenerationChunk = (event)=>{
    const content = [];
    let generationInfo = {};
    let usage_metadata;
    const tool_call_chunks = [];
    const response_metadata = {
        model_provider: "openai"
    };
    const additional_kwargs = {};
    let id;
    if (event.type === "response.output_text.delta") content.push({
        type: "text",
        text: event.delta,
        index: event.content_index
    });
    else if (event.type === "response.output_text.annotation.added") content.push({
        type: "text",
        text: "",
        annotations: [
            event.annotation
        ],
        index: event.content_index
    });
    else if (event.type === "response.output_item.added" && event.item.type === "message") id = event.item.id;
    else if (event.type === "response.output_item.added" && event.item.type === "function_call") {
        tool_call_chunks.push({
            type: "tool_call_chunk",
            name: event.item.name,
            args: event.item.arguments,
            id: event.item.call_id,
            index: event.output_index
        });
        additional_kwargs[_FUNCTION_CALL_IDS_MAP_KEY] = {
            [event.item.call_id]: event.item.id
        };
    } else if (event.type === "response.output_item.done" && event.item.type === "computer_call") {
        tool_call_chunks.push({
            type: "tool_call_chunk",
            name: "computer_use",
            args: JSON.stringify({
                action: event.item.action
            }),
            id: event.item.call_id,
            index: event.output_index
        });
        additional_kwargs.tool_outputs = [
            event.item
        ];
    } else if (event.type === "response.output_item.done" && [
        "web_search_call",
        "file_search_call",
        "code_interpreter_call",
        "mcp_call",
        "mcp_list_tools",
        "mcp_approval_request",
        "image_generation_call",
        "custom_tool_call"
    ].includes(event.item.type)) additional_kwargs.tool_outputs = [
        event.item
    ];
    else if (event.type === "response.created") {
        response_metadata.id = event.response.id;
        response_metadata.model_name = event.response.model;
        response_metadata.model = event.response.model;
    } else if (event.type === "response.completed") {
        const msg = convertResponsesMessageToAIMessage(event.response);
        usage_metadata = convertResponsesUsageToUsageMetadata(event.response.usage);
        if (event.response.text?.format?.type === "json_schema") additional_kwargs.parsed ??= JSON.parse(msg.text);
        for (const [key, value] of Object.entries(event.response))if (key !== "id") response_metadata[key] = value;
    } else if (event.type === "response.function_call_arguments.delta" || event.type === "response.custom_tool_call_input.delta") tool_call_chunks.push({
        type: "tool_call_chunk",
        args: event.delta,
        index: event.output_index
    });
    else if (event.type === "response.web_search_call.completed" || event.type === "response.file_search_call.completed") generationInfo = {
        tool_outputs: {
            id: event.item_id,
            type: event.type.replace("response.", "").replace(".completed", ""),
            status: "completed"
        }
    };
    else if (event.type === "response.refusal.done") additional_kwargs.refusal = event.refusal;
    else if (event.type === "response.output_item.added" && "item" in event && event.item.type === "reasoning") {
        const summary = event.item.summary ? event.item.summary.map((s, index)=>({
                ...s,
                index
            })) : void 0;
        additional_kwargs.reasoning = {
            id: event.item.id,
            type: event.item.type,
            ...summary ? {
                summary
            } : {}
        };
    } else if (event.type === "response.reasoning_summary_part.added") additional_kwargs.reasoning = {
        type: "reasoning",
        summary: [
            {
                ...event.part,
                index: event.summary_index
            }
        ]
    };
    else if (event.type === "response.reasoning_summary_text.delta") additional_kwargs.reasoning = {
        type: "reasoning",
        summary: [
            {
                text: event.delta,
                type: "summary_text",
                index: event.summary_index
            }
        ]
    };
    else if (event.type === "response.image_generation_call.partial_image") return null;
    else return null;
    return new __langchain_core_outputs.ChatGenerationChunk({
        text: content.map((part)=>part.text).join(""),
        message: new __langchain_core_messages.AIMessageChunk({
            id,
            content,
            tool_call_chunks,
            usage_metadata,
            additional_kwargs,
            response_metadata
        }),
        generationInfo
    });
};
/**
* Converts a single LangChain BaseMessage to OpenAI Responses API input format.
*
* This converter transforms a LangChain message into one or more ResponseInputItem objects
* that can be used with OpenAI's Responses API. It handles complex message structures including
* tool calls, reasoning blocks, multimodal content, and various content block types.
*
* @param message - The LangChain BaseMessage to convert. Can be any message type including
*   HumanMessage, AIMessage, SystemMessage, ToolMessage, etc.
*
* @returns An array of ResponseInputItem objects.
*
* @example
* Basic text message conversion:
* ```typescript
* const message = new HumanMessage("Hello, how are you?");
* const items = convertStandardContentMessageToResponsesInput(message);
* // Returns: [{ type: "message", role: "user", content: [{ type: "input_text", text: "Hello, how are you?" }] }]
* ```
*
* @example
* AI message with tool calls:
* ```typescript
* const message = new AIMessage({
*   content: "I'll check the weather for you.",
*   tool_calls: [{
*     id: "call_123",
*     name: "get_weather",
*     args: { location: "San Francisco" }
*   }]
* });
* const items = convertStandardContentMessageToResponsesInput(message);
* // Returns:
* // [
* //   { type: "message", role: "assistant", content: [{ type: "input_text", text: "I'll check the weather for you." }] },
* //   { type: "function_call", call_id: "call_123", name: "get_weather", arguments: '{"location":"San Francisco"}' }
* // ]
* ```
*/ const convertStandardContentMessageToResponsesInput = (message)=>{
    const isResponsesMessage = __langchain_core_messages.AIMessage.isInstance(message) && message.response_metadata?.model_provider === "openai";
    function* iterateItems() {
        const messageRole = require_misc.iife(()=>{
            try {
                const role = require_misc.messageToOpenAIRole(message);
                if (role === "system" || role === "developer" || role === "assistant" || role === "user") return role;
                return "assistant";
            } catch  {
                return "assistant";
            }
        });
        let currentMessage = void 0;
        const functionCallIdsWithBlocks = /* @__PURE__ */ new Set();
        const serverFunctionCallIdsWithBlocks = /* @__PURE__ */ new Set();
        const pendingFunctionChunks = /* @__PURE__ */ new Map();
        const pendingServerFunctionChunks = /* @__PURE__ */ new Map();
        function* flushMessage() {
            if (!currentMessage) return;
            const content = currentMessage.content;
            if (typeof content === "string" && content.length > 0 || Array.isArray(content) && content.length > 0) yield currentMessage;
            currentMessage = void 0;
        }
        const pushMessageContent = (content)=>{
            if (!currentMessage) currentMessage = {
                type: "message",
                role: messageRole,
                content: []
            };
            if (typeof currentMessage.content === "string") currentMessage.content = currentMessage.content.length > 0 ? [
                {
                    type: "input_text",
                    text: currentMessage.content
                },
                ...content
            ] : [
                ...content
            ];
            else currentMessage.content.push(...content);
        };
        const toJsonString = (value)=>{
            if (typeof value === "string") return value;
            try {
                return JSON.stringify(value ?? {});
            } catch  {
                return "{}";
            }
        };
        const resolveImageItem = (block)=>{
            const detail = require_misc.iife(()=>{
                const raw = block.metadata?.detail;
                if (raw === "low" || raw === "high" || raw === "auto") return raw;
                return "auto";
            });
            if (block.fileId) return {
                type: "input_image",
                detail,
                file_id: block.fileId
            };
            if (block.url) return {
                type: "input_image",
                detail,
                image_url: block.url
            };
            if (block.data) {
                const base64Data = typeof block.data === "string" ? block.data : Buffer.from(block.data).toString("base64");
                const mimeType = block.mimeType ?? "image/png";
                return {
                    type: "input_image",
                    detail,
                    image_url: `data:${mimeType};base64,${base64Data}`
                };
            }
            return void 0;
        };
        const resolveFileItem = (block)=>{
            const filename = require_misc.getRequiredFilenameFromMetadata(block);
            if (block.fileId && typeof filename === "string") return {
                type: "input_file",
                file_id: block.fileId,
                ...filename ? {
                    filename
                } : {}
            };
            if (block.url && typeof filename === "string") return {
                type: "input_file",
                file_url: block.url,
                ...filename ? {
                    filename
                } : {}
            };
            if (block.data && typeof filename === "string") {
                const encoded = typeof block.data === "string" ? block.data : Buffer.from(block.data).toString("base64");
                const mimeType = block.mimeType ?? "application/octet-stream";
                return {
                    type: "input_file",
                    file_data: `data:${mimeType};base64,${encoded}`,
                    ...filename ? {
                        filename
                    } : {}
                };
            }
            return void 0;
        };
        const convertReasoningBlock = (block)=>{
            const summaryEntries = require_misc.iife(()=>{
                if (Array.isArray(block.summary)) {
                    const candidate = block.summary;
                    const mapped = candidate?.map((item)=>item?.text).filter((text)=>typeof text === "string") ?? [];
                    if (mapped.length > 0) return mapped;
                }
                return block.reasoning ? [
                    block.reasoning
                ] : [];
            });
            const summary = summaryEntries.length > 0 ? summaryEntries.map((text)=>({
                    type: "summary_text",
                    text
                })) : [
                {
                    type: "summary_text",
                    text: ""
                }
            ];
            const reasoningItem = {
                type: "reasoning",
                id: block.id ?? "",
                summary
            };
            if (block.reasoning) reasoningItem.content = [
                {
                    type: "reasoning_text",
                    text: block.reasoning
                }
            ];
            return reasoningItem;
        };
        const convertFunctionCall = (block)=>({
                type: "function_call",
                name: block.name ?? "",
                call_id: block.id ?? "",
                arguments: toJsonString(block.args)
            });
        const convertFunctionCallOutput = (block)=>{
            const output = toJsonString(block.output);
            const status = block.status === "success" ? "completed" : block.status === "error" ? "incomplete" : void 0;
            return {
                type: "function_call_output",
                call_id: block.toolCallId ?? "",
                output,
                ...status ? {
                    status
                } : {}
            };
        };
        for (const block of message.contentBlocks)if (block.type === "text") pushMessageContent([
            {
                type: "input_text",
                text: block.text
            }
        ]);
        else if (block.type === "invalid_tool_call") {} else if (block.type === "reasoning") {
            yield* flushMessage();
            yield convertReasoningBlock(block);
        } else if (block.type === "tool_call") {
            yield* flushMessage();
            const id = block.id ?? "";
            if (id) {
                functionCallIdsWithBlocks.add(id);
                pendingFunctionChunks.delete(id);
            }
            yield convertFunctionCall(block);
        } else if (block.type === "tool_call_chunk") {
            if (block.id) {
                const existing = pendingFunctionChunks.get(block.id) ?? {
                    name: block.name,
                    args: []
                };
                if (block.name) existing.name = block.name;
                if (block.args) existing.args.push(block.args);
                pendingFunctionChunks.set(block.id, existing);
            }
        } else if (block.type === "server_tool_call") {
            yield* flushMessage();
            const id = block.id ?? "";
            if (id) {
                serverFunctionCallIdsWithBlocks.add(id);
                pendingServerFunctionChunks.delete(id);
            }
            yield convertFunctionCall(block);
        } else if (block.type === "server_tool_call_chunk") {
            if (block.id) {
                const existing = pendingServerFunctionChunks.get(block.id) ?? {
                    name: block.name,
                    args: []
                };
                if (block.name) existing.name = block.name;
                if (block.args) existing.args.push(block.args);
                pendingServerFunctionChunks.set(block.id, existing);
            }
        } else if (block.type === "server_tool_call_result") {
            yield* flushMessage();
            yield convertFunctionCallOutput(block);
        } else if (block.type === "audio") {} else if (block.type === "file") {
            const fileItem = resolveFileItem(block);
            if (fileItem) pushMessageContent([
                fileItem
            ]);
        } else if (block.type === "image") {
            const imageItem = resolveImageItem(block);
            if (imageItem) pushMessageContent([
                imageItem
            ]);
        } else if (block.type === "video") {
            const videoItem = resolveFileItem(block);
            if (videoItem) pushMessageContent([
                videoItem
            ]);
        } else if (block.type === "text-plain") {
            if (block.text) pushMessageContent([
                {
                    type: "input_text",
                    text: block.text
                }
            ]);
        } else if (block.type === "non_standard" && isResponsesMessage) {
            yield* flushMessage();
            yield block.value;
        }
        yield* flushMessage();
        for (const [id, chunk] of pendingFunctionChunks){
            if (!id || functionCallIdsWithBlocks.has(id)) continue;
            const args = chunk.args.join("");
            if (!chunk.name && !args) continue;
            yield {
                type: "function_call",
                call_id: id,
                name: chunk.name ?? "",
                arguments: args
            };
        }
        for (const [id, chunk] of pendingServerFunctionChunks){
            if (!id || serverFunctionCallIdsWithBlocks.has(id)) continue;
            const args = chunk.args.join("");
            if (!chunk.name && !args) continue;
            yield {
                type: "function_call",
                call_id: id,
                name: chunk.name ?? "",
                arguments: args
            };
        }
    }
    return Array.from(iterateItems());
};
/**
* - MCP (Model Context Protocol) approval responses
* - Zero Data Retention (ZDR) mode handling
*
* @param params - Conversion parameters
* @param params.messages - Array of LangChain BaseMessages to convert
* @param params.zdrEnabled - Whether Zero Data Retention mode is enabled. When true, certain
*   metadata like message IDs and function call IDs are omitted from the output
* @param params.model - The model name being used. Used to determine if special role mapping
*   is needed (e.g., "system" -> "developer" for reasoning models)
*
* @returns Array of ResponsesInputItem objects formatted for the OpenAI Responses API
*
* @throws {Error} When a function message is encountered (not supported)
* @throws {Error} When computer call output format is invalid
*
* @example
* ```typescript
* const messages = [
*   new HumanMessage("Hello"),
*   new AIMessage({ content: "Hi there!", tool_calls: [...] })
* ];
*
* const input = convertMessagesToResponsesInput({
*   messages,
*   zdrEnabled: false,
*   model: "gpt-4"
* });
* ```
*/ const convertMessagesToResponsesInput = ({ messages, zdrEnabled, model })=>{
    return messages.flatMap((lcMsg)=>{
        const responseMetadata = lcMsg.response_metadata;
        if (responseMetadata?.output_version === "v1") return convertStandardContentMessageToResponsesInput(lcMsg);
        const additional_kwargs = lcMsg.additional_kwargs;
        let role = require_misc.messageToOpenAIRole(lcMsg);
        if (role === "system" && require_misc.isReasoningModel(model)) role = "developer";
        if (role === "function") throw new Error("Function messages are not supported in Responses API");
        if (role === "tool") {
            const toolMessage = lcMsg;
            if (additional_kwargs?.type === "computer_call_output") {
                const output = (()=>{
                    if (typeof toolMessage.content === "string") return {
                        type: "input_image",
                        image_url: toolMessage.content
                    };
                    if (Array.isArray(toolMessage.content)) {
                        /**
						* Check for input_image type first (computer-use-preview format)
						*/ const inputImage = toolMessage.content.find((i)=>i.type === "input_image");
                        if (inputImage) return inputImage;
                        /**
						* Check for computer_screenshot type (legacy format)
						*/ const oaiScreenshot = toolMessage.content.find((i)=>i.type === "computer_screenshot");
                        if (oaiScreenshot) return oaiScreenshot;
                        /**
						* Convert image_url content block to input_image format
						*/ const lcImage = toolMessage.content.find((i)=>i.type === "image_url");
                        if (lcImage) return {
                            type: "input_image",
                            image_url: typeof lcImage.image_url === "string" ? lcImage.image_url : lcImage.image_url.url
                        };
                    }
                    throw new Error("Invalid computer call output");
                })();
                /**
				* Cast needed because OpenAI SDK types don't yet include input_image
				* for computer-use-preview model output format
				*/ return {
                    type: "computer_call_output",
                    output,
                    call_id: toolMessage.tool_call_id
                };
            }
            if (toolMessage.additional_kwargs?.customTool) return {
                type: "custom_tool_call_output",
                call_id: toolMessage.tool_call_id,
                output: toolMessage.content
            };
            return {
                type: "function_call_output",
                call_id: toolMessage.tool_call_id,
                id: toolMessage.id?.startsWith("fc_") ? toolMessage.id : void 0,
                output: typeof toolMessage.content !== "string" ? JSON.stringify(toolMessage.content) : toolMessage.content
            };
        }
        if (role === "assistant") {
            if (!zdrEnabled && responseMetadata?.output != null && Array.isArray(responseMetadata?.output) && responseMetadata?.output.length > 0 && responseMetadata?.output.every((item)=>"type" in item)) return responseMetadata?.output;
            const input = [];
            if (additional_kwargs?.reasoning && !zdrEnabled) {
                const reasoningItem = convertReasoningSummaryToResponsesReasoningItem(additional_kwargs.reasoning);
                input.push(reasoningItem);
            }
            let { content } = lcMsg;
            if (additional_kwargs?.refusal) {
                if (typeof content === "string") content = [
                    {
                        type: "output_text",
                        text: content,
                        annotations: []
                    }
                ];
                content = [
                    ...content,
                    {
                        type: "refusal",
                        refusal: additional_kwargs.refusal
                    }
                ];
            }
            if (typeof content === "string" || content.length > 0) input.push({
                type: "message",
                role: "assistant",
                ...lcMsg.id && !zdrEnabled && lcMsg.id.startsWith("msg_") ? {
                    id: lcMsg.id
                } : {},
                content: require_misc.iife(()=>{
                    if (typeof content === "string") return content;
                    return content.flatMap((item)=>{
                        if (item.type === "text") return {
                            type: "output_text",
                            text: item.text,
                            annotations: item.annotations ?? []
                        };
                        if (item.type === "output_text" || item.type === "refusal") return item;
                        return [];
                    });
                })
            });
            const functionCallIds = additional_kwargs?.[_FUNCTION_CALL_IDS_MAP_KEY];
            if (__langchain_core_messages.AIMessage.isInstance(lcMsg) && !!lcMsg.tool_calls?.length) input.push(...lcMsg.tool_calls.map((toolCall)=>{
                if (require_tools.isCustomToolCall(toolCall)) return {
                    type: "custom_tool_call",
                    id: toolCall.call_id,
                    call_id: toolCall.id ?? "",
                    input: toolCall.args.input,
                    name: toolCall.name
                };
                if (require_tools.isComputerToolCall(toolCall)) return {
                    type: "computer_call",
                    id: toolCall.call_id,
                    call_id: toolCall.id ?? "",
                    action: toolCall.args.action
                };
                return {
                    type: "function_call",
                    name: toolCall.name,
                    arguments: JSON.stringify(toolCall.args),
                    call_id: toolCall.id,
                    ...!zdrEnabled ? {
                        id: functionCallIds?.[toolCall.id]
                    } : {}
                };
            }));
            else if (additional_kwargs?.tool_calls) input.push(...additional_kwargs.tool_calls.map((toolCall)=>({
                    type: "function_call",
                    name: toolCall.function.name,
                    call_id: toolCall.id,
                    arguments: toolCall.function.arguments,
                    ...!zdrEnabled ? {
                        id: functionCallIds?.[toolCall.id]
                    } : {}
                })));
            const toolOutputs = responseMetadata?.output?.length ? responseMetadata?.output : additional_kwargs.tool_outputs;
            const fallthroughCallTypes = [
                "computer_call",
                "mcp_call",
                "code_interpreter_call",
                "image_generation_call"
            ];
            if (toolOutputs != null) {
                const castToolOutputs = toolOutputs;
                const fallthroughCalls = castToolOutputs?.filter((item)=>fallthroughCallTypes.includes(item.type));
                if (fallthroughCalls.length > 0) input.push(...fallthroughCalls);
            }
            return input;
        }
        if (role === "user" || role === "system" || role === "developer") {
            if (typeof lcMsg.content === "string") return {
                type: "message",
                role,
                content: lcMsg.content
            };
            const messages$1 = [];
            const content = lcMsg.content.flatMap((item)=>{
                if (item.type === "mcp_approval_response") messages$1.push({
                    type: "mcp_approval_response",
                    approval_request_id: item.approval_request_id,
                    approve: item.approve
                });
                if ((0, __langchain_core_messages.isDataContentBlock)(item)) return (0, __langchain_core_messages.convertToProviderContentBlock)(item, require_completions.completionsApiContentBlockConverter);
                if (item.type === "text") return {
                    type: "input_text",
                    text: item.text
                };
                if (item.type === "image_url") {
                    const imageUrl = require_misc.iife(()=>{
                        if (typeof item.image_url === "string") return item.image_url;
                        else if (typeof item.image_url === "object" && item.image_url !== null && "url" in item.image_url) return item.image_url.url;
                        return void 0;
                    });
                    const detail = require_misc.iife(()=>{
                        if (typeof item.image_url === "string") return "auto";
                        else if (typeof item.image_url === "object" && item.image_url !== null && "detail" in item.image_url) return item.image_url.detail;
                        return void 0;
                    });
                    return {
                        type: "input_image",
                        image_url: imageUrl,
                        detail
                    };
                }
                if (item.type === "input_text" || item.type === "input_image" || item.type === "input_file") return item;
                return [];
            });
            if (content.length > 0) messages$1.push({
                type: "message",
                role,
                content
            });
            return messages$1;
        }
        console.warn(`Unsupported role found when converting to OpenAI Responses API: ${role}`);
        return [];
    });
};
//#endregion
exports.convertMessagesToResponsesInput = convertMessagesToResponsesInput;
exports.convertReasoningSummaryToResponsesReasoningItem = convertReasoningSummaryToResponsesReasoningItem;
exports.convertResponsesDeltaToChatGenerationChunk = convertResponsesDeltaToChatGenerationChunk;
exports.convertResponsesMessageToAIMessage = convertResponsesMessageToAIMessage;
exports.convertResponsesUsageToUsageMetadata = convertResponsesUsageToUsageMetadata;
exports.convertStandardContentMessageToResponsesInput = convertStandardContentMessageToResponsesInput; //# sourceMappingURL=responses.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/responses.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const require_client = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/client.cjs [app-route] (ecmascript)");
const require_tools = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/tools.cjs [app-route] (ecmascript)");
const require_base = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/base.cjs [app-route] (ecmascript)");
const require_responses = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/converters/responses.cjs [app-route] (ecmascript)");
const __langchain_core_language_models_base = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/language_models/base.cjs [app-route] (ecmascript)"));
//#region src/chat_models/responses.ts
/**
* OpenAI Responses API implementation.
*
* Will be exported in a later version of @langchain/openai.
*
* @internal
*/ var ChatOpenAIResponses = class extends require_base.BaseChatOpenAI {
    invocationParams(options) {
        let strict;
        if (options?.strict !== void 0) strict = options.strict;
        if (strict === void 0 && this.supportsStrictToolCalling !== void 0) strict = this.supportsStrictToolCalling;
        const params = {
            model: this.model,
            temperature: this.temperature,
            top_p: this.topP,
            user: this.user,
            stream: this.streaming,
            previous_response_id: options?.previous_response_id,
            truncation: options?.truncation,
            include: options?.include,
            tools: options?.tools?.length ? this._reduceChatOpenAITools(options.tools, {
                stream: this.streaming,
                strict
            }) : void 0,
            tool_choice: require_tools.isBuiltInToolChoice(options?.tool_choice) ? options?.tool_choice : (()=>{
                const formatted = require_tools.formatToOpenAIToolChoice(options?.tool_choice);
                if (typeof formatted === "object" && "type" in formatted) {
                    if (formatted.type === "function") return {
                        type: "function",
                        name: formatted.function.name
                    };
                    else if (formatted.type === "allowed_tools") return {
                        type: "allowed_tools",
                        mode: formatted.allowed_tools.mode,
                        tools: formatted.allowed_tools.tools
                    };
                    else if (formatted.type === "custom") return {
                        type: "custom",
                        name: formatted.custom.name
                    };
                }
                return void 0;
            })(),
            text: (()=>{
                if (options?.text) return options.text;
                const format = this._getResponseFormat(options?.response_format);
                if (format?.type === "json_schema") {
                    if (format.json_schema.schema != null) return {
                        format: {
                            type: "json_schema",
                            schema: format.json_schema.schema,
                            description: format.json_schema.description,
                            name: format.json_schema.name,
                            strict: format.json_schema.strict
                        },
                        verbosity: options?.verbosity
                    };
                    return void 0;
                }
                return {
                    format,
                    verbosity: options?.verbosity
                };
            })(),
            parallel_tool_calls: options?.parallel_tool_calls,
            max_output_tokens: this.maxTokens === -1 ? void 0 : this.maxTokens,
            prompt_cache_key: options?.promptCacheKey ?? this.promptCacheKey,
            prompt_cache_retention: options?.promptCacheRetention ?? this.promptCacheRetention,
            ...this.zdrEnabled ? {
                store: false
            } : {},
            ...this.modelKwargs
        };
        const reasoning = this._getReasoningParams(options);
        if (reasoning !== void 0) params.reasoning = reasoning;
        return params;
    }
    async _generate(messages, options) {
        const invocationParams = this.invocationParams(options);
        if (invocationParams.stream) {
            const stream = this._streamResponseChunks(messages, options);
            let finalChunk;
            for await (const chunk of stream){
                chunk.message.response_metadata = {
                    ...chunk.generationInfo,
                    ...chunk.message.response_metadata
                };
                finalChunk = finalChunk?.concat(chunk) ?? chunk;
            }
            return {
                generations: finalChunk ? [
                    finalChunk
                ] : [],
                llmOutput: {
                    estimatedTokenUsage: finalChunk?.message?.usage_metadata
                }
            };
        } else {
            const data = await this.completionWithRetry({
                input: require_responses.convertMessagesToResponsesInput({
                    messages,
                    zdrEnabled: this.zdrEnabled ?? false,
                    model: this.model
                }),
                ...invocationParams,
                stream: false
            }, {
                signal: options?.signal,
                ...options?.options
            });
            return {
                generations: [
                    {
                        text: data.output_text,
                        message: require_responses.convertResponsesMessageToAIMessage(data)
                    }
                ],
                llmOutput: {
                    id: data.id,
                    estimatedTokenUsage: data.usage ? {
                        promptTokens: data.usage.input_tokens,
                        completionTokens: data.usage.output_tokens,
                        totalTokens: data.usage.total_tokens
                    } : void 0
                }
            };
        }
    }
    async *_streamResponseChunks(messages, options, runManager) {
        const streamIterable = await this.completionWithRetry({
            ...this.invocationParams(options),
            input: require_responses.convertMessagesToResponsesInput({
                messages,
                zdrEnabled: this.zdrEnabled ?? false,
                model: this.model
            }),
            stream: true
        }, options);
        for await (const data of streamIterable){
            const chunk = require_responses.convertResponsesDeltaToChatGenerationChunk(data);
            if (chunk == null) continue;
            yield chunk;
            await runManager?.handleLLMNewToken(chunk.text || "", {
                prompt: options.promptIndex ?? 0,
                completion: 0
            }, void 0, void 0, void 0, {
                chunk
            });
        }
    }
    async completionWithRetry(request, requestOptions) {
        return this.caller.call(async ()=>{
            const clientOptions = this._getClientOptions(requestOptions);
            try {
                if (request.text?.format?.type === "json_schema" && !request.stream) return await this.client.responses.parse(request, clientOptions);
                return await this.client.responses.create(request, clientOptions);
            } catch (e) {
                const error = require_client.wrapOpenAIClientError(e);
                throw error;
            }
        });
    }
    /** @internal */ _reduceChatOpenAITools(tools, fields) {
        const reducedTools = [];
        for (const tool of tools)if (require_tools.isBuiltInTool(tool)) {
            if (tool.type === "image_generation" && fields?.stream) tool.partial_images = 1;
            reducedTools.push(tool);
        } else if (require_tools.isCustomTool(tool)) {
            const customToolData = tool.metadata.customTool;
            reducedTools.push({
                type: "custom",
                name: customToolData.name,
                description: customToolData.description,
                format: customToolData.format
            });
        } else if ((0, __langchain_core_language_models_base.isOpenAITool)(tool)) reducedTools.push({
            type: "function",
            name: tool.function.name,
            parameters: tool.function.parameters,
            description: tool.function.description,
            strict: fields?.strict ?? null
        });
        else if (require_tools.isOpenAICustomTool(tool)) reducedTools.push(require_tools.convertCompletionsCustomTool(tool));
        return reducedTools;
    }
};
//#endregion
exports.ChatOpenAIResponses = ChatOpenAIResponses; //# sourceMappingURL=responses.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/azure/chat_models/responses.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_common = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/azure/chat_models/common.cjs [app-route] (ecmascript)");
const require_responses = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/responses.cjs [app-route] (ecmascript)");
//#region src/azure/chat_models/responses.ts
var AzureChatOpenAIResponses = class extends require_responses.ChatOpenAIResponses {
    azureOpenAIApiVersion;
    azureOpenAIApiKey;
    azureADTokenProvider;
    azureOpenAIApiInstanceName;
    azureOpenAIApiDeploymentName;
    azureOpenAIBasePath;
    azureOpenAIEndpoint;
    _llmType() {
        return "azure_openai";
    }
    get lc_aliases() {
        return {
            ...super.lc_aliases,
            ...require_common.AZURE_ALIASES
        };
    }
    get lc_secrets() {
        return {
            ...super.lc_secrets,
            ...require_common.AZURE_SECRETS
        };
    }
    get lc_serializable_keys() {
        return [
            ...super.lc_serializable_keys,
            ...require_common.AZURE_SERIALIZABLE_KEYS
        ];
    }
    getLsParams(options) {
        const params = super.getLsParams(options);
        params.ls_provider = "azure";
        return params;
    }
    constructor(fields){
        super(fields);
        require_common._constructAzureFields.call(this, fields);
    }
    _getClientOptions(options) {
        return require_common._getAzureClientOptions.call(this, options);
    }
    toJSON() {
        return require_common._serializeAzureChat.call(this, super.toJSON());
    }
};
//#endregion
exports.AzureChatOpenAIResponses = AzureChatOpenAIResponses; //# sourceMappingURL=responses.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/index.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_tools = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/tools.cjs [app-route] (ecmascript)");
const require_misc = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/misc.cjs [app-route] (ecmascript)");
const require_base = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/base.cjs [app-route] (ecmascript)");
const require_completions = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/completions.cjs [app-route] (ecmascript)");
const require_responses = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/responses.cjs [app-route] (ecmascript)");
//#region src/chat_models/index.ts
/**
* OpenAI chat model integration.
*
* To use with Azure, import the `AzureChatOpenAI` class.
*
* Setup:
* Install `@langchain/openai` and set an environment variable named `OPENAI_API_KEY`.
*
* ```bash
* npm install @langchain/openai
* export OPENAI_API_KEY="your-api-key"
* ```
*
* ## [Constructor args](https://api.js.langchain.com/classes/langchain_openai.ChatOpenAI.html#constructor)
*
* ## [Runtime args](https://api.js.langchain.com/interfaces/langchain_openai.ChatOpenAICallOptions.html)
*
* Runtime args can be passed as the second argument to any of the base runnable methods `.invoke`. `.stream`, `.batch`, etc.
* They can also be passed via `.withConfig`, or the second arg in `.bindTools`, like shown in the examples below:
*
* ```typescript
* // When calling `.withConfig`, call options should be passed via the first argument
* const llmWithArgsBound = llm.withConfig({
*   stop: ["\n"],
*   tools: [...],
* });
*
* // When calling `.bindTools`, call options should be passed via the second argument
* const llmWithTools = llm.bindTools(
*   [...],
*   {
*     tool_choice: "auto",
*   }
* );
* ```
*
* ## Examples
*
* <details open>
* <summary><strong>Instantiate</strong></summary>
*
* ```typescript
* import { ChatOpenAI } from '@langchain/openai';
*
* const llm = new ChatOpenAI({
*   model: "gpt-4o-mini",
*   temperature: 0,
*   maxTokens: undefined,
*   timeout: undefined,
*   maxRetries: 2,
*   // apiKey: "...",
*   // configuration: {
*   //   baseURL: "...",
*   // }
*   // organization: "...",
*   // other params...
* });
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Invoking</strong></summary>
*
* ```typescript
* const input = `Translate "I love programming" into French.`;
*
* // Models also accept a list of chat messages or a formatted prompt
* const result = await llm.invoke(input);
* console.log(result);
* ```
*
* ```txt
* AIMessage {
*   "id": "chatcmpl-9u4Mpu44CbPjwYFkTbeoZgvzB00Tz",
*   "content": "J'adore la programmation.",
*   "response_metadata": {
*     "tokenUsage": {
*       "completionTokens": 5,
*       "promptTokens": 28,
*       "totalTokens": 33
*     },
*     "finish_reason": "stop",
*     "system_fingerprint": "fp_3aa7262c27"
*   },
*   "usage_metadata": {
*     "input_tokens": 28,
*     "output_tokens": 5,
*     "total_tokens": 33
*   }
* }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Streaming Chunks</strong></summary>
*
* ```typescript
* for await (const chunk of await llm.stream(input)) {
*   console.log(chunk);
* }
* ```
*
* ```txt
* AIMessageChunk {
*   "id": "chatcmpl-9u4NWB7yUeHCKdLr6jP3HpaOYHTqs",
*   "content": ""
* }
* AIMessageChunk {
*   "content": "J"
* }
* AIMessageChunk {
*   "content": "'adore"
* }
* AIMessageChunk {
*   "content": " la"
* }
* AIMessageChunk {
*   "content": " programmation",,
* }
* AIMessageChunk {
*   "content": ".",,
* }
* AIMessageChunk {
*   "content": "",
*   "response_metadata": {
*     "finish_reason": "stop",
*     "system_fingerprint": "fp_c9aa9c0491"
*   },
* }
* AIMessageChunk {
*   "content": "",
*   "usage_metadata": {
*     "input_tokens": 28,
*     "output_tokens": 5,
*     "total_tokens": 33
*   }
* }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Aggregate Streamed Chunks</strong></summary>
*
* ```typescript
* import { AIMessageChunk } from '@langchain/core/messages';
* import { concat } from '@langchain/core/utils/stream';
*
* const stream = await llm.stream(input);
* let full: AIMessageChunk | undefined;
* for await (const chunk of stream) {
*   full = !full ? chunk : concat(full, chunk);
* }
* console.log(full);
* ```
*
* ```txt
* AIMessageChunk {
*   "id": "chatcmpl-9u4PnX6Fy7OmK46DASy0bH6cxn5Xu",
*   "content": "J'adore la programmation.",
*   "response_metadata": {
*     "prompt": 0,
*     "completion": 0,
*     "finish_reason": "stop",
*   },
*   "usage_metadata": {
*     "input_tokens": 28,
*     "output_tokens": 5,
*     "total_tokens": 33
*   }
* }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Bind tools</strong></summary>
*
* ```typescript
* import { z } from 'zod';
*
* const GetWeather = {
*   name: "GetWeather",
*   description: "Get the current weather in a given location",
*   schema: z.object({
*     location: z.string().describe("The city and state, e.g. San Francisco, CA")
*   }),
* }
*
* const GetPopulation = {
*   name: "GetPopulation",
*   description: "Get the current population in a given location",
*   schema: z.object({
*     location: z.string().describe("The city and state, e.g. San Francisco, CA")
*   }),
* }
*
* const llmWithTools = llm.bindTools(
*   [GetWeather, GetPopulation],
*   {
*     // strict: true  // enforce tool args schema is respected
*   }
* );
* const aiMsg = await llmWithTools.invoke(
*   "Which city is hotter today and which is bigger: LA or NY?"
* );
* console.log(aiMsg.tool_calls);
* ```
*
* ```txt
* [
*   {
*     name: 'GetWeather',
*     args: { location: 'Los Angeles, CA' },
*     type: 'tool_call',
*     id: 'call_uPU4FiFzoKAtMxfmPnfQL6UK'
*   },
*   {
*     name: 'GetWeather',
*     args: { location: 'New York, NY' },
*     type: 'tool_call',
*     id: 'call_UNkEwuQsHrGYqgDQuH9nPAtX'
*   },
*   {
*     name: 'GetPopulation',
*     args: { location: 'Los Angeles, CA' },
*     type: 'tool_call',
*     id: 'call_kL3OXxaq9OjIKqRTpvjaCH14'
*   },
*   {
*     name: 'GetPopulation',
*     args: { location: 'New York, NY' },
*     type: 'tool_call',
*     id: 'call_s9KQB1UWj45LLGaEnjz0179q'
*   }
* ]
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Structured Output</strong></summary>
*
* ```typescript
* import { z } from 'zod';
*
* const Joke = z.object({
*   setup: z.string().describe("The setup of the joke"),
*   punchline: z.string().describe("The punchline to the joke"),
*   rating: z.number().nullable().describe("How funny the joke is, from 1 to 10")
* }).describe('Joke to tell user.');
*
* const structuredLlm = llm.withStructuredOutput(Joke, {
*   name: "Joke",
*   strict: true, // Optionally enable OpenAI structured outputs
* });
* const jokeResult = await structuredLlm.invoke("Tell me a joke about cats");
* console.log(jokeResult);
* ```
*
* ```txt
* {
*   setup: 'Why was the cat sitting on the computer?',
*   punchline: 'Because it wanted to keep an eye on the mouse!',
*   rating: 7
* }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>JSON Object Response Format</strong></summary>
*
* ```typescript
* const jsonLlm = llm.withConfig({ response_format: { type: "json_object" } });
* const jsonLlmAiMsg = await jsonLlm.invoke(
*   "Return a JSON object with key 'randomInts' and a value of 10 random ints in [0-99]"
* );
* console.log(jsonLlmAiMsg.content);
* ```
*
* ```txt
* {
*   "randomInts": [23, 87, 45, 12, 78, 34, 56, 90, 11, 67]
* }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Multimodal</strong></summary>
*
* ```typescript
* import { HumanMessage } from '@langchain/core/messages';
*
* const imageUrl = "https://example.com/image.jpg";
* const imageData = await fetch(imageUrl).then(res => res.arrayBuffer());
* const base64Image = Buffer.from(imageData).toString('base64');
*
* const message = new HumanMessage({
*   content: [
*     { type: "text", text: "describe the weather in this image" },
*     {
*       type: "image_url",
*       image_url: { url: `data:image/jpeg;base64,${base64Image}` },
*     },
*   ]
* });
*
* const imageDescriptionAiMsg = await llm.invoke([message]);
* console.log(imageDescriptionAiMsg.content);
* ```
*
* ```txt
* The weather in the image appears to be clear and sunny. The sky is mostly blue with a few scattered white clouds, indicating fair weather. The bright sunlight is casting shadows on the green, grassy hill, suggesting it is a pleasant day with good visibility. There are no signs of rain or stormy conditions.
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Usage Metadata</strong></summary>
*
* ```typescript
* const aiMsgForMetadata = await llm.invoke(input);
* console.log(aiMsgForMetadata.usage_metadata);
* ```
*
* ```txt
* { input_tokens: 28, output_tokens: 5, total_tokens: 33 }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Logprobs</strong></summary>
*
* ```typescript
* const logprobsLlm = new ChatOpenAI({ model: "gpt-4o-mini", logprobs: true });
* const aiMsgForLogprobs = await logprobsLlm.invoke(input);
* console.log(aiMsgForLogprobs.response_metadata.logprobs);
* ```
*
* ```txt
* {
*   content: [
*     {
*       token: 'J',
*       logprob: -0.000050616763,
*       bytes: [Array],
*       top_logprobs: []
*     },
*     {
*       token: "'",
*       logprob: -0.01868736,
*       bytes: [Array],
*       top_logprobs: []
*     },
*     {
*       token: 'ad',
*       logprob: -0.0000030545007,
*       bytes: [Array],
*       top_logprobs: []
*     },
*     { token: 'ore', logprob: 0, bytes: [Array], top_logprobs: [] },
*     {
*       token: ' la',
*       logprob: -0.515404,
*       bytes: [Array],
*       top_logprobs: []
*     },
*     {
*       token: ' programm',
*       logprob: -0.0000118755715,
*       bytes: [Array],
*       top_logprobs: []
*     },
*     { token: 'ation', logprob: 0, bytes: [Array], top_logprobs: [] },
*     {
*       token: '.',
*       logprob: -0.0000037697225,
*       bytes: [Array],
*       top_logprobs: []
*     }
*   ],
*   refusal: null
* }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Response Metadata</strong></summary>
*
* ```typescript
* const aiMsgForResponseMetadata = await llm.invoke(input);
* console.log(aiMsgForResponseMetadata.response_metadata);
* ```
*
* ```txt
* {
*   tokenUsage: { completionTokens: 5, promptTokens: 28, totalTokens: 33 },
*   finish_reason: 'stop',
*   system_fingerprint: 'fp_3aa7262c27'
* }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>JSON Schema Structured Output</strong></summary>
*
* ```typescript
* const llmForJsonSchema = new ChatOpenAI({
*   model: "gpt-4o-2024-08-06",
* }).withStructuredOutput(
*   z.object({
*     command: z.string().describe("The command to execute"),
*     expectedOutput: z.string().describe("The expected output of the command"),
*     options: z
*       .array(z.string())
*       .describe("The options you can pass to the command"),
*   }),
*   {
*     method: "jsonSchema",
*     strict: true, // Optional when using the `jsonSchema` method
*   }
* );
*
* const jsonSchemaRes = await llmForJsonSchema.invoke(
*   "What is the command to list files in a directory?"
* );
* console.log(jsonSchemaRes);
* ```
*
* ```txt
* {
*   command: 'ls',
*   expectedOutput: 'A list of files and subdirectories within the specified directory.',
*   options: [
*     '-a: include directory entries whose names begin with a dot (.).',
*     '-l: use a long listing format.',
*     '-h: with -l, print sizes in human readable format (e.g., 1K, 234M, 2G).',
*     '-t: sort by time, newest first.',
*     '-r: reverse order while sorting.',
*     '-S: sort by file size, largest first.',
*     '-R: list subdirectories recursively.'
*   ]
* }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Audio Outputs</strong></summary>
*
* ```typescript
* import { ChatOpenAI } from "@langchain/openai";
*
* const modelWithAudioOutput = new ChatOpenAI({
*   model: "gpt-4o-audio-preview",
*   // You may also pass these fields to `.withConfig` as a call argument.
*   modalities: ["text", "audio"], // Specifies that the model should output audio.
*   audio: {
*     voice: "alloy",
*     format: "wav",
*   },
* });
*
* const audioOutputResult = await modelWithAudioOutput.invoke("Tell me a joke about cats.");
* const castMessageContent = audioOutputResult.content[0] as Record<string, any>;
*
* console.log({
*   ...castMessageContent,
*   data: castMessageContent.data.slice(0, 100) // Sliced for brevity
* })
* ```
*
* ```txt
* {
*   id: 'audio_67117718c6008190a3afad3e3054b9b6',
*   data: 'UklGRqYwBgBXQVZFZm10IBAAAAABAAEAwF0AAIC7AAACABAATElTVBoAAABJTkZPSVNGVA4AAABMYXZmNTguMjkuMTAwAGRhdGFg',
*   expires_at: 1729201448,
*   transcript: 'Sure! Why did the cat sit on the computer? Because it wanted to keep an eye on the mouse!'
* }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Audio Outputs</strong></summary>
*
* ```typescript
* import { ChatOpenAI } from "@langchain/openai";
*
* const modelWithAudioOutput = new ChatOpenAI({
*   model: "gpt-4o-audio-preview",
*   // You may also pass these fields to `.withConfig` as a call argument.
*   modalities: ["text", "audio"], // Specifies that the model should output audio.
*   audio: {
*     voice: "alloy",
*     format: "wav",
*   },
* });
*
* const audioOutputResult = await modelWithAudioOutput.invoke("Tell me a joke about cats.");
* const castAudioContent = audioOutputResult.additional_kwargs.audio as Record<string, any>;
*
* console.log({
*   ...castAudioContent,
*   data: castAudioContent.data.slice(0, 100) // Sliced for brevity
* })
* ```
*
* ```txt
* {
*   id: 'audio_67117718c6008190a3afad3e3054b9b6',
*   data: 'UklGRqYwBgBXQVZFZm10IBAAAAABAAEAwF0AAIC7AAACABAATElTVBoAAABJTkZPSVNGVA4AAABMYXZmNTguMjkuMTAwAGRhdGFg',
*   expires_at: 1729201448,
*   transcript: 'Sure! Why did the cat sit on the computer? Because it wanted to keep an eye on the mouse!'
* }
* ```
* </details>
*
* <br />
*/ var ChatOpenAI = class ChatOpenAI extends require_base.BaseChatOpenAI {
    /**
	* Whether to use the responses API for all requests. If `false` the responses API will be used
	* only when required in order to fulfill the request.
	*/ useResponsesApi = false;
    responses;
    completions;
    get lc_serializable_keys() {
        return [
            ...super.lc_serializable_keys,
            "useResponsesApi"
        ];
    }
    get callKeys() {
        return [
            ...super.callKeys,
            "useResponsesApi"
        ];
    }
    constructor(fields){
        super(fields);
        this.fields = fields;
        this.useResponsesApi = fields?.useResponsesApi ?? false;
        this.responses = fields?.responses ?? new require_responses.ChatOpenAIResponses(fields);
        this.completions = fields?.completions ?? new require_completions.ChatOpenAICompletions(fields);
    }
    _useResponsesApi(options) {
        const usesBuiltInTools = options?.tools?.some(require_tools.isBuiltInTool);
        const hasResponsesOnlyKwargs = options?.previous_response_id != null || options?.text != null || options?.truncation != null || options?.include != null || options?.reasoning?.summary != null || this.reasoning?.summary != null;
        const hasCustomTools = options?.tools?.some(require_tools.isOpenAICustomTool) || options?.tools?.some(require_tools.isCustomTool);
        return this.useResponsesApi || usesBuiltInTools || hasResponsesOnlyKwargs || hasCustomTools || require_misc._modelPrefersResponsesAPI(this.model);
    }
    getLsParams(options) {
        const optionsWithDefaults = this._combineCallOptions(options);
        if (this._useResponsesApi(options)) return this.responses.getLsParams(optionsWithDefaults);
        return this.completions.getLsParams(optionsWithDefaults);
    }
    invocationParams(options) {
        const optionsWithDefaults = this._combineCallOptions(options);
        if (this._useResponsesApi(options)) return this.responses.invocationParams(optionsWithDefaults);
        return this.completions.invocationParams(optionsWithDefaults);
    }
    /** @ignore */ async _generate(messages, options, runManager) {
        if (this._useResponsesApi(options)) return this.responses._generate(messages, options);
        return this.completions._generate(messages, options, runManager);
    }
    async *_streamResponseChunks(messages, options, runManager) {
        if (this._useResponsesApi(options)) {
            yield* this.responses._streamResponseChunks(messages, this._combineCallOptions(options), runManager);
            return;
        }
        yield* this.completions._streamResponseChunks(messages, this._combineCallOptions(options), runManager);
    }
    withConfig(config) {
        const newModel = new ChatOpenAI(this.fields);
        newModel.defaultOptions = {
            ...this.defaultOptions,
            ...config
        };
        return newModel;
    }
};
//#endregion
exports.ChatOpenAI = ChatOpenAI; //# sourceMappingURL=index.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/azure/chat_models/index.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_common = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/azure/chat_models/common.cjs [app-route] (ecmascript)");
const require_completions = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/azure/chat_models/completions.cjs [app-route] (ecmascript)");
const require_responses = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/azure/chat_models/responses.cjs [app-route] (ecmascript)");
const require_index = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/index.cjs [app-route] (ecmascript)");
//#region src/azure/chat_models/index.ts
/**
* Azure OpenAI chat model integration.
*
* Setup:
* Install `@langchain/openai` and set the following environment variables:
*
* ```bash
* npm install @langchain/openai
* export AZURE_OPENAI_API_KEY="your-api-key"
* export AZURE_OPENAI_API_DEPLOYMENT_NAME="your-deployment-name"
* export AZURE_OPENAI_API_VERSION="your-version"
* export AZURE_OPENAI_BASE_PATH="your-base-path"
* ```
*
* ## [Constructor args](https://api.js.langchain.com/classes/langchain_openai.AzureChatOpenAI.html#constructor)
*
* ## [Runtime args](https://api.js.langchain.com/interfaces/langchain_openai.ChatOpenAICallOptions.html)
*
* Runtime args can be passed as the second argument to any of the base runnable methods `.invoke`. `.stream`, `.batch`, etc.
* They can also be passed via `.withConfig`, or the second arg in `.bindTools`, like shown in the examples below:
*
* ```typescript
* // When calling `.withConfig`, call options should be passed via the first argument
* const llmWithArgsBound = llm.withConfig({
*   stop: ["\n"],
*   tools: [...],
* });
*
* // When calling `.bindTools`, call options should be passed via the second argument
* const llmWithTools = llm.bindTools(
*   [...],
*   {
*     tool_choice: "auto",
*   }
* );
* ```
*
* ## Examples
*
* <details open>
* <summary><strong>Instantiate</strong></summary>
*
* ```typescript
* import { AzureChatOpenAI } from '@langchain/openai';
*
* const llm = new AzureChatOpenAI({
*   azureOpenAIApiKey: process.env.AZURE_OPENAI_API_KEY, // In Node.js defaults to process.env.AZURE_OPENAI_API_KEY
*   azureOpenAIApiInstanceName: process.env.AZURE_OPENAI_API_INSTANCE_NAME, // In Node.js defaults to process.env.AZURE_OPENAI_API_INSTANCE_NAME
*   azureOpenAIApiDeploymentName: process.env.AZURE_OPENAI_API_DEPLOYMENT_NAME, // In Node.js defaults to process.env.AZURE_OPENAI_API_DEPLOYMENT_NAME
*   azureOpenAIApiVersion: process.env.AZURE_OPENAI_API_VERSION, // In Node.js defaults to process.env.AZURE_OPENAI_API_VERSION
*   temperature: 0,
*   maxTokens: undefined,
*   timeout: undefined,
*   maxRetries: 2,
*   // apiKey: "...",
*   // baseUrl: "...",
*   // other params...
* });
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Invoking</strong></summary>
*
* ```typescript
* const input = `Translate "I love programming" into French.`;
*
* // Models also accept a list of chat messages or a formatted prompt
* const result = await llm.invoke(input);
* console.log(result);
* ```
*
* ```txt
* AIMessage {
*   "id": "chatcmpl-9u4Mpu44CbPjwYFkTbeoZgvzB00Tz",
*   "content": "J'adore la programmation.",
*   "response_metadata": {
*     "tokenUsage": {
*       "completionTokens": 5,
*       "promptTokens": 28,
*       "totalTokens": 33
*     },
*     "finish_reason": "stop",
*     "system_fingerprint": "fp_3aa7262c27"
*   },
*   "usage_metadata": {
*     "input_tokens": 28,
*     "output_tokens": 5,
*     "total_tokens": 33
*   }
* }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Streaming Chunks</strong></summary>
*
* ```typescript
* for await (const chunk of await llm.stream(input)) {
*   console.log(chunk);
* }
* ```
*
* ```txt
* AIMessageChunk {
*   "id": "chatcmpl-9u4NWB7yUeHCKdLr6jP3HpaOYHTqs",
*   "content": ""
* }
* AIMessageChunk {
*   "content": "J"
* }
* AIMessageChunk {
*   "content": "'adore"
* }
* AIMessageChunk {
*   "content": " la"
* }
* AIMessageChunk {
*   "content": " programmation",,
* }
* AIMessageChunk {
*   "content": ".",,
* }
* AIMessageChunk {
*   "content": "",
*   "response_metadata": {
*     "finish_reason": "stop",
*     "system_fingerprint": "fp_c9aa9c0491"
*   },
* }
* AIMessageChunk {
*   "content": "",
*   "usage_metadata": {
*     "input_tokens": 28,
*     "output_tokens": 5,
*     "total_tokens": 33
*   }
* }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Aggregate Streamed Chunks</strong></summary>
*
* ```typescript
* import { AIMessageChunk } from '@langchain/core/messages';
* import { concat } from '@langchain/core/utils/stream';
*
* const stream = await llm.stream(input);
* let full: AIMessageChunk | undefined;
* for await (const chunk of stream) {
*   full = !full ? chunk : concat(full, chunk);
* }
* console.log(full);
* ```
*
* ```txt
* AIMessageChunk {
*   "id": "chatcmpl-9u4PnX6Fy7OmK46DASy0bH6cxn5Xu",
*   "content": "J'adore la programmation.",
*   "response_metadata": {
*     "prompt": 0,
*     "completion": 0,
*     "finish_reason": "stop",
*   },
*   "usage_metadata": {
*     "input_tokens": 28,
*     "output_tokens": 5,
*     "total_tokens": 33
*   }
* }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Bind tools</strong></summary>
*
* ```typescript
* import { z } from 'zod';
*
* const GetWeather = {
*   name: "GetWeather",
*   description: "Get the current weather in a given location",
*   schema: z.object({
*     location: z.string().describe("The city and state, e.g. San Francisco, CA")
*   }),
* }
*
* const GetPopulation = {
*   name: "GetPopulation",
*   description: "Get the current population in a given location",
*   schema: z.object({
*     location: z.string().describe("The city and state, e.g. San Francisco, CA")
*   }),
* }
*
* const llmWithTools = llm.bindTools([GetWeather, GetPopulation]);
* const aiMsg = await llmWithTools.invoke(
*   "Which city is hotter today and which is bigger: LA or NY?"
* );
* console.log(aiMsg.tool_calls);
* ```
*
* ```txt
* [
*   {
*     name: 'GetWeather',
*     args: { location: 'Los Angeles, CA' },
*     type: 'tool_call',
*     id: 'call_uPU4FiFzoKAtMxfmPnfQL6UK'
*   },
*   {
*     name: 'GetWeather',
*     args: { location: 'New York, NY' },
*     type: 'tool_call',
*     id: 'call_UNkEwuQsHrGYqgDQuH9nPAtX'
*   },
*   {
*     name: 'GetPopulation',
*     args: { location: 'Los Angeles, CA' },
*     type: 'tool_call',
*     id: 'call_kL3OXxaq9OjIKqRTpvjaCH14'
*   },
*   {
*     name: 'GetPopulation',
*     args: { location: 'New York, NY' },
*     type: 'tool_call',
*     id: 'call_s9KQB1UWj45LLGaEnjz0179q'
*   }
* ]
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Structured Output</strong></summary>
*
* ```typescript
* import { z } from 'zod';
*
* const Joke = z.object({
*   setup: z.string().describe("The setup of the joke"),
*   punchline: z.string().describe("The punchline to the joke"),
*   rating: z.number().nullable().describe("How funny the joke is, from 1 to 10")
* }).describe('Joke to tell user.');
*
* const structuredLlm = llm.withStructuredOutput(Joke, { name: "Joke" });
* const jokeResult = await structuredLlm.invoke("Tell me a joke about cats");
* console.log(jokeResult);
* ```
*
* ```txt
* {
*   setup: 'Why was the cat sitting on the computer?',
*   punchline: 'Because it wanted to keep an eye on the mouse!',
*   rating: 7
* }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>JSON Object Response Format</strong></summary>
*
* ```typescript
* const jsonLlm = llm.withConfig({ response_format: { type: "json_object" } });
* const jsonLlmAiMsg = await jsonLlm.invoke(
*   "Return a JSON object with key 'randomInts' and a value of 10 random ints in [0-99]"
* );
* console.log(jsonLlmAiMsg.content);
* ```
*
* ```txt
* {
*   "randomInts": [23, 87, 45, 12, 78, 34, 56, 90, 11, 67]
* }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Multimodal</strong></summary>
*
* ```typescript
* import { HumanMessage } from '@langchain/core/messages';
*
* const imageUrl = "https://example.com/image.jpg";
* const imageData = await fetch(imageUrl).then(res => res.arrayBuffer());
* const base64Image = Buffer.from(imageData).toString('base64');
*
* const message = new HumanMessage({
*   content: [
*     { type: "text", text: "describe the weather in this image" },
*     {
*       type: "image_url",
*       image_url: { url: `data:image/jpeg;base64,${base64Image}` },
*     },
*   ]
* });
*
* const imageDescriptionAiMsg = await llm.invoke([message]);
* console.log(imageDescriptionAiMsg.content);
* ```
*
* ```txt
* The weather in the image appears to be clear and sunny. The sky is mostly blue with a few scattered white clouds, indicating fair weather. The bright sunlight is casting shadows on the green, grassy hill, suggesting it is a pleasant day with good visibility. There are no signs of rain or stormy conditions.
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Usage Metadata</strong></summary>
*
* ```typescript
* const aiMsgForMetadata = await llm.invoke(input);
* console.log(aiMsgForMetadata.usage_metadata);
* ```
*
* ```txt
* { input_tokens: 28, output_tokens: 5, total_tokens: 33 }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Logprobs</strong></summary>
*
* ```typescript
* const logprobsLlm = new ChatOpenAI({ model: "gpt-4o-mini", logprobs: true });
* const aiMsgForLogprobs = await logprobsLlm.invoke(input);
* console.log(aiMsgForLogprobs.response_metadata.logprobs);
* ```
*
* ```txt
* {
*   content: [
*     {
*       token: 'J',
*       logprob: -0.000050616763,
*       bytes: [Array],
*       top_logprobs: []
*     },
*     {
*       token: "'",
*       logprob: -0.01868736,
*       bytes: [Array],
*       top_logprobs: []
*     },
*     {
*       token: 'ad',
*       logprob: -0.0000030545007,
*       bytes: [Array],
*       top_logprobs: []
*     },
*     { token: 'ore', logprob: 0, bytes: [Array], top_logprobs: [] },
*     {
*       token: ' la',
*       logprob: -0.515404,
*       bytes: [Array],
*       top_logprobs: []
*     },
*     {
*       token: ' programm',
*       logprob: -0.0000118755715,
*       bytes: [Array],
*       top_logprobs: []
*     },
*     { token: 'ation', logprob: 0, bytes: [Array], top_logprobs: [] },
*     {
*       token: '.',
*       logprob: -0.0000037697225,
*       bytes: [Array],
*       top_logprobs: []
*     }
*   ],
*   refusal: null
* }
* ```
* </details>
*
* <br />
*
* <details>
* <summary><strong>Response Metadata</strong></summary>
*
* ```typescript
* const aiMsgForResponseMetadata = await llm.invoke(input);
* console.log(aiMsgForResponseMetadata.response_metadata);
* ```
*
* ```txt
* {
*   tokenUsage: { completionTokens: 5, promptTokens: 28, totalTokens: 33 },
*   finish_reason: 'stop',
*   system_fingerprint: 'fp_3aa7262c27'
* }
* ```
* </details>
*/ var AzureChatOpenAI = class extends require_index.ChatOpenAI {
    azureOpenAIApiVersion;
    azureOpenAIApiKey;
    azureADTokenProvider;
    azureOpenAIApiInstanceName;
    azureOpenAIApiDeploymentName;
    azureOpenAIBasePath;
    azureOpenAIEndpoint;
    _llmType() {
        return "azure_openai";
    }
    get lc_aliases() {
        return {
            ...super.lc_aliases,
            ...require_common.AZURE_ALIASES
        };
    }
    get lc_secrets() {
        return {
            ...super.lc_secrets,
            ...require_common.AZURE_SECRETS
        };
    }
    get lc_serializable_keys() {
        return [
            ...super.lc_serializable_keys,
            ...require_common.AZURE_SERIALIZABLE_KEYS
        ];
    }
    getLsParams(options) {
        const params = super.getLsParams(options);
        params.ls_provider = "azure";
        return params;
    }
    constructor(fields){
        super({
            ...fields,
            completions: new require_completions.AzureChatOpenAICompletions(fields),
            responses: new require_responses.AzureChatOpenAIResponses(fields)
        });
        require_common._constructAzureFields.call(this, fields);
    }
    /** @internal */ _getStructuredOutputMethod(config) {
        const ensuredConfig = {
            ...config
        };
        if (this.model.startsWith("gpt-4o")) {
            if (ensuredConfig?.method === void 0) return "functionCalling";
        }
        return super._getStructuredOutputMethod(ensuredConfig);
    }
    toJSON() {
        return require_common._serializeAzureChat.call(this, super.toJSON());
    }
};
//#endregion
exports.AzureChatOpenAI = AzureChatOpenAI; //# sourceMappingURL=index.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/llms.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const require_client = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/client.cjs [app-route] (ecmascript)");
const require_azure = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/azure.cjs [app-route] (ecmascript)");
const openai = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/openai@6.15.0_ws@8.19.0_zod@4.2.1/node_modules/openai/index.js [app-route] (ecmascript)"));
const __langchain_core_outputs = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/outputs.cjs [app-route] (ecmascript)"));
const __langchain_core_utils_env = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/env.cjs [app-route] (ecmascript)"));
const __langchain_core_language_models_base = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/language_models/base.cjs [app-route] (ecmascript)"));
const __langchain_core_language_models_llms = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/language_models/llms.cjs [app-route] (ecmascript)"));
const __langchain_core_utils_chunk_array = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/chunk_array.cjs [app-route] (ecmascript)"));
//#region src/llms.ts
/**
* Wrapper around OpenAI large language models.
*
* To use you should have the `openai` package installed, with the
* `OPENAI_API_KEY` environment variable set.
*
* To use with Azure, import the `AzureOpenAI` class.
*
* @remarks
* Any parameters that are valid to be passed to {@link
* https://platform.openai.com/docs/api-reference/completions/create |
* `openai.createCompletion`} can be passed through {@link modelKwargs}, even
* if not explicitly available on this class.
* @example
* ```typescript
* const model = new OpenAI({
*   modelName: "gpt-4",
*   temperature: 0.7,
*   maxTokens: 1000,
*   maxRetries: 5,
* });
*
* const res = await model.invoke(
*   "Question: What would be a good company name for a company that makes colorful socks?\nAnswer:"
* );
* console.log({ res });
* ```
*/ var OpenAI = class extends __langchain_core_language_models_llms.BaseLLM {
    static lc_name() {
        return "OpenAI";
    }
    get callKeys() {
        return [
            ...super.callKeys,
            "options"
        ];
    }
    lc_serializable = true;
    get lc_secrets() {
        return {
            openAIApiKey: "OPENAI_API_KEY",
            apiKey: "OPENAI_API_KEY",
            organization: "OPENAI_ORGANIZATION"
        };
    }
    get lc_aliases() {
        return {
            modelName: "model",
            openAIApiKey: "openai_api_key",
            apiKey: "openai_api_key"
        };
    }
    temperature;
    maxTokens;
    topP;
    frequencyPenalty;
    presencePenalty;
    n = 1;
    bestOf;
    logitBias;
    model = "gpt-3.5-turbo-instruct";
    /** @deprecated Use "model" instead */ modelName;
    modelKwargs;
    batchSize = 20;
    timeout;
    stop;
    stopSequences;
    user;
    streaming = false;
    openAIApiKey;
    apiKey;
    organization;
    client;
    clientConfig;
    constructor(fields){
        super(fields ?? {});
        this.openAIApiKey = fields?.apiKey ?? fields?.openAIApiKey ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("OPENAI_API_KEY");
        this.apiKey = this.openAIApiKey;
        this.organization = fields?.configuration?.organization ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("OPENAI_ORGANIZATION");
        this.model = fields?.model ?? fields?.modelName ?? this.model;
        if ((this.model?.startsWith("gpt-3.5-turbo") || this.model?.startsWith("gpt-4") || this.model?.startsWith("o1")) && !this.model?.includes("-instruct")) throw new Error([
            `Your chosen OpenAI model, "${this.model}", is a chat model and not a text-in/text-out LLM.`,
            `Passing it into the "OpenAI" class is no longer supported.`,
            `Please use the "ChatOpenAI" class instead.`,
            "",
            `See this page for more information:`,
            "|",
            `└> https://js.langchain.com/docs/integrations/chat/openai`
        ].join("\n"));
        this.modelName = this.model;
        this.modelKwargs = fields?.modelKwargs ?? {};
        this.batchSize = fields?.batchSize ?? this.batchSize;
        this.timeout = fields?.timeout;
        this.temperature = fields?.temperature ?? this.temperature;
        this.maxTokens = fields?.maxTokens ?? this.maxTokens;
        this.topP = fields?.topP ?? this.topP;
        this.frequencyPenalty = fields?.frequencyPenalty ?? this.frequencyPenalty;
        this.presencePenalty = fields?.presencePenalty ?? this.presencePenalty;
        this.n = fields?.n ?? this.n;
        this.bestOf = fields?.bestOf ?? this.bestOf;
        this.logitBias = fields?.logitBias;
        this.stop = fields?.stopSequences ?? fields?.stop;
        this.stopSequences = this.stop;
        this.user = fields?.user;
        this.streaming = fields?.streaming ?? false;
        if (this.streaming && this.bestOf && this.bestOf > 1) throw new Error("Cannot stream results when bestOf > 1");
        this.clientConfig = {
            apiKey: this.apiKey,
            organization: this.organization,
            dangerouslyAllowBrowser: true,
            ...fields?.configuration
        };
    }
    /**
	* Get the parameters used to invoke the model
	*/ invocationParams(options) {
        return {
            model: this.model,
            temperature: this.temperature,
            max_tokens: this.maxTokens,
            top_p: this.topP,
            frequency_penalty: this.frequencyPenalty,
            presence_penalty: this.presencePenalty,
            n: this.n,
            best_of: this.bestOf,
            logit_bias: this.logitBias,
            stop: options?.stop ?? this.stopSequences,
            user: this.user,
            stream: this.streaming,
            ...this.modelKwargs
        };
    }
    /** @ignore */ _identifyingParams() {
        return {
            model_name: this.model,
            ...this.invocationParams(),
            ...this.clientConfig
        };
    }
    /**
	* Get the identifying parameters for the model
	*/ identifyingParams() {
        return this._identifyingParams();
    }
    /**
	* Call out to OpenAI's endpoint with k unique prompts
	*
	* @param [prompts] - The prompts to pass into the model.
	* @param [options] - Optional list of stop words to use when generating.
	* @param [runManager] - Optional callback manager to use when generating.
	*
	* @returns The full LLM output.
	*
	* @example
	* ```ts
	* import { OpenAI } from "langchain/llms/openai";
	* const openai = new OpenAI();
	* const response = await openai.generate(["Tell me a joke."]);
	* ```
	*/ async _generate(prompts, options, runManager) {
        const subPrompts = (0, __langchain_core_utils_chunk_array.chunkArray)(prompts, this.batchSize);
        const choices = [];
        const tokenUsage = {};
        const params = this.invocationParams(options);
        if (params.max_tokens === -1) {
            if (prompts.length !== 1) throw new Error("max_tokens set to -1 not supported for multiple inputs");
            params.max_tokens = await (0, __langchain_core_language_models_base.calculateMaxTokens)({
                prompt: prompts[0],
                modelName: this.model
            });
        }
        for(let i = 0; i < subPrompts.length; i += 1){
            const data = params.stream ? await (async ()=>{
                const choices$1 = [];
                let response;
                const stream = await this.completionWithRetry({
                    ...params,
                    stream: true,
                    prompt: subPrompts[i]
                }, options);
                for await (const message of stream){
                    if (!response) response = {
                        id: message.id,
                        object: message.object,
                        created: message.created,
                        model: message.model
                    };
                    for (const part of message.choices){
                        if (!choices$1[part.index]) choices$1[part.index] = part;
                        else {
                            const choice = choices$1[part.index];
                            choice.text += part.text;
                            choice.finish_reason = part.finish_reason;
                            choice.logprobs = part.logprobs;
                        }
                        runManager?.handleLLMNewToken(part.text, {
                            prompt: Math.floor(part.index / this.n),
                            completion: part.index % this.n
                        });
                    }
                }
                if (options.signal?.aborted) throw new Error("AbortError");
                return {
                    ...response,
                    choices: choices$1
                };
            })() : await this.completionWithRetry({
                ...params,
                stream: false,
                prompt: subPrompts[i]
            }, {
                signal: options.signal,
                ...options.options
            });
            choices.push(...data.choices);
            const { completion_tokens: completionTokens, prompt_tokens: promptTokens, total_tokens: totalTokens } = data.usage ? data.usage : {
                completion_tokens: void 0,
                prompt_tokens: void 0,
                total_tokens: void 0
            };
            if (completionTokens) tokenUsage.completionTokens = (tokenUsage.completionTokens ?? 0) + completionTokens;
            if (promptTokens) tokenUsage.promptTokens = (tokenUsage.promptTokens ?? 0) + promptTokens;
            if (totalTokens) tokenUsage.totalTokens = (tokenUsage.totalTokens ?? 0) + totalTokens;
        }
        const generations = (0, __langchain_core_utils_chunk_array.chunkArray)(choices, this.n).map((promptChoices)=>promptChoices.map((choice)=>({
                    text: choice.text ?? "",
                    generationInfo: {
                        finishReason: choice.finish_reason,
                        logprobs: choice.logprobs
                    }
                })));
        return {
            generations,
            llmOutput: {
                tokenUsage
            }
        };
    }
    async *_streamResponseChunks(input, options, runManager) {
        const params = {
            ...this.invocationParams(options),
            prompt: input,
            stream: true
        };
        const stream = await this.completionWithRetry(params, options);
        for await (const data of stream){
            const choice = data?.choices[0];
            if (!choice) continue;
            const chunk = new __langchain_core_outputs.GenerationChunk({
                text: choice.text,
                generationInfo: {
                    finishReason: choice.finish_reason
                }
            });
            yield chunk;
            runManager?.handleLLMNewToken(chunk.text ?? "");
        }
        if (options.signal?.aborted) throw new Error("AbortError");
    }
    async completionWithRetry(request, options) {
        const requestOptions = this._getClientOptions(options);
        return this.caller.call(async ()=>{
            try {
                const res = await this.client.completions.create(request, requestOptions);
                return res;
            } catch (e) {
                const error = require_client.wrapOpenAIClientError(e);
                throw error;
            }
        });
    }
    /**
	* Calls the OpenAI API with retry logic in case of failures.
	* @param request The request to send to the OpenAI API.
	* @param options Optional configuration for the API call.
	* @returns The response from the OpenAI API.
	*/ _getClientOptions(options) {
        if (!this.client) {
            const openAIEndpointConfig = {
                baseURL: this.clientConfig.baseURL
            };
            const endpoint = require_azure.getEndpoint(openAIEndpointConfig);
            const params = {
                ...this.clientConfig,
                baseURL: endpoint,
                timeout: this.timeout,
                maxRetries: 0
            };
            if (!params.baseURL) delete params.baseURL;
            params.defaultHeaders = require_azure.getHeadersWithUserAgent(params.defaultHeaders);
            this.client = new openai.OpenAI(params);
        }
        const requestOptions = {
            ...this.clientConfig,
            ...options
        };
        return requestOptions;
    }
    _llmType() {
        return "openai";
    }
};
//#endregion
exports.OpenAI = OpenAI; //# sourceMappingURL=llms.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/azure/llms.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const require_azure = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/azure.cjs [app-route] (ecmascript)");
const require_llms = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/llms.cjs [app-route] (ecmascript)");
const openai = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/openai@6.15.0_ws@8.19.0_zod@4.2.1/node_modules/openai/index.js [app-route] (ecmascript)"));
const __langchain_core_utils_env = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/env.cjs [app-route] (ecmascript)"));
//#region src/azure/llms.ts
var AzureOpenAI = class extends require_llms.OpenAI {
    azureOpenAIApiVersion;
    azureOpenAIApiKey;
    azureADTokenProvider;
    azureOpenAIApiInstanceName;
    azureOpenAIApiDeploymentName;
    azureOpenAIBasePath;
    azureOpenAIEndpoint;
    get lc_aliases() {
        return {
            ...super.lc_aliases,
            openAIApiKey: "openai_api_key",
            openAIApiVersion: "openai_api_version",
            openAIBasePath: "openai_api_base",
            deploymentName: "deployment_name",
            azureOpenAIEndpoint: "azure_endpoint",
            azureOpenAIApiVersion: "openai_api_version",
            azureOpenAIBasePath: "openai_api_base",
            azureOpenAIApiDeploymentName: "deployment_name"
        };
    }
    get lc_secrets() {
        return {
            ...super.lc_secrets,
            azureOpenAIApiKey: "AZURE_OPENAI_API_KEY"
        };
    }
    constructor(fields){
        super(fields);
        this.azureOpenAIApiDeploymentName = (fields?.azureOpenAIApiCompletionsDeploymentName || fields?.azureOpenAIApiDeploymentName) ?? ((0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_API_COMPLETIONS_DEPLOYMENT_NAME") || (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_API_DEPLOYMENT_NAME"));
        this.azureOpenAIApiKey = fields?.azureOpenAIApiKey ?? (typeof fields?.openAIApiKey === "string" ? fields?.openAIApiKey : void 0) ?? (typeof fields?.apiKey === "string" ? fields?.apiKey : void 0) ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_API_KEY");
        this.azureOpenAIApiInstanceName = fields?.azureOpenAIApiInstanceName ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_API_INSTANCE_NAME");
        this.azureOpenAIApiVersion = fields?.azureOpenAIApiVersion ?? fields?.openAIApiVersion ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_API_VERSION");
        this.azureOpenAIBasePath = fields?.azureOpenAIBasePath ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_BASE_PATH");
        this.azureOpenAIEndpoint = fields?.azureOpenAIEndpoint ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_ENDPOINT");
        this.azureADTokenProvider = fields?.azureADTokenProvider;
        if (!this.azureOpenAIApiKey && !this.apiKey && !this.azureADTokenProvider) throw new Error("Azure OpenAI API key or Token Provider not found");
    }
    _getClientOptions(options) {
        if (!this.client) {
            const openAIEndpointConfig = {
                azureOpenAIApiDeploymentName: this.azureOpenAIApiDeploymentName,
                azureOpenAIApiInstanceName: this.azureOpenAIApiInstanceName,
                azureOpenAIApiKey: this.azureOpenAIApiKey,
                azureOpenAIBasePath: this.azureOpenAIBasePath,
                azureADTokenProvider: this.azureADTokenProvider,
                baseURL: this.clientConfig.baseURL
            };
            const endpoint = require_azure.getEndpoint(openAIEndpointConfig);
            const { apiKey: existingApiKey, ...clientConfigRest } = this.clientConfig;
            const params = {
                ...clientConfigRest,
                baseURL: endpoint,
                timeout: this.timeout,
                maxRetries: 0
            };
            if (!this.azureADTokenProvider) params.apiKey = openAIEndpointConfig.azureOpenAIApiKey;
            if (!params.baseURL) delete params.baseURL;
            params.defaultHeaders = require_azure.getHeadersWithUserAgent(params.defaultHeaders, true, "2.0.0");
            this.client = new openai.AzureOpenAI({
                apiVersion: this.azureOpenAIApiVersion,
                azureADTokenProvider: this.azureADTokenProvider,
                ...params
            });
        }
        const requestOptions = {
            ...this.clientConfig,
            ...options
        };
        if (this.azureOpenAIApiKey) {
            requestOptions.headers = {
                "api-key": this.azureOpenAIApiKey,
                ...requestOptions.headers
            };
            requestOptions.query = {
                "api-version": this.azureOpenAIApiVersion,
                ...requestOptions.query
            };
        }
        return requestOptions;
    }
    toJSON() {
        const json = super.toJSON();
        function isRecord(obj) {
            return typeof obj === "object" && obj != null;
        }
        if (isRecord(json) && isRecord(json.kwargs)) {
            delete json.kwargs.azure_openai_base_path;
            delete json.kwargs.azure_openai_api_deployment_name;
            delete json.kwargs.azure_openai_api_key;
            delete json.kwargs.azure_openai_api_version;
            delete json.kwargs.azure_open_ai_base_path;
        }
        return json;
    }
};
//#endregion
exports.AzureOpenAI = AzureOpenAI; //# sourceMappingURL=llms.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/embeddings.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const require_client = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/client.cjs [app-route] (ecmascript)");
const require_azure = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/azure.cjs [app-route] (ecmascript)");
const openai = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/openai@6.15.0_ws@8.19.0_zod@4.2.1/node_modules/openai/index.js [app-route] (ecmascript)"));
const __langchain_core_utils_env = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/env.cjs [app-route] (ecmascript)"));
const __langchain_core_utils_chunk_array = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/chunk_array.cjs [app-route] (ecmascript)"));
const __langchain_core_embeddings = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/embeddings.cjs [app-route] (ecmascript)"));
//#region src/embeddings.ts
/**
* Class for generating embeddings using the OpenAI API.
*
* To use with Azure, import the `AzureOpenAIEmbeddings` class.
*
* @example
* ```typescript
* // Embed a query using OpenAIEmbeddings to generate embeddings for a given text
* const model = new OpenAIEmbeddings();
* const res = await model.embedQuery(
*   "What would be a good company name for a company that makes colorful socks?",
* );
* console.log({ res });
*
* ```
*/ var OpenAIEmbeddings = class extends __langchain_core_embeddings.Embeddings {
    model = "text-embedding-ada-002";
    /** @deprecated Use "model" instead */ modelName;
    batchSize = 512;
    stripNewLines = true;
    /**
	* The number of dimensions the resulting output embeddings should have.
	* Only supported in `text-embedding-3` and later models.
	*/ dimensions;
    timeout;
    organization;
    encodingFormat;
    client;
    clientConfig;
    apiKey;
    constructor(fields){
        const fieldsWithDefaults = {
            maxConcurrency: 2,
            ...fields
        };
        super(fieldsWithDefaults);
        const apiKey = fieldsWithDefaults?.apiKey ?? fieldsWithDefaults?.openAIApiKey ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("OPENAI_API_KEY");
        this.organization = fieldsWithDefaults?.configuration?.organization ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("OPENAI_ORGANIZATION");
        this.model = fieldsWithDefaults?.model ?? fieldsWithDefaults?.modelName ?? this.model;
        this.modelName = this.model;
        this.batchSize = fieldsWithDefaults?.batchSize ?? this.batchSize;
        this.stripNewLines = fieldsWithDefaults?.stripNewLines ?? this.stripNewLines;
        this.timeout = fieldsWithDefaults?.timeout;
        this.dimensions = fieldsWithDefaults?.dimensions;
        this.encodingFormat = fieldsWithDefaults?.encodingFormat;
        this.clientConfig = {
            apiKey,
            organization: this.organization,
            dangerouslyAllowBrowser: true,
            ...fields?.configuration
        };
    }
    /**
	* Method to generate embeddings for an array of documents. Splits the
	* documents into batches and makes requests to the OpenAI API to generate
	* embeddings.
	* @param texts Array of documents to generate embeddings for.
	* @returns Promise that resolves to a 2D array of embeddings for each document.
	*/ async embedDocuments(texts) {
        const batches = (0, __langchain_core_utils_chunk_array.chunkArray)(this.stripNewLines ? texts.map((t)=>t.replace(/\n/g, " ")) : texts, this.batchSize);
        const batchRequests = batches.map((batch)=>{
            const params = {
                model: this.model,
                input: batch
            };
            if (this.dimensions) params.dimensions = this.dimensions;
            if (this.encodingFormat) params.encoding_format = this.encodingFormat;
            return this.embeddingWithRetry(params);
        });
        const batchResponses = await Promise.all(batchRequests);
        const embeddings = [];
        for(let i = 0; i < batchResponses.length; i += 1){
            const batch = batches[i];
            const { data: batchResponse } = batchResponses[i];
            for(let j = 0; j < batch.length; j += 1)embeddings.push(batchResponse[j].embedding);
        }
        return embeddings;
    }
    /**
	* Method to generate an embedding for a single document. Calls the
	* embeddingWithRetry method with the document as the input.
	* @param text Document to generate an embedding for.
	* @returns Promise that resolves to an embedding for the document.
	*/ async embedQuery(text) {
        const params = {
            model: this.model,
            input: this.stripNewLines ? text.replace(/\n/g, " ") : text
        };
        if (this.dimensions) params.dimensions = this.dimensions;
        if (this.encodingFormat) params.encoding_format = this.encodingFormat;
        const { data } = await this.embeddingWithRetry(params);
        return data[0].embedding;
    }
    /**
	* Private method to make a request to the OpenAI API to generate
	* embeddings. Handles the retry logic and returns the response from the
	* API.
	* @param request Request to send to the OpenAI API.
	* @returns Promise that resolves to the response from the API.
	*/ async embeddingWithRetry(request) {
        if (!this.client) {
            const openAIEndpointConfig = {
                baseURL: this.clientConfig.baseURL
            };
            const endpoint = require_azure.getEndpoint(openAIEndpointConfig);
            const params = {
                ...this.clientConfig,
                baseURL: endpoint,
                timeout: this.timeout,
                maxRetries: 0
            };
            if (!params.baseURL) delete params.baseURL;
            params.defaultHeaders = require_azure.getHeadersWithUserAgent(params.defaultHeaders);
            this.client = new openai.OpenAI(params);
        }
        const requestOptions = {};
        return this.caller.call(async ()=>{
            try {
                const res = await this.client.embeddings.create(request, requestOptions);
                return res;
            } catch (e) {
                const error = require_client.wrapOpenAIClientError(e);
                throw error;
            }
        });
    }
};
//#endregion
exports.OpenAIEmbeddings = OpenAIEmbeddings; //# sourceMappingURL=embeddings.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/azure/embeddings.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const require_client = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/client.cjs [app-route] (ecmascript)");
const require_azure = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/azure.cjs [app-route] (ecmascript)");
const require_embeddings = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/embeddings.cjs [app-route] (ecmascript)");
const openai = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/openai@6.15.0_ws@8.19.0_zod@4.2.1/node_modules/openai/index.js [app-route] (ecmascript)"));
const __langchain_core_utils_env = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/env.cjs [app-route] (ecmascript)"));
//#region src/azure/embeddings.ts
var AzureOpenAIEmbeddings = class extends require_embeddings.OpenAIEmbeddings {
    azureOpenAIApiVersion;
    azureOpenAIApiKey;
    azureADTokenProvider;
    azureOpenAIApiInstanceName;
    azureOpenAIApiDeploymentName;
    azureOpenAIBasePath;
    constructor(fields){
        super(fields);
        this.batchSize = fields?.batchSize ?? 1;
        this.azureOpenAIApiKey = fields?.azureOpenAIApiKey ?? (typeof fields?.apiKey === "string" ? fields?.apiKey : void 0) ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_API_KEY");
        this.azureOpenAIApiVersion = fields?.azureOpenAIApiVersion ?? fields?.openAIApiVersion ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_API_VERSION");
        this.azureOpenAIBasePath = fields?.azureOpenAIBasePath ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_BASE_PATH");
        this.azureOpenAIApiInstanceName = fields?.azureOpenAIApiInstanceName ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_API_INSTANCE_NAME");
        this.azureOpenAIApiDeploymentName = (fields?.azureOpenAIApiEmbeddingsDeploymentName || fields?.azureOpenAIApiDeploymentName) ?? ((0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_API_EMBEDDINGS_DEPLOYMENT_NAME") || (0, __langchain_core_utils_env.getEnvironmentVariable)("AZURE_OPENAI_API_DEPLOYMENT_NAME"));
        this.azureADTokenProvider = fields?.azureADTokenProvider;
    }
    async embeddingWithRetry(request) {
        if (!this.client) {
            const openAIEndpointConfig = {
                azureOpenAIApiDeploymentName: this.azureOpenAIApiDeploymentName,
                azureOpenAIApiInstanceName: this.azureOpenAIApiInstanceName,
                azureOpenAIApiKey: this.azureOpenAIApiKey,
                azureOpenAIBasePath: this.azureOpenAIBasePath,
                azureADTokenProvider: this.azureADTokenProvider,
                baseURL: this.clientConfig.baseURL
            };
            const endpoint = require_azure.getEndpoint(openAIEndpointConfig);
            const { apiKey: existingApiKey, ...clientConfigRest } = this.clientConfig;
            const params = {
                ...clientConfigRest,
                baseURL: endpoint,
                timeout: this.timeout,
                maxRetries: 0
            };
            if (!this.azureADTokenProvider) params.apiKey = openAIEndpointConfig.azureOpenAIApiKey;
            if (!params.baseURL) delete params.baseURL;
            params.defaultHeaders = require_azure.getHeadersWithUserAgent(params.defaultHeaders, true, "2.0.0");
            this.client = new openai.AzureOpenAI({
                apiVersion: this.azureOpenAIApiVersion,
                azureADTokenProvider: this.azureADTokenProvider,
                deployment: this.azureOpenAIApiDeploymentName,
                ...params
            });
        }
        const requestOptions = {};
        if (this.azureOpenAIApiKey) {
            requestOptions.headers = {
                "api-key": this.azureOpenAIApiKey,
                ...requestOptions.headers
            };
            requestOptions.query = {
                "api-version": this.azureOpenAIApiVersion,
                ...requestOptions.query
            };
        }
        return this.caller.call(async ()=>{
            try {
                const res = await this.client.embeddings.create(request, requestOptions);
                return res;
            } catch (e) {
                const error = require_client.wrapOpenAIClientError(e);
                throw error;
            }
        });
    }
};
//#endregion
exports.AzureOpenAIEmbeddings = AzureOpenAIEmbeddings; //# sourceMappingURL=embeddings.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/dalle.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const openai = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/openai@6.15.0_ws@8.19.0_zod@4.2.1/node_modules/openai/index.js [app-route] (ecmascript)"));
const __langchain_core_utils_env = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/utils/env.cjs [app-route] (ecmascript)"));
const __langchain_core_tools = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/tools/index.cjs [app-route] (ecmascript)"));
//#region src/tools/dalle.ts
/**
* A tool for generating images with Open AIs Dall-E 2 or 3 API.
*/ var DallEAPIWrapper = class extends __langchain_core_tools.Tool {
    static lc_name() {
        return "DallEAPIWrapper";
    }
    name = "dalle_api_wrapper";
    description = "A wrapper around OpenAI DALL-E API. Useful for when you need to generate images from a text description. Input should be an image description.";
    client;
    static toolName = "dalle_api_wrapper";
    model = "dall-e-3";
    style = "vivid";
    quality = "standard";
    n = 1;
    size = "1024x1024";
    dallEResponseFormat = "url";
    user;
    constructor(fields){
        if (fields?.responseFormat !== void 0 && [
            "url",
            "b64_json"
        ].includes(fields.responseFormat)) {
            fields.dallEResponseFormat = fields.responseFormat;
            fields.responseFormat = "content";
        }
        super(fields);
        const openAIApiKey = fields?.apiKey ?? fields?.openAIApiKey ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("OPENAI_API_KEY");
        const organization = fields?.organization ?? (0, __langchain_core_utils_env.getEnvironmentVariable)("OPENAI_ORGANIZATION");
        const clientConfig = {
            apiKey: openAIApiKey,
            organization,
            dangerouslyAllowBrowser: true,
            baseURL: fields?.baseUrl
        };
        this.client = new openai.OpenAI(clientConfig);
        this.model = fields?.model ?? fields?.modelName ?? this.model;
        this.style = fields?.style ?? this.style;
        this.quality = fields?.quality ?? this.quality;
        this.n = fields?.n ?? this.n;
        this.size = fields?.size ?? this.size;
        this.dallEResponseFormat = fields?.dallEResponseFormat ?? this.dallEResponseFormat;
        this.user = fields?.user;
    }
    /**
	* Processes the API response if multiple images are generated.
	* Returns a list of MessageContentImageUrl objects. If the response
	* format is `url`, then the `image_url` field will contain the URL.
	* If it is `b64_json`, then the `image_url` field will contain an object
	* with a `url` field with the base64 encoded image.
	*
	* @param {OpenAIClient.Images.ImagesResponse[]} response The API response
	* @returns {MessageContentImageUrl[]}
	*/ processMultipleGeneratedUrls(response) {
        if (this.dallEResponseFormat === "url") return response.flatMap((res)=>{
            const imageUrlContent = res.data?.flatMap((item)=>{
                if (!item.url) return [];
                return {
                    type: "image_url",
                    image_url: item.url
                };
            }).filter((item)=>item !== void 0 && item.type === "image_url" && typeof item.image_url === "string" && item.image_url !== void 0) ?? [];
            return imageUrlContent;
        });
        else return response.flatMap((res)=>{
            const b64Content = res.data?.flatMap((item)=>{
                if (!item.b64_json) return [];
                return {
                    type: "image_url",
                    image_url: {
                        url: item.b64_json
                    }
                };
            }).filter((item)=>item !== void 0 && item.type === "image_url" && typeof item.image_url === "object" && "url" in item.image_url && typeof item.image_url.url === "string" && item.image_url.url !== void 0) ?? [];
            return b64Content;
        });
    }
    /** @ignore */ async _call(input) {
        const generateImageFields = {
            model: this.model,
            prompt: input,
            n: 1,
            size: this.size,
            response_format: this.dallEResponseFormat,
            style: this.style,
            quality: this.quality,
            user: this.user
        };
        if (this.n > 1) {
            const results = await Promise.all(Array.from({
                length: this.n
            }).map(()=>this.client.images.generate(generateImageFields)));
            return this.processMultipleGeneratedUrls(results);
        }
        const response = await this.client.images.generate(generateImageFields);
        let data = "";
        if (this.dallEResponseFormat === "url") [data] = response.data?.map((item)=>item.url).filter((url)=>url !== "undefined") ?? [];
        else [data] = response.data?.map((item)=>item.b64_json).filter((b64_json)=>b64_json !== "undefined") ?? [];
        return data;
    }
};
//#endregion
exports.DallEAPIWrapper = DallEAPIWrapper; //# sourceMappingURL=dalle.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/webSearch.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

//#region src/tools/webSearch.ts
/**
* Creates a web search tool that allows OpenAI models to search the web
* for up-to-date information before generating a response.
*
* Web search supports three main types:
* 1. **Non-reasoning web search**: Quick lookups where the model passes queries
*    directly to the search tool.
* 2. **Agentic search with reasoning models**: The model actively manages the
*    search process, analyzing results and deciding whether to keep searching.
* 3. **Deep research**: Extended investigations using models like `o3-deep-research`
*    or `gpt-5` with high reasoning effort.
*
* @see {@link https://platform.openai.com/docs/guides/tools-web-search | OpenAI Web Search Documentation}
* @param options - Configuration options for the web search tool
* @returns A web search tool definition to be passed to the OpenAI Responses API
*
* @example
* ```typescript
* import { ChatOpenAI, tools } from "@langchain/openai";
*
* const model = new ChatOpenAI({
*   model: "gpt-4o",
* });
*
* // Basic usage
* const response = await model.invoke("What was a positive news story from today?", {
*   tools: [tools.webSearch()],
* });
*
* // With domain filtering
* const filteredResponse = await model.invoke("Latest AI research news", {
*   tools: [tools.webSearch({
*     filters: {
*       allowedDomains: ["arxiv.org", "nature.com", "science.org"],
*     },
*   })],
* });
*
* // With user location for geographic relevance
* const localResponse = await model.invoke("What are the best restaurants near me?", {
*   tools: [tools.webSearch({
*     userLocation: {
*       type: "approximate",
*       country: "US",
*       city: "San Francisco",
*       region: "California",
*       timezone: "America/Los_Angeles",
*     },
*   })],
* });
*
* // Cache-only mode (no live internet access)
* const cachedResponse = await model.invoke("Find information about OpenAI", {
*   tools: [tools.webSearch({
*     externalWebAccess: false,
*   })],
* });
* ```
*/ function webSearch(options) {
    return {
        type: "web_search",
        filters: options?.filters?.allowedDomains ? {
            allowed_domains: options.filters.allowedDomains
        } : void 0,
        user_location: options?.userLocation,
        search_context_size: options?.search_context_size
    };
}
//#endregion
exports.webSearch = webSearch; //# sourceMappingURL=webSearch.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/mcp.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

//#region src/tools/mcp.ts
/**
* Converts a McpToolFilter to the API format.
*/ function convertToolFilter(filter) {
    return {
        tool_names: filter.toolNames,
        read_only: filter.readOnly
    };
}
/**
* Converts allowed_tools option to API format.
*/ function convertAllowedTools(allowedTools) {
    if (!allowedTools) return void 0;
    if (Array.isArray(allowedTools)) return allowedTools;
    return convertToolFilter(allowedTools);
}
/**
* Converts require_approval option to API format.
*/ function convertRequireApproval(requireApproval) {
    if (!requireApproval) return void 0;
    if (typeof requireApproval === "string") return requireApproval;
    return {
        always: requireApproval.always ? convertToolFilter(requireApproval.always) : void 0,
        never: requireApproval.never ? convertToolFilter(requireApproval.never) : void 0
    };
}
function mcp(options) {
    const baseConfig = {
        type: "mcp",
        server_label: options.serverLabel,
        allowed_tools: convertAllowedTools(options.allowedTools),
        authorization: options.authorization,
        headers: options.headers,
        require_approval: convertRequireApproval(options.requireApproval),
        server_description: options.serverDescription
    };
    if ("serverUrl" in options) return {
        ...baseConfig,
        server_url: options.serverUrl
    };
    return {
        ...baseConfig,
        connector_id: options.connectorId
    };
}
//#endregion
exports.mcp = mcp; //# sourceMappingURL=mcp.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/codeInterpreter.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

//#region src/tools/codeInterpreter.ts
/**
* Converts container options to the API format.
*/ function convertContainer(container) {
    if (typeof container === "string") return container;
    return {
        type: "auto",
        file_ids: container?.fileIds,
        memory_limit: container?.memoryLimit
    };
}
/**
* Creates a Code Interpreter tool that allows models to write and run Python code
* in a sandboxed environment to solve complex problems.
*
* Use Code Interpreter for:
* - **Data analysis**: Processing files with diverse data and formatting
* - **File generation**: Creating files with data and images of graphs
* - **Iterative coding**: Writing and running code iteratively to solve problems
* - **Visual intelligence**: Cropping, zooming, rotating, and transforming images
*
* The tool runs in a container, which is a fully sandboxed virtual machine.
* Containers can be created automatically (auto mode) or explicitly via the
* `/v1/containers` endpoint.
*
* @see {@link https://platform.openai.com/docs/guides/tools-code-interpreter | OpenAI Code Interpreter Documentation}
*
* @param options - Configuration options for the Code Interpreter tool
* @returns A Code Interpreter tool definition to be passed to the OpenAI Responses API
*
* @example
* ```typescript
* import { ChatOpenAI, tools } from "@langchain/openai";
*
* const model = new ChatOpenAI({ model: "gpt-4.1" });
*
* // Basic usage with auto container (default 1GB memory)
* const response = await model.invoke(
*   "Solve the equation 3x + 11 = 14",
*   { tools: [tools.codeInterpreter()] }
* );
*
* // With increased memory limit for larger computations
* const response = await model.invoke(
*   "Analyze this large dataset and create visualizations",
*   {
*     tools: [tools.codeInterpreter({
*       container: { memoryLimit: "4g" }
*     })]
*   }
* );
*
* // With specific files available to the code
* const response = await model.invoke(
*   "Process the uploaded CSV file",
*   {
*     tools: [tools.codeInterpreter({
*       container: {
*         memoryLimit: "4g",
*         fileIds: ["file-abc123", "file-def456"]
*       }
*     })]
*   }
* );
*
* // Using an explicit container ID (created via /v1/containers)
* const response = await model.invoke(
*   "Continue working with the data",
*   {
*     tools: [tools.codeInterpreter({
*       container: "cntr_abc123"
*     })]
*   }
* );
* ```
*
* @remarks
* - Containers expire after 20 minutes of inactivity
* - While called "Code Interpreter", the model knows it as the "python tool"
* - For explicit prompting, ask for "the python tool" in your prompts
* - Files in model input are automatically uploaded to the container
* - Generated files are returned as `container_file_citation` annotations
*/ function codeInterpreter(options) {
    return {
        type: "code_interpreter",
        container: convertContainer(options?.container)
    };
}
//#endregion
exports.codeInterpreter = codeInterpreter; //# sourceMappingURL=codeInterpreter.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/fileSearch.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

//#region src/tools/fileSearch.ts
/**
* Converts ranking options to the API format.
*/ function convertRankingOptions(options) {
    if (!options) return void 0;
    return {
        ranker: options.ranker,
        score_threshold: options.scoreThreshold,
        hybrid_search: options.hybridSearch ? {
            embedding_weight: options.hybridSearch.embeddingWeight,
            text_weight: options.hybridSearch.textWeight
        } : void 0
    };
}
/**
* Creates a File Search tool that allows models to search your files
* for relevant information using semantic and keyword search.
*
* File Search enables models to retrieve information from a knowledge base
* of previously uploaded files stored in vector stores. This is a hosted tool
* managed by OpenAI - you don't need to implement the search execution yourself.
*
* **Prerequisites**: Before using File Search, you must:
* 1. Upload files to the File API with `purpose: "assistants"`
* 2. Create a vector store
* 3. Add files to the vector store
*
* @see {@link https://platform.openai.com/docs/guides/tools-file-search | OpenAI File Search Documentation}
*
* @param options - Configuration options for the File Search tool
* @returns A File Search tool definition to be passed to the OpenAI Responses API
*
* @example
* ```typescript
* import { ChatOpenAI, tools } from "@langchain/openai";
*
* const model = new ChatOpenAI({ model: "gpt-4.1" });
*
* // Basic usage with a vector store
* const response = await model.invoke(
*   "What is deep research by OpenAI?",
*   {
*     tools: [tools.fileSearch({
*       vectorStoreIds: ["vs_abc123"]
*     })]
*   }
* );
*
* // Limit the number of results for lower latency
* const response = await model.invoke(
*   "Find information about pricing",
*   {
*     tools: [tools.fileSearch({
*       vectorStoreIds: ["vs_abc123"],
*       maxNumResults: 5
*     })]
*   }
* );
*
* // With metadata filtering
* const response = await model.invoke(
*   "Find recent blog posts about AI",
*   {
*     tools: [tools.fileSearch({
*       vectorStoreIds: ["vs_abc123"],
*       filters: {
*         type: "eq",
*         key: "category",
*         value: "blog"
*       }
*     })]
*   }
* );
*
* // With compound filters (AND/OR)
* const response = await model.invoke(
*   "Find technical docs from 2024",
*   {
*     tools: [tools.fileSearch({
*       vectorStoreIds: ["vs_abc123"],
*       filters: {
*         type: "and",
*         filters: [
*           { type: "eq", key: "category", value: "technical" },
*           { type: "gte", key: "year", value: 2024 }
*         ]
*       }
*     })]
*   }
* );
*
* // With ranking options for more relevant results
* const response = await model.invoke(
*   "Find the most relevant information",
*   {
*     tools: [tools.fileSearch({
*       vectorStoreIds: ["vs_abc123"],
*       rankingOptions: {
*         scoreThreshold: 0.8,
*         ranker: "auto"
*       }
*     })]
*   }
* );
*
* // Search multiple vector stores
* const response = await model.invoke(
*   "Search across all knowledge bases",
*   {
*     tools: [tools.fileSearch({
*       vectorStoreIds: ["vs_abc123", "vs_def456"]
*     })]
*   }
* );
* ```
*
* @remarks
* - Vector stores must be created and populated before using this tool
* - The tool returns file citations in the response annotations
* - Use `include: ["file_search_call.results"]` in the API call to get search results
* - Supported file types include PDF, DOCX, TXT, MD, and many code file formats
*/ function fileSearch(options) {
    return {
        type: "file_search",
        vector_store_ids: options.vectorStoreIds,
        max_num_results: options.maxNumResults,
        filters: options.filters,
        ranking_options: convertRankingOptions(options.rankingOptions)
    };
}
//#endregion
exports.fileSearch = fileSearch; //# sourceMappingURL=fileSearch.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/imageGeneration.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

//#region src/tools/imageGeneration.ts
/**
* Converts input mask options to the API format.
*/ function convertInputImageMask(mask) {
    if (!mask) return void 0;
    return {
        image_url: mask.imageUrl,
        file_id: mask.fileId
    };
}
/**
* Creates an Image Generation tool that allows models to generate or edit images
* using text prompts and optional image inputs.
*
* The image generation tool leverages the GPT Image model and automatically
* optimizes text inputs for improved performance. When included in a request,
* the model can decide when and how to generate images as part of the conversation.
*
* **Key Features**:
* - Generate images from text descriptions
* - Edit existing images with text instructions
* - Multi-turn image editing by referencing previous responses
* - Configurable output options (size, quality, format)
* - Streaming support for partial image generation
*
* **Prompting Tips**:
* - Use terms like "draw" or "edit" in your prompt for best results
* - For combining images, say "edit the first image by adding this element" instead of "combine"
*
* @see {@link https://platform.openai.com/docs/guides/tools-image-generation | OpenAI Image Generation Documentation}
*
* @param options - Configuration options for the Image Generation tool
* @returns An Image Generation tool definition to be passed to the OpenAI Responses API
*
* @example
* ```typescript
* import { ChatOpenAI, tools } from "@langchain/openai";
*
* const model = new ChatOpenAI({ model: "gpt-4o" });
*
* // Basic usage - generate an image
* const response = await model.invoke(
*   "Generate an image of a gray tabby cat hugging an otter with an orange scarf",
*   { tools: [tools.imageGeneration()] }
* );
*
* // Access the generated image
* const imageData = response.additional_kwargs.tool_outputs?.find(
*   (output) => output.type === "image_generation_call"
* );
* if (imageData?.result) {
*   // imageData.result contains the base64-encoded image
*   const fs = await import("fs");
*   fs.writeFileSync("output.png", Buffer.from(imageData.result, "base64"));
* }
*
* // With custom options
* const response = await model.invoke(
*   "Draw a beautiful sunset over mountains",
*   {
*     tools: [tools.imageGeneration({
*       size: "1536x1024",      // Landscape format
*       quality: "high",        // Higher quality output
*       outputFormat: "jpeg",   // JPEG format
*       outputCompression: 90,  // 90% compression
*     })]
*   }
* );
*
* // With transparent background
* const response = await model.invoke(
*   "Create a logo with a transparent background",
*   {
*     tools: [tools.imageGeneration({
*       background: "transparent",
*       outputFormat: "png",
*     })]
*   }
* );
*
* // Force the model to use image generation
* const response = await model.invoke(
*   "A serene lake at dawn",
*   {
*     tools: [tools.imageGeneration()],
*     tool_choice: { type: "image_generation" },
*   }
* );
*
* // Enable streaming with partial images
* const response = await model.invoke(
*   "Draw a detailed fantasy castle",
*   {
*     tools: [tools.imageGeneration({
*       partialImages: 2,  // Get 2 partial images during generation
*     })]
*   }
* );
* ```
*
* @remarks
* - Supported models: gpt-4o, gpt-4o-mini, gpt-4.1, gpt-4.1-mini, gpt-4.1-nano, o3
* - The image generation process always uses `gpt-image-1` model internally
* - The model will automatically revise prompts for improved performance
* - Access the revised prompt via `revised_prompt` field in the output
* - Multi-turn editing is supported by passing previous response messages
*/ function imageGeneration(options) {
    return {
        type: "image_generation",
        background: options?.background,
        input_fidelity: options?.inputFidelity,
        input_image_mask: convertInputImageMask(options?.inputImageMask),
        model: options?.model,
        moderation: options?.moderation,
        output_compression: options?.outputCompression,
        output_format: options?.outputFormat,
        partial_images: options?.partialImages,
        quality: options?.quality,
        size: options?.size
    };
}
//#endregion
exports.imageGeneration = imageGeneration; //# sourceMappingURL=imageGeneration.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/computerUse.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const __langchain_core_messages = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/messages/index.cjs [app-route] (ecmascript)"));
const __langchain_core_tools = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/tools/index.cjs [app-route] (ecmascript)"));
const zod_v4 = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/zod@4.2.1/node_modules/zod/v4/index.cjs [app-route] (ecmascript)"));
//#region src/tools/computerUse.ts
const ComputerUseScreenshotActionSchema = zod_v4.z.object({
    type: zod_v4.z.literal("screenshot")
});
const ComputerUseClickActionSchema = zod_v4.z.object({
    type: zod_v4.z.literal("click"),
    x: zod_v4.z.number(),
    y: zod_v4.z.number(),
    button: zod_v4.z.enum([
        "left",
        "right",
        "wheel",
        "back",
        "forward"
    ]).default("left")
});
const ComputerUseDoubleClickActionSchema = zod_v4.z.object({
    type: zod_v4.z.literal("double_click"),
    x: zod_v4.z.number(),
    y: zod_v4.z.number(),
    button: zod_v4.z.enum([
        "left",
        "right",
        "wheel",
        "back",
        "forward"
    ]).default("left")
});
const ComputerUseDragActionSchema = zod_v4.z.object({
    type: zod_v4.z.literal("drag"),
    path: zod_v4.z.array(zod_v4.z.object({
        x: zod_v4.z.number(),
        y: zod_v4.z.number()
    }))
});
const ComputerUseKeypressActionSchema = zod_v4.z.object({
    type: zod_v4.z.literal("keypress"),
    keys: zod_v4.z.array(zod_v4.z.string())
});
const ComputerUseMoveActionSchema = zod_v4.z.object({
    type: zod_v4.z.literal("move"),
    x: zod_v4.z.number(),
    y: zod_v4.z.number()
});
const ComputerUseScrollActionSchema = zod_v4.z.object({
    type: zod_v4.z.literal("scroll"),
    x: zod_v4.z.number(),
    y: zod_v4.z.number(),
    scroll_x: zod_v4.z.number(),
    scroll_y: zod_v4.z.number()
});
const ComputerUseTypeActionSchema = zod_v4.z.object({
    type: zod_v4.z.literal("type"),
    text: zod_v4.z.string()
});
const ComputerUseWaitActionSchema = zod_v4.z.object({
    type: zod_v4.z.literal("wait"),
    duration: zod_v4.z.number().optional()
});
const ComputerUseActionUnionSchema = zod_v4.z.discriminatedUnion("type", [
    ComputerUseScreenshotActionSchema,
    ComputerUseClickActionSchema,
    ComputerUseDoubleClickActionSchema,
    ComputerUseDragActionSchema,
    ComputerUseKeypressActionSchema,
    ComputerUseMoveActionSchema,
    ComputerUseScrollActionSchema,
    ComputerUseTypeActionSchema,
    ComputerUseWaitActionSchema
]);
const ComputerUseActionSchema = zod_v4.z.object({
    action: ComputerUseActionUnionSchema
});
const TOOL_NAME = "computer_use";
/**
* Creates a Computer Use tool that allows models to control computer interfaces
* and perform tasks by simulating mouse clicks, keyboard input, scrolling, and more.
*
* **Computer Use** is a practical application of OpenAI's Computer-Using Agent (CUA)
* model (`computer-use-preview`), which combines vision capabilities with advanced
* reasoning to simulate controlling computer interfaces.
*
* **How it works**:
* The tool operates in a continuous loop:
* 1. Model sends computer actions (click, type, scroll, etc.)
* 2. Your code executes these actions in a controlled environment
* 3. You capture a screenshot of the result
* 4. Send the screenshot back to the model
* 5. Repeat until the task is complete
*
* **Important**: Computer use is in beta and requires careful consideration:
* - Use in sandboxed environments only
* - Do not use for high-stakes or authenticated tasks
* - Always implement human-in-the-loop for important decisions
* - Handle safety checks appropriately
*
* @see {@link https://platform.openai.com/docs/guides/tools-computer-use | OpenAI Computer Use Documentation}
*
* @param options - Configuration options for the Computer Use tool
* @returns A Computer Use tool that can be passed to `bindTools`
*
* @example
* ```typescript
* import { ChatOpenAI, tools } from "@langchain/openai";
*
* const model = new ChatOpenAI({ model: "computer-use-preview" });
*
* // With execute callback for automatic action handling
* const computer = tools.computerUse({
*   displayWidth: 1024,
*   displayHeight: 768,
*   environment: "browser",
*   execute: async (action) => {
*     if (action.type === "screenshot") {
*       return captureScreenshot();
*     }
*     if (action.type === "click") {
*       await page.mouse.click(action.x, action.y, { button: action.button });
*       return captureScreenshot();
*     }
*     if (action.type === "type") {
*       await page.keyboard.type(action.text);
*       return captureScreenshot();
*     }
*     // Handle other actions...
*     return captureScreenshot();
*   },
* });
*
* const llmWithComputer = model.bindTools([computer]);
* const response = await llmWithComputer.invoke(
*   "Check the latest news on bing.com"
* );
* ```
*
* @example
* ```typescript
* // Without execute callback (manual action handling)
* const computer = tools.computerUse({
*   displayWidth: 1024,
*   displayHeight: 768,
*   environment: "browser",
* });
*
* const response = await model.invoke("Check the news", {
*   tools: [computer],
* });
*
* // Access the computer call from the response
* const computerCall = response.additional_kwargs.tool_outputs?.find(
*   (output) => output.type === "computer_call"
* );
* if (computerCall) {
*   console.log("Action to execute:", computerCall.action);
*   // Execute the action manually, then send back a screenshot
* }
* ```
*
* @example
* ```typescript
* // For macOS desktop automation with Docker
* const computer = tools.computerUse({
*   displayWidth: 1920,
*   displayHeight: 1080,
*   environment: "mac",
*   execute: async (action) => {
*     if (action.type === "click") {
*       await dockerExec(
*         `DISPLAY=:99 xdotool mousemove ${action.x} ${action.y} click 1`,
*         containerName
*       );
*     }
*     // Capture screenshot from container
*     return await getDockerScreenshot(containerName);
*   },
* });
* ```
*
* @remarks
* - Only available through the Responses API (not Chat Completions)
* - Requires `computer-use-preview` model
* - Actions include: click, double_click, drag, keypress, move, screenshot, scroll, type, wait
* - Safety checks may be returned that require acknowledgment before proceeding
* - Use `truncation: "auto"` parameter when making requests
* - Recommended to use with `reasoning.summary` for debugging
*/ function computerUse(options) {
    const computerTool = (0, __langchain_core_tools.tool)(async (input, runtime)=>{
        /**
		* get computer_use call id from runtime
		*/ const aiMessage = runtime.state?.messages.at(-1);
        const computerToolCall = aiMessage?.tool_calls?.find((tc)=>tc.name === "computer_use");
        const computerToolCallId = computerToolCall?.id;
        if (!computerToolCallId) throw new Error("Computer use call id not found");
        const result = await options.execute(input.action, runtime);
        /**
		* make sure {@link ToolMessage} is returned with the correct additional kwargs
		*/ if (typeof result === "string") return new __langchain_core_messages.ToolMessage({
            content: result,
            tool_call_id: computerToolCallId,
            additional_kwargs: {
                type: "computer_call_output"
            }
        });
        /**
		* make sure {@link ToolMessage} is returned with the correct additional kwargs
		*/ return new __langchain_core_messages.ToolMessage({
            ...result,
            tool_call_id: computerToolCallId,
            additional_kwargs: {
                type: "computer_call_output",
                ...result.additional_kwargs
            }
        });
    }, {
        name: TOOL_NAME,
        description: "Control a computer interface by executing mouse clicks, keyboard input, scrolling, and other actions.",
        schema: ComputerUseActionSchema
    });
    computerTool.extras = {
        ...computerTool.extras ?? {},
        providerToolDefinition: {
            type: "computer_use_preview",
            display_width: options.displayWidth,
            display_height: options.displayHeight,
            environment: options.environment
        }
    };
    /**
	* return as typed {@link DynamicStructuredTool} so we don't get any type
	* errors like "can't export tool without reference"
	*/ return computerTool;
}
//#endregion
exports.computerUse = computerUse; //# sourceMappingURL=computerUse.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/localShell.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const __langchain_core_tools = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/tools/index.cjs [app-route] (ecmascript)"));
const zod_v4 = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/zod@4.2.1/node_modules/zod/v4/index.cjs [app-route] (ecmascript)"));
//#region src/tools/localShell.ts
const LocalShellExecActionSchema = zod_v4.z.object({
    type: zod_v4.z.literal("exec"),
    command: zod_v4.z.array(zod_v4.z.string()),
    env: zod_v4.z.record(zod_v4.z.string(), zod_v4.z.string()).optional(),
    working_directory: zod_v4.z.string().optional(),
    timeout_ms: zod_v4.z.number().optional(),
    user: zod_v4.z.string().optional()
});
const LocalShellActionSchema = zod_v4.z.discriminatedUnion("type", [
    LocalShellExecActionSchema
]);
const TOOL_NAME = "local_shell";
/**
* Creates a Local Shell tool that allows models to run shell commands locally
* on a machine you provide. Commands are executed inside your own runtime—
* the API only returns the instructions, but does not execute them on OpenAI infrastructure.
*
* **Important**: The local shell tool is designed to work with
* [Codex CLI](https://github.com/openai/codex) and the `codex-mini-latest` model.
*
* **How it works**:
* The tool operates in a continuous loop:
* 1. Model sends shell commands (`local_shell_call` with `exec` action)
* 2. Your code executes the command locally
* 3. You return the output back to the model
* 4. Repeat until the task is complete
*
* **Security Warning**: Running arbitrary shell commands can be dangerous.
* Always sandbox execution or add strict allow/deny-lists before forwarding
* a command to the system shell.
*
* @see {@link https://platform.openai.com/docs/guides/tools-local-shell | OpenAI Local Shell Documentation}
*
* @param options - Optional configuration for the Local Shell tool
* @returns A Local Shell tool that can be passed to `bindTools`
*
* @example
* ```typescript
* import { ChatOpenAI, tools } from "@langchain/openai";
* import { exec } from "child_process";
* import { promisify } from "util";
*
* const execAsync = promisify(exec);
* const model = new ChatOpenAI({ model: "codex-mini-latest" });
*
* // With execute callback for automatic command handling
* const shell = tools.localShell({
*   execute: async (action) => {
*     const { command, env, working_directory, timeout_ms } = action;
*     const result = await execAsync(command.join(' '), {
*       cwd: working_directory ?? process.cwd(),
*       env: { ...process.env, ...env },
*       timeout: timeout_ms ?? undefined,
*     });
*     return result.stdout + result.stderr;
*   },
* });
*
* const llmWithShell = model.bindTools([shell]);
* const response = await llmWithShell.invoke(
*   "List files in the current directory"
* );
* ```
*
* @example
* ```typescript
* // Without execute callback (manual handling)
* const shell = tools.localShell();
*
* const response = await model.invoke("List files", {
*   tools: [shell],
* });
*
* // Access the shell call from the response
* const shellCall = response.additional_kwargs.tool_outputs?.find(
*   (output) => output.type === "local_shell_call"
* );
* if (shellCall) {
*   console.log("Command to execute:", shellCall.action.command);
*   // Execute the command manually, then send back the output
* }
* ```
*
* @example
* ```typescript
* // Full shell loop example
* async function shellLoop(model, task) {
*   let response = await model.invoke(task, {
*     tools: [tools.localShell()],
*   });
*
*   while (true) {
*     const shellCall = response.additional_kwargs.tool_outputs?.find(
*       (output) => output.type === "local_shell_call"
*     );
*
*     if (!shellCall) break;
*
*     // Execute command (with proper sandboxing!)
*     const output = await executeCommand(shellCall.action);
*
*     // Send output back to model
*     response = await model.invoke([
*       response,
*       {
*         type: "local_shell_call_output",
*         id: shellCall.call_id,
*         output: output,
*       },
*     ], {
*       tools: [tools.localShell()],
*     });
*   }
*
*   return response;
* }
* ```
*
* @remarks
* - Only available through the Responses API (not Chat Completions)
* - Designed for use with `codex-mini-latest` model
* - Commands are provided as argv tokens in `action.command`
* - Action includes: `command`, `env`, `working_directory`, `timeout_ms`, `user`
* - Always sandbox or validate commands before execution
* - The `timeout_ms` from the model is only a hint—enforce your own limits
*/ function localShell(options) {
    const shellTool = (0, __langchain_core_tools.tool)(options.execute, {
        name: TOOL_NAME,
        description: "Execute shell commands locally on the machine. Commands are provided as argv tokens.",
        schema: LocalShellActionSchema
    });
    shellTool.extras = {
        ...shellTool.extras ?? {},
        providerToolDefinition: {
            type: "local_shell"
        }
    };
    return shellTool;
}
//#endregion
exports.localShell = localShell; //# sourceMappingURL=localShell.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/shell.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const __langchain_core_tools = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/tools/index.cjs [app-route] (ecmascript)"));
const zod_v4 = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/zod@4.2.1/node_modules/zod/v4/index.cjs [app-route] (ecmascript)"));
//#region src/tools/shell.ts
const ShellActionSchema = zod_v4.z.object({
    commands: zod_v4.z.array(zod_v4.z.string()).describe("Array of shell commands to execute"),
    timeout_ms: zod_v4.z.number().optional().describe("Optional timeout in milliseconds for the commands"),
    max_output_length: zod_v4.z.number().optional().describe("Optional maximum number of characters to return from each command")
});
const TOOL_NAME = "shell";
/**
* Creates a Shell tool that allows models to run shell commands through your integration.
*
* The shell tool allows the model to interact with your local computer through a controlled
* command-line interface. The model proposes shell commands; your integration executes them
* and returns the outputs. This creates a simple plan-execute loop that lets models inspect
* the system, run utilities, and gather data until they can finish the task.
*
* **Important**: The shell tool is available through the Responses API for use with `GPT-5.1`.
* It is not available on other models, or via the Chat Completions API.
*
* **When to use**:
* - **Automating filesystem or process diagnostics** – For example, "find the largest PDF
*   under ~/Documents" or "show running gunicorn processes."
* - **Extending the model's capabilities** – Using built-in UNIX utilities, python runtime
*   and other CLIs in your environment.
* - **Running multi-step build and test flows** – Chaining commands like `pip install` and `pytest`.
* - **Complex agentic coding workflows** – Using other tools like `apply_patch` to complete
*   workflows that involve complex file operations.
*
* **How it works**:
* The tool operates in a continuous loop:
* 1. Model sends shell commands (`shell_call` with `commands` array)
* 2. Your code executes the commands (can be concurrent)
* 3. You return stdout, stderr, and outcome for each command
* 4. Repeat until the task is complete
*
* **Security Warning**: Running arbitrary shell commands can be dangerous.
* Always sandbox execution or add strict allow/deny-lists before forwarding
* a command to the system shell.
*
* @see {@link https://platform.openai.com/docs/guides/tools-shell | OpenAI Shell Documentation}
* @see {@link https://github.com/openai/codex | Codex CLI} for reference implementation.
*
* @param options - Configuration for the Shell tool
* @returns A Shell tool that can be passed to `bindTools`
*
* @example
* ```typescript
* import { ChatOpenAI, tools } from "@langchain/openai";
* import { exec } from "child_process/promises";
*
* const model = new ChatOpenAI({ model: "gpt-5.1" });
*
* // With execute callback for automatic command handling
* const shellTool = tools.shell({
*   execute: async (action) => {
*     const outputs = await Promise.all(
*       action.commands.map(async (cmd) => {
*         try {
*           const { stdout, stderr } = await exec(cmd, {
*             timeout: action.timeout_ms ?? undefined,
*           });
*           return {
*             stdout,
*             stderr,
*             outcome: { type: "exit" as const, exit_code: 0 },
*           };
*         } catch (error) {
*           const timedOut = error.killed && error.signal === "SIGTERM";
*           return {
*             stdout: error.stdout ?? "",
*             stderr: error.stderr ?? String(error),
*             outcome: timedOut
*               ? { type: "timeout" as const }
*               : { type: "exit" as const, exit_code: error.code ?? 1 },
*           };
*         }
*       })
*     );
*     return {
*       output: outputs,
*       maxOutputLength: action.max_output_length,
*     };
*   },
* });
*
* const llmWithShell = model.bindTools([shellTool]);
* const response = await llmWithShell.invoke(
*   "Find the largest PDF file in ~/Documents"
* );
* ```
*
* @example
* ```typescript
* // Full shell loop example
* async function shellLoop(model, task) {
*   let response = await model.invoke(task, {
*     tools: [tools.shell({ execute: myExecutor })],
*   });
*
*   while (true) {
*     const shellCall = response.additional_kwargs.tool_outputs?.find(
*       (output) => output.type === "shell_call"
*     );
*
*     if (!shellCall) break;
*
*     // Execute commands (with proper sandboxing!)
*     const result = await executeCommands(shellCall.action);
*
*     // Send output back to model
*     response = await model.invoke([
*       response,
*       {
*         type: "shell_call_output",
*         call_id: shellCall.call_id,
*         output: result.output,
*         max_output_length: result.maxOutputLength,
*       },
*     ], {
*       tools: [tools.shell({ execute: myExecutor })],
*     });
*   }
*
*   return response;
* }
* ```
*
* @remarks
* - Only available through the Responses API (not Chat Completions)
* - Designed for use with `gpt-5.1` model
* - Commands are provided as an array of strings that can be executed concurrently
* - Action includes: `commands`, `timeout_ms`, `max_output_length`
* - Always sandbox or validate commands before execution
* - The `timeout_ms` from the model is only a hint—enforce your own limits
* - If `max_output_length` exists in the action, always pass it back in the output
* - Many CLI tools return non-zero exit codes for warnings; still capture stdout/stderr
*/ function shell(options) {
    const executeWrapper = async (action)=>{
        const result = await options.execute(action);
        return JSON.stringify({
            output: result.output,
            max_output_length: result.maxOutputLength
        });
    };
    const shellTool = (0, __langchain_core_tools.tool)(executeWrapper, {
        name: TOOL_NAME,
        description: "Execute shell commands in a managed environment. Commands can be run concurrently.",
        schema: ShellActionSchema
    });
    shellTool.extras = {
        ...shellTool.extras ?? {},
        providerToolDefinition: {
            type: "shell"
        }
    };
    return shellTool;
}
//#endregion
exports.shell = shell; //# sourceMappingURL=shell.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/applyPatch.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const __langchain_core_tools = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/tools/index.cjs [app-route] (ecmascript)"));
const zod_v4 = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/zod@4.2.1/node_modules/zod/v4/index.cjs [app-route] (ecmascript)"));
//#region src/tools/applyPatch.ts
const ApplyPatchCreateFileOperationSchema = zod_v4.z.object({
    type: zod_v4.z.literal("create_file"),
    path: zod_v4.z.string(),
    diff: zod_v4.z.string()
});
const ApplyPatchUpdateFileOperationSchema = zod_v4.z.object({
    type: zod_v4.z.literal("update_file"),
    path: zod_v4.z.string(),
    diff: zod_v4.z.string()
});
const ApplyPatchDeleteFileOperationSchema = zod_v4.z.object({
    type: zod_v4.z.literal("delete_file"),
    path: zod_v4.z.string()
});
const ApplyPatchOperationSchema = zod_v4.z.discriminatedUnion("type", [
    ApplyPatchCreateFileOperationSchema,
    ApplyPatchUpdateFileOperationSchema,
    ApplyPatchDeleteFileOperationSchema
]);
const TOOL_NAME = "apply_patch";
/**
* Creates an Apply Patch tool that allows models to propose structured diffs
* that your integration applies. This enables iterative, multi-step code
* editing workflows.
*
* **Apply Patch** lets GPT-5.1 create, update, and delete files in your codebase
* using structured diffs. Instead of just suggesting edits, the model emits
* patch operations that your application applies and then reports back on.
*
* **When to use**:
* - **Multi-file refactors** – Rename symbols, extract helpers, or reorganize modules
* - **Bug fixes** – Have the model both diagnose issues and emit precise patches
* - **Tests & docs generation** – Create new test files, fixtures, and documentation
* - **Migrations & mechanical edits** – Apply repetitive, structured updates
*
* **How it works**:
* The tool operates in a continuous loop:
* 1. Model sends patch operations (`apply_patch_call` with operation type)
* 2. Your code applies the patch to your working directory or repo
* 3. You return success/failure status and optional output
* 4. Repeat until the task is complete
*
* **Security Warning**: Applying patches can modify files in your codebase.
* Always validate paths, implement backups, and consider sandboxing.
*
* @see {@link https://platform.openai.com/docs/guides/tools-apply-patch | OpenAI Apply Patch Documentation}
*
* @param options - Configuration options for the Apply Patch tool
* @returns An Apply Patch tool that can be passed to `bindTools`
*
* @example
* ```typescript
* import { ChatOpenAI, tools } from "@langchain/openai";
* import { applyDiff } from "@openai/agents";
* import * as fs from "fs/promises";
*
* const model = new ChatOpenAI({ model: "gpt-5.1" });
*
* // With execute callback for automatic patch handling
* const patchTool = tools.applyPatch({
*   execute: async (operation) => {
*     if (operation.type === "create_file") {
*       const content = applyDiff("", operation.diff, "create");
*       await fs.writeFile(operation.path, content);
*       return `Created ${operation.path}`;
*     }
*     if (operation.type === "update_file") {
*       const current = await fs.readFile(operation.path, "utf-8");
*       const newContent = applyDiff(current, operation.diff);
*       await fs.writeFile(operation.path, newContent);
*       return `Updated ${operation.path}`;
*     }
*     if (operation.type === "delete_file") {
*       await fs.unlink(operation.path);
*       return `Deleted ${operation.path}`;
*     }
*     return "Unknown operation type";
*   },
* });
*
* const llmWithPatch = model.bindTools([patchTool]);
* const response = await llmWithPatch.invoke(
*   "Rename the fib() function to fibonacci() in lib/fib.py"
* );
* ```
*
* @remarks
* - Only available through the Responses API (not Chat Completions)
* - Designed for use with `gpt-5.1` model
* - Operations include: `create_file`, `update_file`, `delete_file`
* - Patches use V4A diff format for updates
* - Always validate paths to prevent directory traversal attacks
* - Consider backing up files before applying patches
* - Implement "all-or-nothing" semantics if atomicity is required
*/ function applyPatch(options) {
    const patchTool = (0, __langchain_core_tools.tool)(options.execute, {
        name: TOOL_NAME,
        description: "Apply structured diffs to create, update, or delete files in the codebase.",
        schema: ApplyPatchOperationSchema
    });
    patchTool.extras = {
        ...patchTool.extras ?? {},
        providerToolDefinition: {
            type: "apply_patch"
        }
    };
    return patchTool;
}
//#endregion
exports.applyPatch = applyPatch; //# sourceMappingURL=applyPatch.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/index.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_dalle = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/dalle.cjs [app-route] (ecmascript)");
const require_webSearch = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/webSearch.cjs [app-route] (ecmascript)");
const require_mcp = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/mcp.cjs [app-route] (ecmascript)");
const require_codeInterpreter = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/codeInterpreter.cjs [app-route] (ecmascript)");
const require_fileSearch = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/fileSearch.cjs [app-route] (ecmascript)");
const require_imageGeneration = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/imageGeneration.cjs [app-route] (ecmascript)");
const require_computerUse = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/computerUse.cjs [app-route] (ecmascript)");
const require_localShell = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/localShell.cjs [app-route] (ecmascript)");
const require_shell = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/shell.cjs [app-route] (ecmascript)");
const require_applyPatch = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/applyPatch.cjs [app-route] (ecmascript)");
//#region src/tools/index.ts
const tools = {
    webSearch: require_webSearch.webSearch,
    mcp: require_mcp.mcp,
    codeInterpreter: require_codeInterpreter.codeInterpreter,
    fileSearch: require_fileSearch.fileSearch,
    imageGeneration: require_imageGeneration.imageGeneration,
    computerUse: require_computerUse.computerUse,
    localShell: require_localShell.localShell,
    shell: require_shell.shell,
    applyPatch: require_applyPatch.applyPatch
};
//#endregion
exports.tools = tools; //# sourceMappingURL=index.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/custom.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const __langchain_core_runnables = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/runnables/index.cjs [app-route] (ecmascript)"));
const __langchain_core_tools = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/tools/index.cjs [app-route] (ecmascript)"));
const __langchain_core_singletons = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1_/node_modules/@langchain/core/dist/singletons/index.cjs [app-route] (ecmascript)"));
//#region src/tools/custom.ts
function customTool(func, fields) {
    return new __langchain_core_tools.DynamicTool({
        ...fields,
        description: "",
        metadata: {
            customTool: fields
        },
        func: async (input, runManager, config)=>new Promise((resolve, reject)=>{
                const childConfig = (0, __langchain_core_runnables.patchConfig)(config, {
                    callbacks: runManager?.getChild()
                });
                __langchain_core_singletons.AsyncLocalStorageProviderSingleton.runWithConfig((0, __langchain_core_runnables.pickRunnableConfigKeys)(childConfig), async ()=>{
                    try {
                        resolve(func(input, childConfig));
                    } catch (e) {
                        reject(e);
                    }
                });
            })
    });
}
//#endregion
exports.customTool = customTool; //# sourceMappingURL=custom.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/prompts.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_completions = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/converters/completions.cjs [app-route] (ecmascript)");
//#region src/utils/prompts.ts
/**
* Convert a formatted LangChain prompt (e.g. pulled from the hub) into
* a format expected by OpenAI's JS SDK.
*
* Requires the "@langchain/openai" package to be installed in addition
* to the OpenAI SDK.
*
* @example
* ```ts
* import { convertPromptToOpenAI } from "langsmith/utils/hub/openai";
* import { pull } from "langchain/hub";
*
* import OpenAI from 'openai';
*
* const prompt = await pull("jacob/joke-generator");
* const formattedPrompt = await prompt.invoke({
*   topic: "cats",
* });
*
* const { messages } = convertPromptToOpenAI(formattedPrompt);
*
* const openAIClient = new OpenAI();
*
* const openaiResponse = await openAIClient.chat.completions.create({
*   model: "gpt-4o-mini",
*   messages,
* });
* ```
* @param formattedPrompt
* @returns A partial OpenAI payload.
*/ function convertPromptToOpenAI(formattedPrompt) {
    const messages = formattedPrompt.toChatMessages();
    return {
        messages: require_completions.convertMessagesToCompletionsMessageParams({
            messages
        })
    };
}
//#endregion
exports.convertPromptToOpenAI = convertPromptToOpenAI; //# sourceMappingURL=prompts.cjs.map
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/converters/index.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_completions = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/converters/completions.cjs [app-route] (ecmascript)");
const require_responses = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/converters/responses.cjs [app-route] (ecmascript)");
}),
"[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/index.cjs [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

const require_rolldown_runtime = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/_virtual/rolldown_runtime.cjs [app-route] (ecmascript)");
const require_client = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/client.cjs [app-route] (ecmascript)");
const require_misc = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/misc.cjs [app-route] (ecmascript)");
const require_azure = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/azure.cjs [app-route] (ecmascript)");
const require_base = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/base.cjs [app-route] (ecmascript)");
const require_completions = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/converters/completions.cjs [app-route] (ecmascript)");
const require_completions$1 = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/completions.cjs [app-route] (ecmascript)");
const require_completions$2 = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/azure/chat_models/completions.cjs [app-route] (ecmascript)");
const require_responses = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/converters/responses.cjs [app-route] (ecmascript)");
const require_responses$1 = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/responses.cjs [app-route] (ecmascript)");
const require_responses$2 = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/azure/chat_models/responses.cjs [app-route] (ecmascript)");
const require_index = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/chat_models/index.cjs [app-route] (ecmascript)");
const require_index$1 = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/azure/chat_models/index.cjs [app-route] (ecmascript)");
const require_llms = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/llms.cjs [app-route] (ecmascript)");
const require_llms$1 = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/azure/llms.cjs [app-route] (ecmascript)");
const require_embeddings = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/embeddings.cjs [app-route] (ecmascript)");
const require_embeddings$1 = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/azure/embeddings.cjs [app-route] (ecmascript)");
const require_dalle = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/dalle.cjs [app-route] (ecmascript)");
const require_index$2 = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/index.cjs [app-route] (ecmascript)");
const require_custom = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/tools/custom.cjs [app-route] (ecmascript)");
const require_prompts = __turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/utils/prompts.cjs [app-route] (ecmascript)");
__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/@langchain+openai@1.2.0_@langchain+core@1.1.8_openai@6.15.0_ws@8.19.0_zod@4.2.1___ws@8.19.0/node_modules/@langchain/openai/dist/converters/index.cjs [app-route] (ecmascript)");
const openai = require_rolldown_runtime.__toESM(__turbopack_context__.r("[project]/workspace/projects/node_modules/.pnpm/openai@6.15.0_ws@8.19.0_zod@4.2.1/node_modules/openai/index.js [app-route] (ecmascript)"));
exports.AzureChatOpenAI = require_index$1.AzureChatOpenAI;
exports.AzureChatOpenAICompletions = require_completions$2.AzureChatOpenAICompletions;
exports.AzureChatOpenAIResponses = require_responses$2.AzureChatOpenAIResponses;
exports.AzureOpenAI = require_llms$1.AzureOpenAI;
exports.AzureOpenAIEmbeddings = require_embeddings$1.AzureOpenAIEmbeddings;
exports.BaseChatOpenAI = require_base.BaseChatOpenAI;
exports.ChatOpenAI = require_index.ChatOpenAI;
exports.ChatOpenAICompletions = require_completions$1.ChatOpenAICompletions;
exports.ChatOpenAIResponses = require_responses$1.ChatOpenAIResponses;
exports.DallEAPIWrapper = require_dalle.DallEAPIWrapper;
exports.OpenAI = require_llms.OpenAI;
Object.defineProperty(exports, 'OpenAIClient', {
    enumerable: true,
    get: function() {
        return openai.OpenAI;
    }
});
exports.OpenAIEmbeddings = require_embeddings.OpenAIEmbeddings;
exports.completionsApiContentBlockConverter = require_completions.completionsApiContentBlockConverter;
exports.convertCompletionsDeltaToBaseMessageChunk = require_completions.convertCompletionsDeltaToBaseMessageChunk;
exports.convertCompletionsMessageToBaseMessage = require_completions.convertCompletionsMessageToBaseMessage;
exports.convertMessagesToCompletionsMessageParams = require_completions.convertMessagesToCompletionsMessageParams;
exports.convertMessagesToResponsesInput = require_responses.convertMessagesToResponsesInput;
exports.convertPromptToOpenAI = require_prompts.convertPromptToOpenAI;
exports.convertReasoningSummaryToResponsesReasoningItem = require_responses.convertReasoningSummaryToResponsesReasoningItem;
exports.convertResponsesDeltaToChatGenerationChunk = require_responses.convertResponsesDeltaToChatGenerationChunk;
exports.convertResponsesMessageToAIMessage = require_responses.convertResponsesMessageToAIMessage;
exports.convertResponsesUsageToUsageMetadata = require_responses.convertResponsesUsageToUsageMetadata;
exports.convertStandardContentBlockToCompletionsContentPart = require_completions.convertStandardContentBlockToCompletionsContentPart;
exports.convertStandardContentMessageToCompletionsMessage = require_completions.convertStandardContentMessageToCompletionsMessage;
exports.convertStandardContentMessageToResponsesInput = require_responses.convertStandardContentMessageToResponsesInput;
exports.customTool = require_custom.customTool;
exports.getEndpoint = require_azure.getEndpoint;
exports.getFormattedEnv = require_azure.getFormattedEnv;
exports.getHeadersWithUserAgent = require_azure.getHeadersWithUserAgent;
exports.isHeaders = require_azure.isHeaders;
exports.messageToOpenAIRole = require_misc.messageToOpenAIRole;
exports.normalizeHeaders = require_azure.normalizeHeaders;
Object.defineProperty(exports, 'toFile', {
    enumerable: true,
    get: function() {
        return openai.toFile;
    }
});
exports.tools = require_index$2.tools;
exports.wrapOpenAIClientError = require_client.wrapOpenAIClientError;
}),
];

//# sourceMappingURL=16e57_%40langchain_openai_dist_03ca0de2._.js.map