globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/b9369_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0aa19d29._.js",
    "static/chunks/b9369_next_dist_compiled_react-dom_042e344b._.js",
    "static/chunks/b9369_next_dist_compiled_react-server-dom-turbopack_4cf0dcec._.js",
    "static/chunks/b9369_next_dist_compiled_next-devtools_index_47dc7d4e.js",
    "static/chunks/b9369_next_dist_compiled_8be6bc0d._.js",
    "static/chunks/b9369_next_dist_client_c798e8db._.js",
    "static/chunks/b9369_next_dist_a8f12cf7._.js",
    "static/chunks/ff2e8_@swc_helpers_cjs_ed7f8946._.js",
    "static/chunks/workspace_projects_a0ff3932._.js",
    "static/chunks/turbopack-workspace_projects_90e803cd._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];